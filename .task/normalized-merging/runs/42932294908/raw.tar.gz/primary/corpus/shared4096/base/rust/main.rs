fn graph_fn0(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2048((x*x+1)%65521,d-1); let b=graph_fn2049((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2049((x*x+2)%65521,d-1); let b=graph_fn2066((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn2(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2050((x*x+3)%65521,d-1); let b=graph_fn2083((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn3(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2051((x*x+4)%65521,d-1); let b=graph_fn2100((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn4(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2052((x*x+5)%65521,d-1); let b=graph_fn2117((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn5(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2053((x*x+6)%65521,d-1); let b=graph_fn2134((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn6(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2054((x*x+7)%65521,d-1); let b=graph_fn2151((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn7(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2055((x*x+8)%65521,d-1); let b=graph_fn2168((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn8(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2056((x*x+9)%65521,d-1); let b=graph_fn2185((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn9(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2057((x*x+10)%65521,d-1); let b=graph_fn2202((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn10(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2058((x*x+11)%65521,d-1); let b=graph_fn2219((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn11(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2059((x*x+12)%65521,d-1); let b=graph_fn2236((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn12(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2060((x*x+13)%65521,d-1); let b=graph_fn2253((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn13(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2061((x*x+14)%65521,d-1); let b=graph_fn2270((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn14(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2062((x*x+15)%65521,d-1); let b=graph_fn2287((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn15(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2063((x*x+16)%65521,d-1); let b=graph_fn2304((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn16(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2064((x*x+17)%65521,d-1); let b=graph_fn2321((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn17(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2065((x*x+18)%65521,d-1); let b=graph_fn2338((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn18(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2066((x*x+19)%65521,d-1); let b=graph_fn2355((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn19(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2067((x*x+20)%65521,d-1); let b=graph_fn2372((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn20(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2068((x*x+21)%65521,d-1); let b=graph_fn2389((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn21(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2069((x*x+22)%65521,d-1); let b=graph_fn2406((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn22(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2070((x*x+23)%65521,d-1); let b=graph_fn2423((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn23(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2071((x*x+24)%65521,d-1); let b=graph_fn2440((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn24(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2072((x*x+25)%65521,d-1); let b=graph_fn2457((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn25(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2073((x*x+26)%65521,d-1); let b=graph_fn2474((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn26(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2074((x*x+27)%65521,d-1); let b=graph_fn2491((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn27(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2075((x*x+28)%65521,d-1); let b=graph_fn2508((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn28(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2076((x*x+29)%65521,d-1); let b=graph_fn2525((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn29(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2077((x*x+30)%65521,d-1); let b=graph_fn2542((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn30(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2078((x*x+31)%65521,d-1); let b=graph_fn2559((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn31(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2079((x*x+32)%65521,d-1); let b=graph_fn2576((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn32(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2080((x*x+33)%65521,d-1); let b=graph_fn2593((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn33(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2081((x*x+34)%65521,d-1); let b=graph_fn2610((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn34(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2082((x*x+35)%65521,d-1); let b=graph_fn2627((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn35(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2083((x*x+36)%65521,d-1); let b=graph_fn2644((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn36(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2084((x*x+37)%65521,d-1); let b=graph_fn2661((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn37(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2085((x*x+38)%65521,d-1); let b=graph_fn2678((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn38(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2086((x*x+39)%65521,d-1); let b=graph_fn2695((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn39(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2087((x*x+40)%65521,d-1); let b=graph_fn2712((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn40(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2088((x*x+41)%65521,d-1); let b=graph_fn2729((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn41(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2089((x*x+42)%65521,d-1); let b=graph_fn2746((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn42(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2090((x*x+43)%65521,d-1); let b=graph_fn2763((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn43(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2091((x*x+44)%65521,d-1); let b=graph_fn2780((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn44(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2092((x*x+45)%65521,d-1); let b=graph_fn2797((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn45(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2093((x*x+46)%65521,d-1); let b=graph_fn2814((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn46(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2094((x*x+47)%65521,d-1); let b=graph_fn2831((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn47(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2095((x*x+48)%65521,d-1); let b=graph_fn2848((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn48(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2096((x*x+49)%65521,d-1); let b=graph_fn2865((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn49(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2097((x*x+50)%65521,d-1); let b=graph_fn2882((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn50(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2098((x*x+51)%65521,d-1); let b=graph_fn2899((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn51(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2099((x*x+52)%65521,d-1); let b=graph_fn2916((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn52(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2100((x*x+53)%65521,d-1); let b=graph_fn2933((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn53(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2101((x*x+54)%65521,d-1); let b=graph_fn2950((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn54(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2102((x*x+55)%65521,d-1); let b=graph_fn2967((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn55(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2103((x*x+56)%65521,d-1); let b=graph_fn2984((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn56(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2104((x*x+57)%65521,d-1); let b=graph_fn3001((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn57(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2105((x*x+58)%65521,d-1); let b=graph_fn3018((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn58(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2106((x*x+59)%65521,d-1); let b=graph_fn3035((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn59(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2107((x*x+60)%65521,d-1); let b=graph_fn3052((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn60(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2108((x*x+61)%65521,d-1); let b=graph_fn3069((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn61(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2109((x*x+62)%65521,d-1); let b=graph_fn3086((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn62(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2110((x*x+63)%65521,d-1); let b=graph_fn3103((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn63(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2111((x*x+64)%65521,d-1); let b=graph_fn3120((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn64(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2112((x*x+65)%65521,d-1); let b=graph_fn3137((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn65(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2113((x*x+66)%65521,d-1); let b=graph_fn3154((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn66(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2114((x*x+67)%65521,d-1); let b=graph_fn3171((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn67(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2115((x*x+68)%65521,d-1); let b=graph_fn3188((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn68(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2116((x*x+69)%65521,d-1); let b=graph_fn3205((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn69(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2117((x*x+70)%65521,d-1); let b=graph_fn3222((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn70(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2118((x*x+71)%65521,d-1); let b=graph_fn3239((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn71(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2119((x*x+72)%65521,d-1); let b=graph_fn3256((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn72(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2120((x*x+73)%65521,d-1); let b=graph_fn3273((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn73(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2121((x*x+74)%65521,d-1); let b=graph_fn3290((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn74(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2122((x*x+75)%65521,d-1); let b=graph_fn3307((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn75(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2123((x*x+76)%65521,d-1); let b=graph_fn3324((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn76(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2124((x*x+77)%65521,d-1); let b=graph_fn3341((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn77(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2125((x*x+78)%65521,d-1); let b=graph_fn3358((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn78(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2126((x*x+79)%65521,d-1); let b=graph_fn3375((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn79(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2127((x*x+80)%65521,d-1); let b=graph_fn3392((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn80(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2128((x*x+81)%65521,d-1); let b=graph_fn3409((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn81(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2129((x*x+82)%65521,d-1); let b=graph_fn3426((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn82(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2130((x*x+83)%65521,d-1); let b=graph_fn3443((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn83(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2131((x*x+84)%65521,d-1); let b=graph_fn3460((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn84(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2132((x*x+85)%65521,d-1); let b=graph_fn3477((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn85(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2133((x*x+86)%65521,d-1); let b=graph_fn3494((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn86(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2134((x*x+87)%65521,d-1); let b=graph_fn3511((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn87(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2135((x*x+88)%65521,d-1); let b=graph_fn3528((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn88(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2136((x*x+89)%65521,d-1); let b=graph_fn3545((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn89(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2137((x*x+90)%65521,d-1); let b=graph_fn3562((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn90(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2138((x*x+91)%65521,d-1); let b=graph_fn3579((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn91(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2139((x*x+92)%65521,d-1); let b=graph_fn3596((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn92(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2140((x*x+93)%65521,d-1); let b=graph_fn3613((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn93(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2141((x*x+94)%65521,d-1); let b=graph_fn3630((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn94(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2142((x*x+95)%65521,d-1); let b=graph_fn3647((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn95(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2143((x*x+96)%65521,d-1); let b=graph_fn3664((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn96(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2144((x*x+97)%65521,d-1); let b=graph_fn3681((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn97(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2145((x*x+1)%65521,d-1); let b=graph_fn3698((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn98(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2146((x*x+2)%65521,d-1); let b=graph_fn3715((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn99(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2147((x*x+3)%65521,d-1); let b=graph_fn3732((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn100(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2148((x*x+4)%65521,d-1); let b=graph_fn3749((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn101(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2149((x*x+5)%65521,d-1); let b=graph_fn3766((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn102(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2150((x*x+6)%65521,d-1); let b=graph_fn3783((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn103(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2151((x*x+7)%65521,d-1); let b=graph_fn3800((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn104(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2152((x*x+8)%65521,d-1); let b=graph_fn3817((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn105(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2153((x*x+9)%65521,d-1); let b=graph_fn3834((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn106(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2154((x*x+10)%65521,d-1); let b=graph_fn3851((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn107(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2155((x*x+11)%65521,d-1); let b=graph_fn3868((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn108(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2156((x*x+12)%65521,d-1); let b=graph_fn3885((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn109(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2157((x*x+13)%65521,d-1); let b=graph_fn3902((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn110(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2158((x*x+14)%65521,d-1); let b=graph_fn3919((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn111(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2159((x*x+15)%65521,d-1); let b=graph_fn3936((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn112(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2160((x*x+16)%65521,d-1); let b=graph_fn3953((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn113(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2161((x*x+17)%65521,d-1); let b=graph_fn3970((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn114(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2162((x*x+18)%65521,d-1); let b=graph_fn3987((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn115(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2163((x*x+19)%65521,d-1); let b=graph_fn4004((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn116(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2164((x*x+20)%65521,d-1); let b=graph_fn4021((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn117(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2165((x*x+21)%65521,d-1); let b=graph_fn4038((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn118(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2166((x*x+22)%65521,d-1); let b=graph_fn4055((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn119(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2167((x*x+23)%65521,d-1); let b=graph_fn4072((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn120(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2168((x*x+24)%65521,d-1); let b=graph_fn4089((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn121(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2169((x*x+25)%65521,d-1); let b=graph_fn2058((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn122(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2170((x*x+26)%65521,d-1); let b=graph_fn2075((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn123(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2171((x*x+27)%65521,d-1); let b=graph_fn2092((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn124(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2172((x*x+28)%65521,d-1); let b=graph_fn2109((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn125(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2173((x*x+29)%65521,d-1); let b=graph_fn2126((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn126(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2174((x*x+30)%65521,d-1); let b=graph_fn2143((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn127(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2175((x*x+31)%65521,d-1); let b=graph_fn2160((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn128(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2176((x*x+32)%65521,d-1); let b=graph_fn2177((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn129(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2177((x*x+33)%65521,d-1); let b=graph_fn2194((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn130(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2178((x*x+34)%65521,d-1); let b=graph_fn2211((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn131(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2179((x*x+35)%65521,d-1); let b=graph_fn2228((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn132(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2180((x*x+36)%65521,d-1); let b=graph_fn2245((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn133(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2181((x*x+37)%65521,d-1); let b=graph_fn2262((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn134(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2182((x*x+38)%65521,d-1); let b=graph_fn2279((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn135(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2183((x*x+39)%65521,d-1); let b=graph_fn2296((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn136(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2184((x*x+40)%65521,d-1); let b=graph_fn2313((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn137(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2185((x*x+41)%65521,d-1); let b=graph_fn2330((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn138(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2186((x*x+42)%65521,d-1); let b=graph_fn2347((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn139(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2187((x*x+43)%65521,d-1); let b=graph_fn2364((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn140(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2188((x*x+44)%65521,d-1); let b=graph_fn2381((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn141(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2189((x*x+45)%65521,d-1); let b=graph_fn2398((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn142(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2190((x*x+46)%65521,d-1); let b=graph_fn2415((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn143(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2191((x*x+47)%65521,d-1); let b=graph_fn2432((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn144(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2192((x*x+48)%65521,d-1); let b=graph_fn2449((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn145(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2193((x*x+49)%65521,d-1); let b=graph_fn2466((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn146(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2194((x*x+50)%65521,d-1); let b=graph_fn2483((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn147(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2195((x*x+51)%65521,d-1); let b=graph_fn2500((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn148(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2196((x*x+52)%65521,d-1); let b=graph_fn2517((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn149(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2197((x*x+53)%65521,d-1); let b=graph_fn2534((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn150(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2198((x*x+54)%65521,d-1); let b=graph_fn2551((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn151(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2199((x*x+55)%65521,d-1); let b=graph_fn2568((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn152(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2200((x*x+56)%65521,d-1); let b=graph_fn2585((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn153(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2201((x*x+57)%65521,d-1); let b=graph_fn2602((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn154(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2202((x*x+58)%65521,d-1); let b=graph_fn2619((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn155(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2203((x*x+59)%65521,d-1); let b=graph_fn2636((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn156(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2204((x*x+60)%65521,d-1); let b=graph_fn2653((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn157(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2205((x*x+61)%65521,d-1); let b=graph_fn2670((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn158(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2206((x*x+62)%65521,d-1); let b=graph_fn2687((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn159(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2207((x*x+63)%65521,d-1); let b=graph_fn2704((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn160(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2208((x*x+64)%65521,d-1); let b=graph_fn2721((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn161(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2209((x*x+65)%65521,d-1); let b=graph_fn2738((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn162(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2210((x*x+66)%65521,d-1); let b=graph_fn2755((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn163(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2211((x*x+67)%65521,d-1); let b=graph_fn2772((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn164(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2212((x*x+68)%65521,d-1); let b=graph_fn2789((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn165(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2213((x*x+69)%65521,d-1); let b=graph_fn2806((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn166(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2214((x*x+70)%65521,d-1); let b=graph_fn2823((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn167(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2215((x*x+71)%65521,d-1); let b=graph_fn2840((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn168(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2216((x*x+72)%65521,d-1); let b=graph_fn2857((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn169(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2217((x*x+73)%65521,d-1); let b=graph_fn2874((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn170(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2218((x*x+74)%65521,d-1); let b=graph_fn2891((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn171(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2219((x*x+75)%65521,d-1); let b=graph_fn2908((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn172(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2220((x*x+76)%65521,d-1); let b=graph_fn2925((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn173(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2221((x*x+77)%65521,d-1); let b=graph_fn2942((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn174(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2222((x*x+78)%65521,d-1); let b=graph_fn2959((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn175(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2223((x*x+79)%65521,d-1); let b=graph_fn2976((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn176(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2224((x*x+80)%65521,d-1); let b=graph_fn2993((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn177(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2225((x*x+81)%65521,d-1); let b=graph_fn3010((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn178(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2226((x*x+82)%65521,d-1); let b=graph_fn3027((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn179(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2227((x*x+83)%65521,d-1); let b=graph_fn3044((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn180(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2228((x*x+84)%65521,d-1); let b=graph_fn3061((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn181(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2229((x*x+85)%65521,d-1); let b=graph_fn3078((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn182(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2230((x*x+86)%65521,d-1); let b=graph_fn3095((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn183(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2231((x*x+87)%65521,d-1); let b=graph_fn3112((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn184(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2232((x*x+88)%65521,d-1); let b=graph_fn3129((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn185(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2233((x*x+89)%65521,d-1); let b=graph_fn3146((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn186(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2234((x*x+90)%65521,d-1); let b=graph_fn3163((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn187(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2235((x*x+91)%65521,d-1); let b=graph_fn3180((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn188(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2236((x*x+92)%65521,d-1); let b=graph_fn3197((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn189(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2237((x*x+93)%65521,d-1); let b=graph_fn3214((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn190(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2238((x*x+94)%65521,d-1); let b=graph_fn3231((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn191(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2239((x*x+95)%65521,d-1); let b=graph_fn3248((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn192(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2240((x*x+96)%65521,d-1); let b=graph_fn3265((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn193(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2241((x*x+97)%65521,d-1); let b=graph_fn3282((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn194(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2242((x*x+1)%65521,d-1); let b=graph_fn3299((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn195(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2243((x*x+2)%65521,d-1); let b=graph_fn3316((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn196(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2244((x*x+3)%65521,d-1); let b=graph_fn3333((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn197(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2245((x*x+4)%65521,d-1); let b=graph_fn3350((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn198(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2246((x*x+5)%65521,d-1); let b=graph_fn3367((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn199(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2247((x*x+6)%65521,d-1); let b=graph_fn3384((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn200(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2248((x*x+7)%65521,d-1); let b=graph_fn3401((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn201(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2249((x*x+8)%65521,d-1); let b=graph_fn3418((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn202(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2250((x*x+9)%65521,d-1); let b=graph_fn3435((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn203(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2251((x*x+10)%65521,d-1); let b=graph_fn3452((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn204(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2252((x*x+11)%65521,d-1); let b=graph_fn3469((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn205(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2253((x*x+12)%65521,d-1); let b=graph_fn3486((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn206(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2254((x*x+13)%65521,d-1); let b=graph_fn3503((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn207(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2255((x*x+14)%65521,d-1); let b=graph_fn3520((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn208(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2256((x*x+15)%65521,d-1); let b=graph_fn3537((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn209(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2257((x*x+16)%65521,d-1); let b=graph_fn3554((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn210(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2258((x*x+17)%65521,d-1); let b=graph_fn3571((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn211(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2259((x*x+18)%65521,d-1); let b=graph_fn3588((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn212(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2260((x*x+19)%65521,d-1); let b=graph_fn3605((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn213(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2261((x*x+20)%65521,d-1); let b=graph_fn3622((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn214(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2262((x*x+21)%65521,d-1); let b=graph_fn3639((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn215(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2263((x*x+22)%65521,d-1); let b=graph_fn3656((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn216(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2264((x*x+23)%65521,d-1); let b=graph_fn3673((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn217(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2265((x*x+24)%65521,d-1); let b=graph_fn3690((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn218(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2266((x*x+25)%65521,d-1); let b=graph_fn3707((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn219(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2267((x*x+26)%65521,d-1); let b=graph_fn3724((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn220(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2268((x*x+27)%65521,d-1); let b=graph_fn3741((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn221(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2269((x*x+28)%65521,d-1); let b=graph_fn3758((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn222(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2270((x*x+29)%65521,d-1); let b=graph_fn3775((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn223(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2271((x*x+30)%65521,d-1); let b=graph_fn3792((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn224(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2272((x*x+31)%65521,d-1); let b=graph_fn3809((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn225(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2273((x*x+32)%65521,d-1); let b=graph_fn3826((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn226(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2274((x*x+33)%65521,d-1); let b=graph_fn3843((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn227(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2275((x*x+34)%65521,d-1); let b=graph_fn3860((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn228(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2276((x*x+35)%65521,d-1); let b=graph_fn3877((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn229(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2277((x*x+36)%65521,d-1); let b=graph_fn3894((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn230(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2278((x*x+37)%65521,d-1); let b=graph_fn3911((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn231(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2279((x*x+38)%65521,d-1); let b=graph_fn3928((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn232(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2280((x*x+39)%65521,d-1); let b=graph_fn3945((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn233(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2281((x*x+40)%65521,d-1); let b=graph_fn3962((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn234(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2282((x*x+41)%65521,d-1); let b=graph_fn3979((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn235(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2283((x*x+42)%65521,d-1); let b=graph_fn3996((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn236(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2284((x*x+43)%65521,d-1); let b=graph_fn4013((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn237(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2285((x*x+44)%65521,d-1); let b=graph_fn4030((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn238(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2286((x*x+45)%65521,d-1); let b=graph_fn4047((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn239(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2287((x*x+46)%65521,d-1); let b=graph_fn4064((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn240(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2288((x*x+47)%65521,d-1); let b=graph_fn4081((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn241(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2289((x*x+48)%65521,d-1); let b=graph_fn2050((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn242(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2290((x*x+49)%65521,d-1); let b=graph_fn2067((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn243(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2291((x*x+50)%65521,d-1); let b=graph_fn2084((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn244(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2292((x*x+51)%65521,d-1); let b=graph_fn2101((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn245(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2293((x*x+52)%65521,d-1); let b=graph_fn2118((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn246(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2294((x*x+53)%65521,d-1); let b=graph_fn2135((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn247(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2295((x*x+54)%65521,d-1); let b=graph_fn2152((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn248(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2296((x*x+55)%65521,d-1); let b=graph_fn2169((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn249(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2297((x*x+56)%65521,d-1); let b=graph_fn2186((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn250(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2298((x*x+57)%65521,d-1); let b=graph_fn2203((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn251(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2299((x*x+58)%65521,d-1); let b=graph_fn2220((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn252(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2300((x*x+59)%65521,d-1); let b=graph_fn2237((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn253(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2301((x*x+60)%65521,d-1); let b=graph_fn2254((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn254(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2302((x*x+61)%65521,d-1); let b=graph_fn2271((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn255(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2303((x*x+62)%65521,d-1); let b=graph_fn2288((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn256(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2304((x*x+63)%65521,d-1); let b=graph_fn2305((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn257(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2305((x*x+64)%65521,d-1); let b=graph_fn2322((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn258(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2306((x*x+65)%65521,d-1); let b=graph_fn2339((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn259(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2307((x*x+66)%65521,d-1); let b=graph_fn2356((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn260(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2308((x*x+67)%65521,d-1); let b=graph_fn2373((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn261(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2309((x*x+68)%65521,d-1); let b=graph_fn2390((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn262(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2310((x*x+69)%65521,d-1); let b=graph_fn2407((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn263(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2311((x*x+70)%65521,d-1); let b=graph_fn2424((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn264(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2312((x*x+71)%65521,d-1); let b=graph_fn2441((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn265(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2313((x*x+72)%65521,d-1); let b=graph_fn2458((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn266(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2314((x*x+73)%65521,d-1); let b=graph_fn2475((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn267(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2315((x*x+74)%65521,d-1); let b=graph_fn2492((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn268(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2316((x*x+75)%65521,d-1); let b=graph_fn2509((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn269(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2317((x*x+76)%65521,d-1); let b=graph_fn2526((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn270(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2318((x*x+77)%65521,d-1); let b=graph_fn2543((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn271(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2319((x*x+78)%65521,d-1); let b=graph_fn2560((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn272(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2320((x*x+79)%65521,d-1); let b=graph_fn2577((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn273(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2321((x*x+80)%65521,d-1); let b=graph_fn2594((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn274(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2322((x*x+81)%65521,d-1); let b=graph_fn2611((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn275(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2323((x*x+82)%65521,d-1); let b=graph_fn2628((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn276(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2324((x*x+83)%65521,d-1); let b=graph_fn2645((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn277(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2325((x*x+84)%65521,d-1); let b=graph_fn2662((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn278(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2326((x*x+85)%65521,d-1); let b=graph_fn2679((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn279(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2327((x*x+86)%65521,d-1); let b=graph_fn2696((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn280(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2328((x*x+87)%65521,d-1); let b=graph_fn2713((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn281(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2329((x*x+88)%65521,d-1); let b=graph_fn2730((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn282(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2330((x*x+89)%65521,d-1); let b=graph_fn2747((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn283(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2331((x*x+90)%65521,d-1); let b=graph_fn2764((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn284(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2332((x*x+91)%65521,d-1); let b=graph_fn2781((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn285(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2333((x*x+92)%65521,d-1); let b=graph_fn2798((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn286(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2334((x*x+93)%65521,d-1); let b=graph_fn2815((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn287(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2335((x*x+94)%65521,d-1); let b=graph_fn2832((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn288(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2336((x*x+95)%65521,d-1); let b=graph_fn2849((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn289(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2337((x*x+96)%65521,d-1); let b=graph_fn2866((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn290(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2338((x*x+97)%65521,d-1); let b=graph_fn2883((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn291(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2339((x*x+1)%65521,d-1); let b=graph_fn2900((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn292(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2340((x*x+2)%65521,d-1); let b=graph_fn2917((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn293(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2341((x*x+3)%65521,d-1); let b=graph_fn2934((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn294(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2342((x*x+4)%65521,d-1); let b=graph_fn2951((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn295(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2343((x*x+5)%65521,d-1); let b=graph_fn2968((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn296(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2344((x*x+6)%65521,d-1); let b=graph_fn2985((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn297(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2345((x*x+7)%65521,d-1); let b=graph_fn3002((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn298(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2346((x*x+8)%65521,d-1); let b=graph_fn3019((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn299(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2347((x*x+9)%65521,d-1); let b=graph_fn3036((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn300(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2348((x*x+10)%65521,d-1); let b=graph_fn3053((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn301(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2349((x*x+11)%65521,d-1); let b=graph_fn3070((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn302(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2350((x*x+12)%65521,d-1); let b=graph_fn3087((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn303(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2351((x*x+13)%65521,d-1); let b=graph_fn3104((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn304(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2352((x*x+14)%65521,d-1); let b=graph_fn3121((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn305(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2353((x*x+15)%65521,d-1); let b=graph_fn3138((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn306(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2354((x*x+16)%65521,d-1); let b=graph_fn3155((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn307(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2355((x*x+17)%65521,d-1); let b=graph_fn3172((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn308(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2356((x*x+18)%65521,d-1); let b=graph_fn3189((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn309(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2357((x*x+19)%65521,d-1); let b=graph_fn3206((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn310(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2358((x*x+20)%65521,d-1); let b=graph_fn3223((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn311(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2359((x*x+21)%65521,d-1); let b=graph_fn3240((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn312(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2360((x*x+22)%65521,d-1); let b=graph_fn3257((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn313(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2361((x*x+23)%65521,d-1); let b=graph_fn3274((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn314(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2362((x*x+24)%65521,d-1); let b=graph_fn3291((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn315(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2363((x*x+25)%65521,d-1); let b=graph_fn3308((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn316(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2364((x*x+26)%65521,d-1); let b=graph_fn3325((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn317(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2365((x*x+27)%65521,d-1); let b=graph_fn3342((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn318(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2366((x*x+28)%65521,d-1); let b=graph_fn3359((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn319(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2367((x*x+29)%65521,d-1); let b=graph_fn3376((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn320(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2368((x*x+30)%65521,d-1); let b=graph_fn3393((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn321(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2369((x*x+31)%65521,d-1); let b=graph_fn3410((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn322(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2370((x*x+32)%65521,d-1); let b=graph_fn3427((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn323(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2371((x*x+33)%65521,d-1); let b=graph_fn3444((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn324(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2372((x*x+34)%65521,d-1); let b=graph_fn3461((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn325(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2373((x*x+35)%65521,d-1); let b=graph_fn3478((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn326(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2374((x*x+36)%65521,d-1); let b=graph_fn3495((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn327(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2375((x*x+37)%65521,d-1); let b=graph_fn3512((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn328(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2376((x*x+38)%65521,d-1); let b=graph_fn3529((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn329(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2377((x*x+39)%65521,d-1); let b=graph_fn3546((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn330(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2378((x*x+40)%65521,d-1); let b=graph_fn3563((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn331(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2379((x*x+41)%65521,d-1); let b=graph_fn3580((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn332(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2380((x*x+42)%65521,d-1); let b=graph_fn3597((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn333(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2381((x*x+43)%65521,d-1); let b=graph_fn3614((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn334(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2382((x*x+44)%65521,d-1); let b=graph_fn3631((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn335(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2383((x*x+45)%65521,d-1); let b=graph_fn3648((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn336(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2384((x*x+46)%65521,d-1); let b=graph_fn3665((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn337(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2385((x*x+47)%65521,d-1); let b=graph_fn3682((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn338(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2386((x*x+48)%65521,d-1); let b=graph_fn3699((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn339(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2387((x*x+49)%65521,d-1); let b=graph_fn3716((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn340(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2388((x*x+50)%65521,d-1); let b=graph_fn3733((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn341(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2389((x*x+51)%65521,d-1); let b=graph_fn3750((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn342(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2390((x*x+52)%65521,d-1); let b=graph_fn3767((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn343(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2391((x*x+53)%65521,d-1); let b=graph_fn3784((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn344(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2392((x*x+54)%65521,d-1); let b=graph_fn3801((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn345(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2393((x*x+55)%65521,d-1); let b=graph_fn3818((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn346(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2394((x*x+56)%65521,d-1); let b=graph_fn3835((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn347(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2395((x*x+57)%65521,d-1); let b=graph_fn3852((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn348(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2396((x*x+58)%65521,d-1); let b=graph_fn3869((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn349(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2397((x*x+59)%65521,d-1); let b=graph_fn3886((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn350(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2398((x*x+60)%65521,d-1); let b=graph_fn3903((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn351(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2399((x*x+61)%65521,d-1); let b=graph_fn3920((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn352(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2400((x*x+62)%65521,d-1); let b=graph_fn3937((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn353(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2401((x*x+63)%65521,d-1); let b=graph_fn3954((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn354(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2402((x*x+64)%65521,d-1); let b=graph_fn3971((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn355(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2403((x*x+65)%65521,d-1); let b=graph_fn3988((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn356(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2404((x*x+66)%65521,d-1); let b=graph_fn4005((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn357(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2405((x*x+67)%65521,d-1); let b=graph_fn4022((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn358(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2406((x*x+68)%65521,d-1); let b=graph_fn4039((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn359(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2407((x*x+69)%65521,d-1); let b=graph_fn4056((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn360(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2408((x*x+70)%65521,d-1); let b=graph_fn4073((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn361(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2409((x*x+71)%65521,d-1); let b=graph_fn4090((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn362(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2410((x*x+72)%65521,d-1); let b=graph_fn2059((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn363(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2411((x*x+73)%65521,d-1); let b=graph_fn2076((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn364(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2412((x*x+74)%65521,d-1); let b=graph_fn2093((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn365(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2413((x*x+75)%65521,d-1); let b=graph_fn2110((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn366(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2414((x*x+76)%65521,d-1); let b=graph_fn2127((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn367(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2415((x*x+77)%65521,d-1); let b=graph_fn2144((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn368(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2416((x*x+78)%65521,d-1); let b=graph_fn2161((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn369(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2417((x*x+79)%65521,d-1); let b=graph_fn2178((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn370(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2418((x*x+80)%65521,d-1); let b=graph_fn2195((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn371(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2419((x*x+81)%65521,d-1); let b=graph_fn2212((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn372(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2420((x*x+82)%65521,d-1); let b=graph_fn2229((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn373(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2421((x*x+83)%65521,d-1); let b=graph_fn2246((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn374(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2422((x*x+84)%65521,d-1); let b=graph_fn2263((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn375(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2423((x*x+85)%65521,d-1); let b=graph_fn2280((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn376(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2424((x*x+86)%65521,d-1); let b=graph_fn2297((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn377(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2425((x*x+87)%65521,d-1); let b=graph_fn2314((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn378(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2426((x*x+88)%65521,d-1); let b=graph_fn2331((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn379(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2427((x*x+89)%65521,d-1); let b=graph_fn2348((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn380(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2428((x*x+90)%65521,d-1); let b=graph_fn2365((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn381(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2429((x*x+91)%65521,d-1); let b=graph_fn2382((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn382(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2430((x*x+92)%65521,d-1); let b=graph_fn2399((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn383(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2431((x*x+93)%65521,d-1); let b=graph_fn2416((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn384(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2432((x*x+94)%65521,d-1); let b=graph_fn2433((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn385(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2433((x*x+95)%65521,d-1); let b=graph_fn2450((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn386(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2434((x*x+96)%65521,d-1); let b=graph_fn2467((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn387(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2435((x*x+97)%65521,d-1); let b=graph_fn2484((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn388(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2436((x*x+1)%65521,d-1); let b=graph_fn2501((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn389(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2437((x*x+2)%65521,d-1); let b=graph_fn2518((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn390(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2438((x*x+3)%65521,d-1); let b=graph_fn2535((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn391(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2439((x*x+4)%65521,d-1); let b=graph_fn2552((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn392(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2440((x*x+5)%65521,d-1); let b=graph_fn2569((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn393(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2441((x*x+6)%65521,d-1); let b=graph_fn2586((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn394(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2442((x*x+7)%65521,d-1); let b=graph_fn2603((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn395(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2443((x*x+8)%65521,d-1); let b=graph_fn2620((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn396(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2444((x*x+9)%65521,d-1); let b=graph_fn2637((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn397(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2445((x*x+10)%65521,d-1); let b=graph_fn2654((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn398(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2446((x*x+11)%65521,d-1); let b=graph_fn2671((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn399(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2447((x*x+12)%65521,d-1); let b=graph_fn2688((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn400(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2448((x*x+13)%65521,d-1); let b=graph_fn2705((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn401(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2449((x*x+14)%65521,d-1); let b=graph_fn2722((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn402(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2450((x*x+15)%65521,d-1); let b=graph_fn2739((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn403(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2451((x*x+16)%65521,d-1); let b=graph_fn2756((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn404(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2452((x*x+17)%65521,d-1); let b=graph_fn2773((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn405(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2453((x*x+18)%65521,d-1); let b=graph_fn2790((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn406(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2454((x*x+19)%65521,d-1); let b=graph_fn2807((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn407(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2455((x*x+20)%65521,d-1); let b=graph_fn2824((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn408(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2456((x*x+21)%65521,d-1); let b=graph_fn2841((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn409(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2457((x*x+22)%65521,d-1); let b=graph_fn2858((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn410(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2458((x*x+23)%65521,d-1); let b=graph_fn2875((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn411(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2459((x*x+24)%65521,d-1); let b=graph_fn2892((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn412(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2460((x*x+25)%65521,d-1); let b=graph_fn2909((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn413(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2461((x*x+26)%65521,d-1); let b=graph_fn2926((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn414(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2462((x*x+27)%65521,d-1); let b=graph_fn2943((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn415(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2463((x*x+28)%65521,d-1); let b=graph_fn2960((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn416(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2464((x*x+29)%65521,d-1); let b=graph_fn2977((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn417(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2465((x*x+30)%65521,d-1); let b=graph_fn2994((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn418(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2466((x*x+31)%65521,d-1); let b=graph_fn3011((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn419(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2467((x*x+32)%65521,d-1); let b=graph_fn3028((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn420(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2468((x*x+33)%65521,d-1); let b=graph_fn3045((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn421(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2469((x*x+34)%65521,d-1); let b=graph_fn3062((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn422(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2470((x*x+35)%65521,d-1); let b=graph_fn3079((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn423(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2471((x*x+36)%65521,d-1); let b=graph_fn3096((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn424(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2472((x*x+37)%65521,d-1); let b=graph_fn3113((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn425(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2473((x*x+38)%65521,d-1); let b=graph_fn3130((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn426(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2474((x*x+39)%65521,d-1); let b=graph_fn3147((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn427(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2475((x*x+40)%65521,d-1); let b=graph_fn3164((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn428(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2476((x*x+41)%65521,d-1); let b=graph_fn3181((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn429(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2477((x*x+42)%65521,d-1); let b=graph_fn3198((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn430(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2478((x*x+43)%65521,d-1); let b=graph_fn3215((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn431(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2479((x*x+44)%65521,d-1); let b=graph_fn3232((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn432(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2480((x*x+45)%65521,d-1); let b=graph_fn3249((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn433(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2481((x*x+46)%65521,d-1); let b=graph_fn3266((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn434(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2482((x*x+47)%65521,d-1); let b=graph_fn3283((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn435(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2483((x*x+48)%65521,d-1); let b=graph_fn3300((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn436(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2484((x*x+49)%65521,d-1); let b=graph_fn3317((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn437(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2485((x*x+50)%65521,d-1); let b=graph_fn3334((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn438(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2486((x*x+51)%65521,d-1); let b=graph_fn3351((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn439(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2487((x*x+52)%65521,d-1); let b=graph_fn3368((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn440(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2488((x*x+53)%65521,d-1); let b=graph_fn3385((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn441(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2489((x*x+54)%65521,d-1); let b=graph_fn3402((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn442(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2490((x*x+55)%65521,d-1); let b=graph_fn3419((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn443(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2491((x*x+56)%65521,d-1); let b=graph_fn3436((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn444(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2492((x*x+57)%65521,d-1); let b=graph_fn3453((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn445(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2493((x*x+58)%65521,d-1); let b=graph_fn3470((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn446(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2494((x*x+59)%65521,d-1); let b=graph_fn3487((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn447(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2495((x*x+60)%65521,d-1); let b=graph_fn3504((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn448(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2496((x*x+61)%65521,d-1); let b=graph_fn3521((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn449(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2497((x*x+62)%65521,d-1); let b=graph_fn3538((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn450(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2498((x*x+63)%65521,d-1); let b=graph_fn3555((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn451(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2499((x*x+64)%65521,d-1); let b=graph_fn3572((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn452(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2500((x*x+65)%65521,d-1); let b=graph_fn3589((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn453(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2501((x*x+66)%65521,d-1); let b=graph_fn3606((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn454(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2502((x*x+67)%65521,d-1); let b=graph_fn3623((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn455(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2503((x*x+68)%65521,d-1); let b=graph_fn3640((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn456(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2504((x*x+69)%65521,d-1); let b=graph_fn3657((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn457(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2505((x*x+70)%65521,d-1); let b=graph_fn3674((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn458(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2506((x*x+71)%65521,d-1); let b=graph_fn3691((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn459(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2507((x*x+72)%65521,d-1); let b=graph_fn3708((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn460(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2508((x*x+73)%65521,d-1); let b=graph_fn3725((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn461(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2509((x*x+74)%65521,d-1); let b=graph_fn3742((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn462(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2510((x*x+75)%65521,d-1); let b=graph_fn3759((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn463(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2511((x*x+76)%65521,d-1); let b=graph_fn3776((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn464(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2512((x*x+77)%65521,d-1); let b=graph_fn3793((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn465(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2513((x*x+78)%65521,d-1); let b=graph_fn3810((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn466(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2514((x*x+79)%65521,d-1); let b=graph_fn3827((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn467(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2515((x*x+80)%65521,d-1); let b=graph_fn3844((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn468(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2516((x*x+81)%65521,d-1); let b=graph_fn3861((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn469(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2517((x*x+82)%65521,d-1); let b=graph_fn3878((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn470(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2518((x*x+83)%65521,d-1); let b=graph_fn3895((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn471(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2519((x*x+84)%65521,d-1); let b=graph_fn3912((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn472(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2520((x*x+85)%65521,d-1); let b=graph_fn3929((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn473(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2521((x*x+86)%65521,d-1); let b=graph_fn3946((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn474(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2522((x*x+87)%65521,d-1); let b=graph_fn3963((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn475(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2523((x*x+88)%65521,d-1); let b=graph_fn3980((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn476(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2524((x*x+89)%65521,d-1); let b=graph_fn3997((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn477(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2525((x*x+90)%65521,d-1); let b=graph_fn4014((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn478(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2526((x*x+91)%65521,d-1); let b=graph_fn4031((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn479(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2527((x*x+92)%65521,d-1); let b=graph_fn4048((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn480(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2528((x*x+93)%65521,d-1); let b=graph_fn4065((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn481(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2529((x*x+94)%65521,d-1); let b=graph_fn4082((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn482(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2530((x*x+95)%65521,d-1); let b=graph_fn2051((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn483(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2531((x*x+96)%65521,d-1); let b=graph_fn2068((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn484(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2532((x*x+97)%65521,d-1); let b=graph_fn2085((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn485(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2533((x*x+1)%65521,d-1); let b=graph_fn2102((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn486(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2534((x*x+2)%65521,d-1); let b=graph_fn2119((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn487(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2535((x*x+3)%65521,d-1); let b=graph_fn2136((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn488(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2536((x*x+4)%65521,d-1); let b=graph_fn2153((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn489(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2537((x*x+5)%65521,d-1); let b=graph_fn2170((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn490(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2538((x*x+6)%65521,d-1); let b=graph_fn2187((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn491(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2539((x*x+7)%65521,d-1); let b=graph_fn2204((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn492(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2540((x*x+8)%65521,d-1); let b=graph_fn2221((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn493(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2541((x*x+9)%65521,d-1); let b=graph_fn2238((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn494(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2542((x*x+10)%65521,d-1); let b=graph_fn2255((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn495(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2543((x*x+11)%65521,d-1); let b=graph_fn2272((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn496(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2544((x*x+12)%65521,d-1); let b=graph_fn2289((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn497(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2545((x*x+13)%65521,d-1); let b=graph_fn2306((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn498(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2546((x*x+14)%65521,d-1); let b=graph_fn2323((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn499(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2547((x*x+15)%65521,d-1); let b=graph_fn2340((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn500(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2548((x*x+16)%65521,d-1); let b=graph_fn2357((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn501(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2549((x*x+17)%65521,d-1); let b=graph_fn2374((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn502(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2550((x*x+18)%65521,d-1); let b=graph_fn2391((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn503(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2551((x*x+19)%65521,d-1); let b=graph_fn2408((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn504(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2552((x*x+20)%65521,d-1); let b=graph_fn2425((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn505(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2553((x*x+21)%65521,d-1); let b=graph_fn2442((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn506(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2554((x*x+22)%65521,d-1); let b=graph_fn2459((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn507(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2555((x*x+23)%65521,d-1); let b=graph_fn2476((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn508(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2556((x*x+24)%65521,d-1); let b=graph_fn2493((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn509(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2557((x*x+25)%65521,d-1); let b=graph_fn2510((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn510(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2558((x*x+26)%65521,d-1); let b=graph_fn2527((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn511(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2559((x*x+27)%65521,d-1); let b=graph_fn2544((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn512(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2560((x*x+28)%65521,d-1); let b=graph_fn2561((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn513(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2561((x*x+29)%65521,d-1); let b=graph_fn2578((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn514(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2562((x*x+30)%65521,d-1); let b=graph_fn2595((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn515(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2563((x*x+31)%65521,d-1); let b=graph_fn2612((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn516(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2564((x*x+32)%65521,d-1); let b=graph_fn2629((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn517(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2565((x*x+33)%65521,d-1); let b=graph_fn2646((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn518(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2566((x*x+34)%65521,d-1); let b=graph_fn2663((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn519(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2567((x*x+35)%65521,d-1); let b=graph_fn2680((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn520(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2568((x*x+36)%65521,d-1); let b=graph_fn2697((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn521(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2569((x*x+37)%65521,d-1); let b=graph_fn2714((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn522(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2570((x*x+38)%65521,d-1); let b=graph_fn2731((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn523(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2571((x*x+39)%65521,d-1); let b=graph_fn2748((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn524(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2572((x*x+40)%65521,d-1); let b=graph_fn2765((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn525(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2573((x*x+41)%65521,d-1); let b=graph_fn2782((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn526(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2574((x*x+42)%65521,d-1); let b=graph_fn2799((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn527(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2575((x*x+43)%65521,d-1); let b=graph_fn2816((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn528(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2576((x*x+44)%65521,d-1); let b=graph_fn2833((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn529(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2577((x*x+45)%65521,d-1); let b=graph_fn2850((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn530(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2578((x*x+46)%65521,d-1); let b=graph_fn2867((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn531(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2579((x*x+47)%65521,d-1); let b=graph_fn2884((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn532(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2580((x*x+48)%65521,d-1); let b=graph_fn2901((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn533(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2581((x*x+49)%65521,d-1); let b=graph_fn2918((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn534(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2582((x*x+50)%65521,d-1); let b=graph_fn2935((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn535(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2583((x*x+51)%65521,d-1); let b=graph_fn2952((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn536(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2584((x*x+52)%65521,d-1); let b=graph_fn2969((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn537(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2585((x*x+53)%65521,d-1); let b=graph_fn2986((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn538(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2586((x*x+54)%65521,d-1); let b=graph_fn3003((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn539(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2587((x*x+55)%65521,d-1); let b=graph_fn3020((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn540(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2588((x*x+56)%65521,d-1); let b=graph_fn3037((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn541(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2589((x*x+57)%65521,d-1); let b=graph_fn3054((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn542(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2590((x*x+58)%65521,d-1); let b=graph_fn3071((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn543(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2591((x*x+59)%65521,d-1); let b=graph_fn3088((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn544(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2592((x*x+60)%65521,d-1); let b=graph_fn3105((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn545(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2593((x*x+61)%65521,d-1); let b=graph_fn3122((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn546(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2594((x*x+62)%65521,d-1); let b=graph_fn3139((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn547(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2595((x*x+63)%65521,d-1); let b=graph_fn3156((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn548(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2596((x*x+64)%65521,d-1); let b=graph_fn3173((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn549(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2597((x*x+65)%65521,d-1); let b=graph_fn3190((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn550(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2598((x*x+66)%65521,d-1); let b=graph_fn3207((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn551(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2599((x*x+67)%65521,d-1); let b=graph_fn3224((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn552(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2600((x*x+68)%65521,d-1); let b=graph_fn3241((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn553(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2601((x*x+69)%65521,d-1); let b=graph_fn3258((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn554(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2602((x*x+70)%65521,d-1); let b=graph_fn3275((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn555(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2603((x*x+71)%65521,d-1); let b=graph_fn3292((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn556(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2604((x*x+72)%65521,d-1); let b=graph_fn3309((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn557(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2605((x*x+73)%65521,d-1); let b=graph_fn3326((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn558(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2606((x*x+74)%65521,d-1); let b=graph_fn3343((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn559(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2607((x*x+75)%65521,d-1); let b=graph_fn3360((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn560(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2608((x*x+76)%65521,d-1); let b=graph_fn3377((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn561(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2609((x*x+77)%65521,d-1); let b=graph_fn3394((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn562(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2610((x*x+78)%65521,d-1); let b=graph_fn3411((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn563(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2611((x*x+79)%65521,d-1); let b=graph_fn3428((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn564(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2612((x*x+80)%65521,d-1); let b=graph_fn3445((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn565(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2613((x*x+81)%65521,d-1); let b=graph_fn3462((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn566(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2614((x*x+82)%65521,d-1); let b=graph_fn3479((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn567(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2615((x*x+83)%65521,d-1); let b=graph_fn3496((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn568(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2616((x*x+84)%65521,d-1); let b=graph_fn3513((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn569(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2617((x*x+85)%65521,d-1); let b=graph_fn3530((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn570(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2618((x*x+86)%65521,d-1); let b=graph_fn3547((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn571(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2619((x*x+87)%65521,d-1); let b=graph_fn3564((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn572(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2620((x*x+88)%65521,d-1); let b=graph_fn3581((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn573(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2621((x*x+89)%65521,d-1); let b=graph_fn3598((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn574(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2622((x*x+90)%65521,d-1); let b=graph_fn3615((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn575(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2623((x*x+91)%65521,d-1); let b=graph_fn3632((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn576(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2624((x*x+92)%65521,d-1); let b=graph_fn3649((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn577(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2625((x*x+93)%65521,d-1); let b=graph_fn3666((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn578(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2626((x*x+94)%65521,d-1); let b=graph_fn3683((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn579(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2627((x*x+95)%65521,d-1); let b=graph_fn3700((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn580(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2628((x*x+96)%65521,d-1); let b=graph_fn3717((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn581(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2629((x*x+97)%65521,d-1); let b=graph_fn3734((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn582(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2630((x*x+1)%65521,d-1); let b=graph_fn3751((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn583(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2631((x*x+2)%65521,d-1); let b=graph_fn3768((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn584(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2632((x*x+3)%65521,d-1); let b=graph_fn3785((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn585(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2633((x*x+4)%65521,d-1); let b=graph_fn3802((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn586(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2634((x*x+5)%65521,d-1); let b=graph_fn3819((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn587(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2635((x*x+6)%65521,d-1); let b=graph_fn3836((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn588(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2636((x*x+7)%65521,d-1); let b=graph_fn3853((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn589(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2637((x*x+8)%65521,d-1); let b=graph_fn3870((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn590(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2638((x*x+9)%65521,d-1); let b=graph_fn3887((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn591(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2639((x*x+10)%65521,d-1); let b=graph_fn3904((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn592(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2640((x*x+11)%65521,d-1); let b=graph_fn3921((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn593(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2641((x*x+12)%65521,d-1); let b=graph_fn3938((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn594(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2642((x*x+13)%65521,d-1); let b=graph_fn3955((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn595(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2643((x*x+14)%65521,d-1); let b=graph_fn3972((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn596(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2644((x*x+15)%65521,d-1); let b=graph_fn3989((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn597(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2645((x*x+16)%65521,d-1); let b=graph_fn4006((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn598(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2646((x*x+17)%65521,d-1); let b=graph_fn4023((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn599(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2647((x*x+18)%65521,d-1); let b=graph_fn4040((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn600(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2648((x*x+19)%65521,d-1); let b=graph_fn4057((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn601(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2649((x*x+20)%65521,d-1); let b=graph_fn4074((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn602(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2650((x*x+21)%65521,d-1); let b=graph_fn4091((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn603(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2651((x*x+22)%65521,d-1); let b=graph_fn2060((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn604(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2652((x*x+23)%65521,d-1); let b=graph_fn2077((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn605(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2653((x*x+24)%65521,d-1); let b=graph_fn2094((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn606(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2654((x*x+25)%65521,d-1); let b=graph_fn2111((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn607(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2655((x*x+26)%65521,d-1); let b=graph_fn2128((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn608(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2656((x*x+27)%65521,d-1); let b=graph_fn2145((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn609(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2657((x*x+28)%65521,d-1); let b=graph_fn2162((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn610(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2658((x*x+29)%65521,d-1); let b=graph_fn2179((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn611(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2659((x*x+30)%65521,d-1); let b=graph_fn2196((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn612(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2660((x*x+31)%65521,d-1); let b=graph_fn2213((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn613(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2661((x*x+32)%65521,d-1); let b=graph_fn2230((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn614(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2662((x*x+33)%65521,d-1); let b=graph_fn2247((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn615(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2663((x*x+34)%65521,d-1); let b=graph_fn2264((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn616(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2664((x*x+35)%65521,d-1); let b=graph_fn2281((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn617(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2665((x*x+36)%65521,d-1); let b=graph_fn2298((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn618(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2666((x*x+37)%65521,d-1); let b=graph_fn2315((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn619(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2667((x*x+38)%65521,d-1); let b=graph_fn2332((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn620(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2668((x*x+39)%65521,d-1); let b=graph_fn2349((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn621(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2669((x*x+40)%65521,d-1); let b=graph_fn2366((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn622(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2670((x*x+41)%65521,d-1); let b=graph_fn2383((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn623(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2671((x*x+42)%65521,d-1); let b=graph_fn2400((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn624(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2672((x*x+43)%65521,d-1); let b=graph_fn2417((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn625(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2673((x*x+44)%65521,d-1); let b=graph_fn2434((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn626(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2674((x*x+45)%65521,d-1); let b=graph_fn2451((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn627(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2675((x*x+46)%65521,d-1); let b=graph_fn2468((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn628(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2676((x*x+47)%65521,d-1); let b=graph_fn2485((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn629(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2677((x*x+48)%65521,d-1); let b=graph_fn2502((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn630(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2678((x*x+49)%65521,d-1); let b=graph_fn2519((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn631(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2679((x*x+50)%65521,d-1); let b=graph_fn2536((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn632(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2680((x*x+51)%65521,d-1); let b=graph_fn2553((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn633(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2681((x*x+52)%65521,d-1); let b=graph_fn2570((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn634(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2682((x*x+53)%65521,d-1); let b=graph_fn2587((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn635(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2683((x*x+54)%65521,d-1); let b=graph_fn2604((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn636(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2684((x*x+55)%65521,d-1); let b=graph_fn2621((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn637(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2685((x*x+56)%65521,d-1); let b=graph_fn2638((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn638(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2686((x*x+57)%65521,d-1); let b=graph_fn2655((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn639(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2687((x*x+58)%65521,d-1); let b=graph_fn2672((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn640(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2688((x*x+59)%65521,d-1); let b=graph_fn2689((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn641(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2689((x*x+60)%65521,d-1); let b=graph_fn2706((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn642(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2690((x*x+61)%65521,d-1); let b=graph_fn2723((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn643(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2691((x*x+62)%65521,d-1); let b=graph_fn2740((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn644(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2692((x*x+63)%65521,d-1); let b=graph_fn2757((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn645(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2693((x*x+64)%65521,d-1); let b=graph_fn2774((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn646(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2694((x*x+65)%65521,d-1); let b=graph_fn2791((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn647(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2695((x*x+66)%65521,d-1); let b=graph_fn2808((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn648(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2696((x*x+67)%65521,d-1); let b=graph_fn2825((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn649(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2697((x*x+68)%65521,d-1); let b=graph_fn2842((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn650(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2698((x*x+69)%65521,d-1); let b=graph_fn2859((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn651(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2699((x*x+70)%65521,d-1); let b=graph_fn2876((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn652(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2700((x*x+71)%65521,d-1); let b=graph_fn2893((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn653(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2701((x*x+72)%65521,d-1); let b=graph_fn2910((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn654(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2702((x*x+73)%65521,d-1); let b=graph_fn2927((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn655(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2703((x*x+74)%65521,d-1); let b=graph_fn2944((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn656(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2704((x*x+75)%65521,d-1); let b=graph_fn2961((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn657(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2705((x*x+76)%65521,d-1); let b=graph_fn2978((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn658(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2706((x*x+77)%65521,d-1); let b=graph_fn2995((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn659(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2707((x*x+78)%65521,d-1); let b=graph_fn3012((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn660(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2708((x*x+79)%65521,d-1); let b=graph_fn3029((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn661(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2709((x*x+80)%65521,d-1); let b=graph_fn3046((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn662(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2710((x*x+81)%65521,d-1); let b=graph_fn3063((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn663(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2711((x*x+82)%65521,d-1); let b=graph_fn3080((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn664(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2712((x*x+83)%65521,d-1); let b=graph_fn3097((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn665(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2713((x*x+84)%65521,d-1); let b=graph_fn3114((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn666(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2714((x*x+85)%65521,d-1); let b=graph_fn3131((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn667(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2715((x*x+86)%65521,d-1); let b=graph_fn3148((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn668(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2716((x*x+87)%65521,d-1); let b=graph_fn3165((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn669(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2717((x*x+88)%65521,d-1); let b=graph_fn3182((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn670(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2718((x*x+89)%65521,d-1); let b=graph_fn3199((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn671(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2719((x*x+90)%65521,d-1); let b=graph_fn3216((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn672(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2720((x*x+91)%65521,d-1); let b=graph_fn3233((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn673(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2721((x*x+92)%65521,d-1); let b=graph_fn3250((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn674(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2722((x*x+93)%65521,d-1); let b=graph_fn3267((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn675(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2723((x*x+94)%65521,d-1); let b=graph_fn3284((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn676(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2724((x*x+95)%65521,d-1); let b=graph_fn3301((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn677(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2725((x*x+96)%65521,d-1); let b=graph_fn3318((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn678(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2726((x*x+97)%65521,d-1); let b=graph_fn3335((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn679(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2727((x*x+1)%65521,d-1); let b=graph_fn3352((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn680(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2728((x*x+2)%65521,d-1); let b=graph_fn3369((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn681(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2729((x*x+3)%65521,d-1); let b=graph_fn3386((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn682(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2730((x*x+4)%65521,d-1); let b=graph_fn3403((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn683(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2731((x*x+5)%65521,d-1); let b=graph_fn3420((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn684(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2732((x*x+6)%65521,d-1); let b=graph_fn3437((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn685(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2733((x*x+7)%65521,d-1); let b=graph_fn3454((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn686(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2734((x*x+8)%65521,d-1); let b=graph_fn3471((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn687(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2735((x*x+9)%65521,d-1); let b=graph_fn3488((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn688(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2736((x*x+10)%65521,d-1); let b=graph_fn3505((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn689(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2737((x*x+11)%65521,d-1); let b=graph_fn3522((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn690(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2738((x*x+12)%65521,d-1); let b=graph_fn3539((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn691(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2739((x*x+13)%65521,d-1); let b=graph_fn3556((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn692(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2740((x*x+14)%65521,d-1); let b=graph_fn3573((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn693(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2741((x*x+15)%65521,d-1); let b=graph_fn3590((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn694(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2742((x*x+16)%65521,d-1); let b=graph_fn3607((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn695(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2743((x*x+17)%65521,d-1); let b=graph_fn3624((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn696(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2744((x*x+18)%65521,d-1); let b=graph_fn3641((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn697(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2745((x*x+19)%65521,d-1); let b=graph_fn3658((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn698(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2746((x*x+20)%65521,d-1); let b=graph_fn3675((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn699(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2747((x*x+21)%65521,d-1); let b=graph_fn3692((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn700(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2748((x*x+22)%65521,d-1); let b=graph_fn3709((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn701(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2749((x*x+23)%65521,d-1); let b=graph_fn3726((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn702(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2750((x*x+24)%65521,d-1); let b=graph_fn3743((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn703(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2751((x*x+25)%65521,d-1); let b=graph_fn3760((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn704(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2752((x*x+26)%65521,d-1); let b=graph_fn3777((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn705(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2753((x*x+27)%65521,d-1); let b=graph_fn3794((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn706(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2754((x*x+28)%65521,d-1); let b=graph_fn3811((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn707(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2755((x*x+29)%65521,d-1); let b=graph_fn3828((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn708(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2756((x*x+30)%65521,d-1); let b=graph_fn3845((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn709(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2757((x*x+31)%65521,d-1); let b=graph_fn3862((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn710(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2758((x*x+32)%65521,d-1); let b=graph_fn3879((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn711(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2759((x*x+33)%65521,d-1); let b=graph_fn3896((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn712(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2760((x*x+34)%65521,d-1); let b=graph_fn3913((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn713(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2761((x*x+35)%65521,d-1); let b=graph_fn3930((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn714(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2762((x*x+36)%65521,d-1); let b=graph_fn3947((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn715(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2763((x*x+37)%65521,d-1); let b=graph_fn3964((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn716(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2764((x*x+38)%65521,d-1); let b=graph_fn3981((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn717(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2765((x*x+39)%65521,d-1); let b=graph_fn3998((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn718(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2766((x*x+40)%65521,d-1); let b=graph_fn4015((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn719(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2767((x*x+41)%65521,d-1); let b=graph_fn4032((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn720(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2768((x*x+42)%65521,d-1); let b=graph_fn4049((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn721(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2769((x*x+43)%65521,d-1); let b=graph_fn4066((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn722(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2770((x*x+44)%65521,d-1); let b=graph_fn4083((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn723(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2771((x*x+45)%65521,d-1); let b=graph_fn2052((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn724(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2772((x*x+46)%65521,d-1); let b=graph_fn2069((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn725(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2773((x*x+47)%65521,d-1); let b=graph_fn2086((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn726(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2774((x*x+48)%65521,d-1); let b=graph_fn2103((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn727(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2775((x*x+49)%65521,d-1); let b=graph_fn2120((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn728(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2776((x*x+50)%65521,d-1); let b=graph_fn2137((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn729(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2777((x*x+51)%65521,d-1); let b=graph_fn2154((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn730(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2778((x*x+52)%65521,d-1); let b=graph_fn2171((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn731(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2779((x*x+53)%65521,d-1); let b=graph_fn2188((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn732(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2780((x*x+54)%65521,d-1); let b=graph_fn2205((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn733(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2781((x*x+55)%65521,d-1); let b=graph_fn2222((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn734(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2782((x*x+56)%65521,d-1); let b=graph_fn2239((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn735(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2783((x*x+57)%65521,d-1); let b=graph_fn2256((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn736(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2784((x*x+58)%65521,d-1); let b=graph_fn2273((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn737(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2785((x*x+59)%65521,d-1); let b=graph_fn2290((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn738(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2786((x*x+60)%65521,d-1); let b=graph_fn2307((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn739(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2787((x*x+61)%65521,d-1); let b=graph_fn2324((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn740(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2788((x*x+62)%65521,d-1); let b=graph_fn2341((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn741(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2789((x*x+63)%65521,d-1); let b=graph_fn2358((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn742(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2790((x*x+64)%65521,d-1); let b=graph_fn2375((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn743(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2791((x*x+65)%65521,d-1); let b=graph_fn2392((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn744(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2792((x*x+66)%65521,d-1); let b=graph_fn2409((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn745(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2793((x*x+67)%65521,d-1); let b=graph_fn2426((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn746(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2794((x*x+68)%65521,d-1); let b=graph_fn2443((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn747(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2795((x*x+69)%65521,d-1); let b=graph_fn2460((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn748(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2796((x*x+70)%65521,d-1); let b=graph_fn2477((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn749(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2797((x*x+71)%65521,d-1); let b=graph_fn2494((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn750(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2798((x*x+72)%65521,d-1); let b=graph_fn2511((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn751(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2799((x*x+73)%65521,d-1); let b=graph_fn2528((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn752(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2800((x*x+74)%65521,d-1); let b=graph_fn2545((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn753(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2801((x*x+75)%65521,d-1); let b=graph_fn2562((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn754(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2802((x*x+76)%65521,d-1); let b=graph_fn2579((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn755(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2803((x*x+77)%65521,d-1); let b=graph_fn2596((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn756(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2804((x*x+78)%65521,d-1); let b=graph_fn2613((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn757(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2805((x*x+79)%65521,d-1); let b=graph_fn2630((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn758(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2806((x*x+80)%65521,d-1); let b=graph_fn2647((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn759(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2807((x*x+81)%65521,d-1); let b=graph_fn2664((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn760(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2808((x*x+82)%65521,d-1); let b=graph_fn2681((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn761(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2809((x*x+83)%65521,d-1); let b=graph_fn2698((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn762(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2810((x*x+84)%65521,d-1); let b=graph_fn2715((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn763(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2811((x*x+85)%65521,d-1); let b=graph_fn2732((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn764(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2812((x*x+86)%65521,d-1); let b=graph_fn2749((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn765(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2813((x*x+87)%65521,d-1); let b=graph_fn2766((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn766(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2814((x*x+88)%65521,d-1); let b=graph_fn2783((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn767(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2815((x*x+89)%65521,d-1); let b=graph_fn2800((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn768(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2816((x*x+90)%65521,d-1); let b=graph_fn2817((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn769(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2817((x*x+91)%65521,d-1); let b=graph_fn2834((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn770(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2818((x*x+92)%65521,d-1); let b=graph_fn2851((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn771(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2819((x*x+93)%65521,d-1); let b=graph_fn2868((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn772(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2820((x*x+94)%65521,d-1); let b=graph_fn2885((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn773(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2821((x*x+95)%65521,d-1); let b=graph_fn2902((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn774(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2822((x*x+96)%65521,d-1); let b=graph_fn2919((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn775(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2823((x*x+97)%65521,d-1); let b=graph_fn2936((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn776(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2824((x*x+1)%65521,d-1); let b=graph_fn2953((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn777(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2825((x*x+2)%65521,d-1); let b=graph_fn2970((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn778(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2826((x*x+3)%65521,d-1); let b=graph_fn2987((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn779(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2827((x*x+4)%65521,d-1); let b=graph_fn3004((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn780(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2828((x*x+5)%65521,d-1); let b=graph_fn3021((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn781(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2829((x*x+6)%65521,d-1); let b=graph_fn3038((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn782(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2830((x*x+7)%65521,d-1); let b=graph_fn3055((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn783(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2831((x*x+8)%65521,d-1); let b=graph_fn3072((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn784(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2832((x*x+9)%65521,d-1); let b=graph_fn3089((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn785(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2833((x*x+10)%65521,d-1); let b=graph_fn3106((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn786(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2834((x*x+11)%65521,d-1); let b=graph_fn3123((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn787(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2835((x*x+12)%65521,d-1); let b=graph_fn3140((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn788(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2836((x*x+13)%65521,d-1); let b=graph_fn3157((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn789(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2837((x*x+14)%65521,d-1); let b=graph_fn3174((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn790(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2838((x*x+15)%65521,d-1); let b=graph_fn3191((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn791(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2839((x*x+16)%65521,d-1); let b=graph_fn3208((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn792(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2840((x*x+17)%65521,d-1); let b=graph_fn3225((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn793(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2841((x*x+18)%65521,d-1); let b=graph_fn3242((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn794(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2842((x*x+19)%65521,d-1); let b=graph_fn3259((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn795(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2843((x*x+20)%65521,d-1); let b=graph_fn3276((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn796(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2844((x*x+21)%65521,d-1); let b=graph_fn3293((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn797(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2845((x*x+22)%65521,d-1); let b=graph_fn3310((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn798(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2846((x*x+23)%65521,d-1); let b=graph_fn3327((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn799(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2847((x*x+24)%65521,d-1); let b=graph_fn3344((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn800(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2848((x*x+25)%65521,d-1); let b=graph_fn3361((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn801(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2849((x*x+26)%65521,d-1); let b=graph_fn3378((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn802(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2850((x*x+27)%65521,d-1); let b=graph_fn3395((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn803(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2851((x*x+28)%65521,d-1); let b=graph_fn3412((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn804(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2852((x*x+29)%65521,d-1); let b=graph_fn3429((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn805(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2853((x*x+30)%65521,d-1); let b=graph_fn3446((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn806(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2854((x*x+31)%65521,d-1); let b=graph_fn3463((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn807(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2855((x*x+32)%65521,d-1); let b=graph_fn3480((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn808(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2856((x*x+33)%65521,d-1); let b=graph_fn3497((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn809(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2857((x*x+34)%65521,d-1); let b=graph_fn3514((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn810(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2858((x*x+35)%65521,d-1); let b=graph_fn3531((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn811(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2859((x*x+36)%65521,d-1); let b=graph_fn3548((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn812(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2860((x*x+37)%65521,d-1); let b=graph_fn3565((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn813(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2861((x*x+38)%65521,d-1); let b=graph_fn3582((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn814(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2862((x*x+39)%65521,d-1); let b=graph_fn3599((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn815(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2863((x*x+40)%65521,d-1); let b=graph_fn3616((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn816(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2864((x*x+41)%65521,d-1); let b=graph_fn3633((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn817(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2865((x*x+42)%65521,d-1); let b=graph_fn3650((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn818(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2866((x*x+43)%65521,d-1); let b=graph_fn3667((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn819(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2867((x*x+44)%65521,d-1); let b=graph_fn3684((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn820(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2868((x*x+45)%65521,d-1); let b=graph_fn3701((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn821(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2869((x*x+46)%65521,d-1); let b=graph_fn3718((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn822(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2870((x*x+47)%65521,d-1); let b=graph_fn3735((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn823(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2871((x*x+48)%65521,d-1); let b=graph_fn3752((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn824(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2872((x*x+49)%65521,d-1); let b=graph_fn3769((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn825(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2873((x*x+50)%65521,d-1); let b=graph_fn3786((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn826(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2874((x*x+51)%65521,d-1); let b=graph_fn3803((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn827(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2875((x*x+52)%65521,d-1); let b=graph_fn3820((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn828(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2876((x*x+53)%65521,d-1); let b=graph_fn3837((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn829(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2877((x*x+54)%65521,d-1); let b=graph_fn3854((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn830(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2878((x*x+55)%65521,d-1); let b=graph_fn3871((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn831(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2879((x*x+56)%65521,d-1); let b=graph_fn3888((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn832(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2880((x*x+57)%65521,d-1); let b=graph_fn3905((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn833(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2881((x*x+58)%65521,d-1); let b=graph_fn3922((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn834(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2882((x*x+59)%65521,d-1); let b=graph_fn3939((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn835(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2883((x*x+60)%65521,d-1); let b=graph_fn3956((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn836(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2884((x*x+61)%65521,d-1); let b=graph_fn3973((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn837(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2885((x*x+62)%65521,d-1); let b=graph_fn3990((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn838(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2886((x*x+63)%65521,d-1); let b=graph_fn4007((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn839(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2887((x*x+64)%65521,d-1); let b=graph_fn4024((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn840(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2888((x*x+65)%65521,d-1); let b=graph_fn4041((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn841(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2889((x*x+66)%65521,d-1); let b=graph_fn4058((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn842(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2890((x*x+67)%65521,d-1); let b=graph_fn4075((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn843(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2891((x*x+68)%65521,d-1); let b=graph_fn4092((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn844(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2892((x*x+69)%65521,d-1); let b=graph_fn2061((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn845(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2893((x*x+70)%65521,d-1); let b=graph_fn2078((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn846(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2894((x*x+71)%65521,d-1); let b=graph_fn2095((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn847(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2895((x*x+72)%65521,d-1); let b=graph_fn2112((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn848(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2896((x*x+73)%65521,d-1); let b=graph_fn2129((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn849(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2897((x*x+74)%65521,d-1); let b=graph_fn2146((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn850(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2898((x*x+75)%65521,d-1); let b=graph_fn2163((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn851(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2899((x*x+76)%65521,d-1); let b=graph_fn2180((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn852(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2900((x*x+77)%65521,d-1); let b=graph_fn2197((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn853(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2901((x*x+78)%65521,d-1); let b=graph_fn2214((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn854(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2902((x*x+79)%65521,d-1); let b=graph_fn2231((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn855(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn2903((x*x+80)%65521,d-1); let b=graph_fn2248((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn856(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn2904((x*x+81)%65521,d-1); let b=graph_fn2265((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn857(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn2905((x*x+82)%65521,d-1); let b=graph_fn2282((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn858(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn2906((x*x+83)%65521,d-1); let b=graph_fn2299((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn859(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn2907((x*x+84)%65521,d-1); let b=graph_fn2316((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn860(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn2908((x*x+85)%65521,d-1); let b=graph_fn2333((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn861(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn2909((x*x+86)%65521,d-1); let b=graph_fn2350((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn862(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn2910((x*x+87)%65521,d-1); let b=graph_fn2367((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn863(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn2911((x*x+88)%65521,d-1); let b=graph_fn2384((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn864(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn2912((x*x+89)%65521,d-1); let b=graph_fn2401((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn865(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn2913((x*x+90)%65521,d-1); let b=graph_fn2418((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn866(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn2914((x*x+91)%65521,d-1); let b=graph_fn2435((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn867(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn2915((x*x+92)%65521,d-1); let b=graph_fn2452((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn868(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn2916((x*x+93)%65521,d-1); let b=graph_fn2469((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn869(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn2917((x*x+94)%65521,d-1); let b=graph_fn2486((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn870(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn2918((x*x+95)%65521,d-1); let b=graph_fn2503((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn871(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn2919((x*x+96)%65521,d-1); let b=graph_fn2520((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn872(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn2920((x*x+97)%65521,d-1); let b=graph_fn2537((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn873(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn2921((x*x+1)%65521,d-1); let b=graph_fn2554((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn874(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn2922((x*x+2)%65521,d-1); let b=graph_fn2571((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn875(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn2923((x*x+3)%65521,d-1); let b=graph_fn2588((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn876(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn2924((x*x+4)%65521,d-1); let b=graph_fn2605((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn877(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn2925((x*x+5)%65521,d-1); let b=graph_fn2622((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn878(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn2926((x*x+6)%65521,d-1); let b=graph_fn2639((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn879(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn2927((x*x+7)%65521,d-1); let b=graph_fn2656((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn880(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn2928((x*x+8)%65521,d-1); let b=graph_fn2673((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn881(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn2929((x*x+9)%65521,d-1); let b=graph_fn2690((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn882(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn2930((x*x+10)%65521,d-1); let b=graph_fn2707((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn883(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn2931((x*x+11)%65521,d-1); let b=graph_fn2724((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn884(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn2932((x*x+12)%65521,d-1); let b=graph_fn2741((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn885(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn2933((x*x+13)%65521,d-1); let b=graph_fn2758((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn886(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn2934((x*x+14)%65521,d-1); let b=graph_fn2775((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn887(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn2935((x*x+15)%65521,d-1); let b=graph_fn2792((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn888(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn2936((x*x+16)%65521,d-1); let b=graph_fn2809((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn889(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn2937((x*x+17)%65521,d-1); let b=graph_fn2826((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn890(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn2938((x*x+18)%65521,d-1); let b=graph_fn2843((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn891(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn2939((x*x+19)%65521,d-1); let b=graph_fn2860((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn892(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn2940((x*x+20)%65521,d-1); let b=graph_fn2877((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn893(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn2941((x*x+21)%65521,d-1); let b=graph_fn2894((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn894(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn2942((x*x+22)%65521,d-1); let b=graph_fn2911((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn895(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn2943((x*x+23)%65521,d-1); let b=graph_fn2928((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn896(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn2944((x*x+24)%65521,d-1); let b=graph_fn2945((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn897(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn2945((x*x+25)%65521,d-1); let b=graph_fn2962((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn898(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn2946((x*x+26)%65521,d-1); let b=graph_fn2979((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn899(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn2947((x*x+27)%65521,d-1); let b=graph_fn2996((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn900(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn2948((x*x+28)%65521,d-1); let b=graph_fn3013((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn901(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn2949((x*x+29)%65521,d-1); let b=graph_fn3030((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn902(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn2950((x*x+30)%65521,d-1); let b=graph_fn3047((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn903(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn2951((x*x+31)%65521,d-1); let b=graph_fn3064((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn904(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn2952((x*x+32)%65521,d-1); let b=graph_fn3081((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn905(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn2953((x*x+33)%65521,d-1); let b=graph_fn3098((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn906(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn2954((x*x+34)%65521,d-1); let b=graph_fn3115((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn907(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn2955((x*x+35)%65521,d-1); let b=graph_fn3132((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn908(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn2956((x*x+36)%65521,d-1); let b=graph_fn3149((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn909(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn2957((x*x+37)%65521,d-1); let b=graph_fn3166((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn910(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn2958((x*x+38)%65521,d-1); let b=graph_fn3183((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn911(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn2959((x*x+39)%65521,d-1); let b=graph_fn3200((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn912(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn2960((x*x+40)%65521,d-1); let b=graph_fn3217((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn913(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn2961((x*x+41)%65521,d-1); let b=graph_fn3234((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn914(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn2962((x*x+42)%65521,d-1); let b=graph_fn3251((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn915(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn2963((x*x+43)%65521,d-1); let b=graph_fn3268((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn916(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn2964((x*x+44)%65521,d-1); let b=graph_fn3285((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn917(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn2965((x*x+45)%65521,d-1); let b=graph_fn3302((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn918(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn2966((x*x+46)%65521,d-1); let b=graph_fn3319((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn919(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn2967((x*x+47)%65521,d-1); let b=graph_fn3336((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn920(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn2968((x*x+48)%65521,d-1); let b=graph_fn3353((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn921(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn2969((x*x+49)%65521,d-1); let b=graph_fn3370((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn922(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn2970((x*x+50)%65521,d-1); let b=graph_fn3387((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn923(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn2971((x*x+51)%65521,d-1); let b=graph_fn3404((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn924(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn2972((x*x+52)%65521,d-1); let b=graph_fn3421((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn925(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn2973((x*x+53)%65521,d-1); let b=graph_fn3438((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn926(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn2974((x*x+54)%65521,d-1); let b=graph_fn3455((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn927(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn2975((x*x+55)%65521,d-1); let b=graph_fn3472((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn928(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn2976((x*x+56)%65521,d-1); let b=graph_fn3489((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn929(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn2977((x*x+57)%65521,d-1); let b=graph_fn3506((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn930(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn2978((x*x+58)%65521,d-1); let b=graph_fn3523((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn931(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn2979((x*x+59)%65521,d-1); let b=graph_fn3540((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn932(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn2980((x*x+60)%65521,d-1); let b=graph_fn3557((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn933(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn2981((x*x+61)%65521,d-1); let b=graph_fn3574((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn934(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn2982((x*x+62)%65521,d-1); let b=graph_fn3591((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn935(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn2983((x*x+63)%65521,d-1); let b=graph_fn3608((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn936(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn2984((x*x+64)%65521,d-1); let b=graph_fn3625((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn937(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn2985((x*x+65)%65521,d-1); let b=graph_fn3642((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn938(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn2986((x*x+66)%65521,d-1); let b=graph_fn3659((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn939(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn2987((x*x+67)%65521,d-1); let b=graph_fn3676((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn940(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn2988((x*x+68)%65521,d-1); let b=graph_fn3693((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn941(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn2989((x*x+69)%65521,d-1); let b=graph_fn3710((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn942(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn2990((x*x+70)%65521,d-1); let b=graph_fn3727((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn943(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn2991((x*x+71)%65521,d-1); let b=graph_fn3744((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn944(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn2992((x*x+72)%65521,d-1); let b=graph_fn3761((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn945(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn2993((x*x+73)%65521,d-1); let b=graph_fn3778((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn946(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn2994((x*x+74)%65521,d-1); let b=graph_fn3795((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn947(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn2995((x*x+75)%65521,d-1); let b=graph_fn3812((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn948(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn2996((x*x+76)%65521,d-1); let b=graph_fn3829((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn949(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn2997((x*x+77)%65521,d-1); let b=graph_fn3846((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn950(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn2998((x*x+78)%65521,d-1); let b=graph_fn3863((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn951(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn2999((x*x+79)%65521,d-1); let b=graph_fn3880((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn952(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3000((x*x+80)%65521,d-1); let b=graph_fn3897((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn953(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3001((x*x+81)%65521,d-1); let b=graph_fn3914((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn954(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3002((x*x+82)%65521,d-1); let b=graph_fn3931((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn955(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3003((x*x+83)%65521,d-1); let b=graph_fn3948((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn956(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3004((x*x+84)%65521,d-1); let b=graph_fn3965((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn957(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3005((x*x+85)%65521,d-1); let b=graph_fn3982((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn958(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3006((x*x+86)%65521,d-1); let b=graph_fn3999((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn959(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3007((x*x+87)%65521,d-1); let b=graph_fn4016((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn960(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3008((x*x+88)%65521,d-1); let b=graph_fn4033((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn961(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3009((x*x+89)%65521,d-1); let b=graph_fn4050((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn962(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3010((x*x+90)%65521,d-1); let b=graph_fn4067((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn963(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3011((x*x+91)%65521,d-1); let b=graph_fn4084((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn964(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3012((x*x+92)%65521,d-1); let b=graph_fn2053((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn965(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3013((x*x+93)%65521,d-1); let b=graph_fn2070((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn966(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3014((x*x+94)%65521,d-1); let b=graph_fn2087((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn967(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3015((x*x+95)%65521,d-1); let b=graph_fn2104((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn968(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3016((x*x+96)%65521,d-1); let b=graph_fn2121((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn969(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3017((x*x+97)%65521,d-1); let b=graph_fn2138((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn970(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3018((x*x+1)%65521,d-1); let b=graph_fn2155((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn971(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3019((x*x+2)%65521,d-1); let b=graph_fn2172((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn972(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3020((x*x+3)%65521,d-1); let b=graph_fn2189((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn973(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3021((x*x+4)%65521,d-1); let b=graph_fn2206((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn974(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3022((x*x+5)%65521,d-1); let b=graph_fn2223((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn975(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3023((x*x+6)%65521,d-1); let b=graph_fn2240((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn976(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3024((x*x+7)%65521,d-1); let b=graph_fn2257((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn977(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3025((x*x+8)%65521,d-1); let b=graph_fn2274((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn978(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3026((x*x+9)%65521,d-1); let b=graph_fn2291((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn979(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3027((x*x+10)%65521,d-1); let b=graph_fn2308((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn980(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3028((x*x+11)%65521,d-1); let b=graph_fn2325((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn981(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3029((x*x+12)%65521,d-1); let b=graph_fn2342((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn982(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3030((x*x+13)%65521,d-1); let b=graph_fn2359((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn983(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3031((x*x+14)%65521,d-1); let b=graph_fn2376((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn984(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3032((x*x+15)%65521,d-1); let b=graph_fn2393((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn985(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3033((x*x+16)%65521,d-1); let b=graph_fn2410((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn986(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3034((x*x+17)%65521,d-1); let b=graph_fn2427((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn987(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3035((x*x+18)%65521,d-1); let b=graph_fn2444((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn988(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3036((x*x+19)%65521,d-1); let b=graph_fn2461((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn989(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3037((x*x+20)%65521,d-1); let b=graph_fn2478((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn990(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3038((x*x+21)%65521,d-1); let b=graph_fn2495((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn991(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3039((x*x+22)%65521,d-1); let b=graph_fn2512((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn992(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3040((x*x+23)%65521,d-1); let b=graph_fn2529((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn993(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3041((x*x+24)%65521,d-1); let b=graph_fn2546((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn994(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3042((x*x+25)%65521,d-1); let b=graph_fn2563((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn995(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3043((x*x+26)%65521,d-1); let b=graph_fn2580((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn996(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3044((x*x+27)%65521,d-1); let b=graph_fn2597((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn997(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3045((x*x+28)%65521,d-1); let b=graph_fn2614((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn998(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3046((x*x+29)%65521,d-1); let b=graph_fn2631((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn999(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3047((x*x+30)%65521,d-1); let b=graph_fn2648((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1000(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3048((x*x+31)%65521,d-1); let b=graph_fn2665((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1001(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3049((x*x+32)%65521,d-1); let b=graph_fn2682((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1002(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3050((x*x+33)%65521,d-1); let b=graph_fn2699((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1003(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3051((x*x+34)%65521,d-1); let b=graph_fn2716((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1004(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3052((x*x+35)%65521,d-1); let b=graph_fn2733((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1005(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3053((x*x+36)%65521,d-1); let b=graph_fn2750((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1006(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3054((x*x+37)%65521,d-1); let b=graph_fn2767((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1007(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3055((x*x+38)%65521,d-1); let b=graph_fn2784((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1008(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3056((x*x+39)%65521,d-1); let b=graph_fn2801((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1009(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3057((x*x+40)%65521,d-1); let b=graph_fn2818((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1010(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3058((x*x+41)%65521,d-1); let b=graph_fn2835((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1011(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3059((x*x+42)%65521,d-1); let b=graph_fn2852((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1012(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3060((x*x+43)%65521,d-1); let b=graph_fn2869((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1013(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3061((x*x+44)%65521,d-1); let b=graph_fn2886((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1014(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3062((x*x+45)%65521,d-1); let b=graph_fn2903((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1015(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3063((x*x+46)%65521,d-1); let b=graph_fn2920((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1016(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3064((x*x+47)%65521,d-1); let b=graph_fn2937((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1017(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3065((x*x+48)%65521,d-1); let b=graph_fn2954((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1018(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3066((x*x+49)%65521,d-1); let b=graph_fn2971((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1019(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3067((x*x+50)%65521,d-1); let b=graph_fn2988((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1020(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3068((x*x+51)%65521,d-1); let b=graph_fn3005((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1021(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3069((x*x+52)%65521,d-1); let b=graph_fn3022((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1022(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3070((x*x+53)%65521,d-1); let b=graph_fn3039((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1023(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3071((x*x+54)%65521,d-1); let b=graph_fn3056((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1024(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3072((x*x+55)%65521,d-1); let b=graph_fn3073((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1025(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3073((x*x+56)%65521,d-1); let b=graph_fn3090((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1026(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3074((x*x+57)%65521,d-1); let b=graph_fn3107((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1027(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3075((x*x+58)%65521,d-1); let b=graph_fn3124((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1028(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3076((x*x+59)%65521,d-1); let b=graph_fn3141((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1029(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3077((x*x+60)%65521,d-1); let b=graph_fn3158((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1030(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3078((x*x+61)%65521,d-1); let b=graph_fn3175((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1031(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3079((x*x+62)%65521,d-1); let b=graph_fn3192((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1032(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3080((x*x+63)%65521,d-1); let b=graph_fn3209((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1033(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3081((x*x+64)%65521,d-1); let b=graph_fn3226((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1034(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3082((x*x+65)%65521,d-1); let b=graph_fn3243((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1035(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3083((x*x+66)%65521,d-1); let b=graph_fn3260((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1036(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3084((x*x+67)%65521,d-1); let b=graph_fn3277((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1037(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3085((x*x+68)%65521,d-1); let b=graph_fn3294((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1038(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3086((x*x+69)%65521,d-1); let b=graph_fn3311((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1039(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3087((x*x+70)%65521,d-1); let b=graph_fn3328((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1040(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3088((x*x+71)%65521,d-1); let b=graph_fn3345((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1041(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3089((x*x+72)%65521,d-1); let b=graph_fn3362((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1042(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3090((x*x+73)%65521,d-1); let b=graph_fn3379((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1043(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3091((x*x+74)%65521,d-1); let b=graph_fn3396((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1044(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3092((x*x+75)%65521,d-1); let b=graph_fn3413((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1045(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3093((x*x+76)%65521,d-1); let b=graph_fn3430((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1046(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3094((x*x+77)%65521,d-1); let b=graph_fn3447((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1047(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3095((x*x+78)%65521,d-1); let b=graph_fn3464((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1048(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3096((x*x+79)%65521,d-1); let b=graph_fn3481((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1049(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3097((x*x+80)%65521,d-1); let b=graph_fn3498((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1050(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3098((x*x+81)%65521,d-1); let b=graph_fn3515((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1051(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3099((x*x+82)%65521,d-1); let b=graph_fn3532((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1052(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3100((x*x+83)%65521,d-1); let b=graph_fn3549((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1053(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3101((x*x+84)%65521,d-1); let b=graph_fn3566((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1054(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3102((x*x+85)%65521,d-1); let b=graph_fn3583((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1055(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3103((x*x+86)%65521,d-1); let b=graph_fn3600((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1056(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3104((x*x+87)%65521,d-1); let b=graph_fn3617((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1057(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3105((x*x+88)%65521,d-1); let b=graph_fn3634((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1058(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3106((x*x+89)%65521,d-1); let b=graph_fn3651((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1059(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3107((x*x+90)%65521,d-1); let b=graph_fn3668((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1060(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3108((x*x+91)%65521,d-1); let b=graph_fn3685((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1061(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3109((x*x+92)%65521,d-1); let b=graph_fn3702((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1062(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3110((x*x+93)%65521,d-1); let b=graph_fn3719((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1063(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3111((x*x+94)%65521,d-1); let b=graph_fn3736((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1064(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3112((x*x+95)%65521,d-1); let b=graph_fn3753((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1065(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3113((x*x+96)%65521,d-1); let b=graph_fn3770((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1066(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3114((x*x+97)%65521,d-1); let b=graph_fn3787((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1067(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3115((x*x+1)%65521,d-1); let b=graph_fn3804((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1068(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3116((x*x+2)%65521,d-1); let b=graph_fn3821((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1069(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3117((x*x+3)%65521,d-1); let b=graph_fn3838((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1070(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3118((x*x+4)%65521,d-1); let b=graph_fn3855((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1071(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3119((x*x+5)%65521,d-1); let b=graph_fn3872((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1072(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3120((x*x+6)%65521,d-1); let b=graph_fn3889((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1073(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3121((x*x+7)%65521,d-1); let b=graph_fn3906((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1074(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3122((x*x+8)%65521,d-1); let b=graph_fn3923((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1075(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3123((x*x+9)%65521,d-1); let b=graph_fn3940((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1076(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3124((x*x+10)%65521,d-1); let b=graph_fn3957((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1077(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3125((x*x+11)%65521,d-1); let b=graph_fn3974((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1078(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3126((x*x+12)%65521,d-1); let b=graph_fn3991((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1079(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3127((x*x+13)%65521,d-1); let b=graph_fn4008((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1080(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3128((x*x+14)%65521,d-1); let b=graph_fn4025((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1081(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3129((x*x+15)%65521,d-1); let b=graph_fn4042((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1082(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3130((x*x+16)%65521,d-1); let b=graph_fn4059((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1083(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3131((x*x+17)%65521,d-1); let b=graph_fn4076((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1084(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3132((x*x+18)%65521,d-1); let b=graph_fn4093((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1085(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3133((x*x+19)%65521,d-1); let b=graph_fn2062((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1086(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3134((x*x+20)%65521,d-1); let b=graph_fn2079((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1087(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3135((x*x+21)%65521,d-1); let b=graph_fn2096((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1088(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3136((x*x+22)%65521,d-1); let b=graph_fn2113((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1089(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3137((x*x+23)%65521,d-1); let b=graph_fn2130((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1090(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3138((x*x+24)%65521,d-1); let b=graph_fn2147((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1091(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3139((x*x+25)%65521,d-1); let b=graph_fn2164((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1092(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3140((x*x+26)%65521,d-1); let b=graph_fn2181((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1093(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3141((x*x+27)%65521,d-1); let b=graph_fn2198((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1094(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3142((x*x+28)%65521,d-1); let b=graph_fn2215((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1095(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3143((x*x+29)%65521,d-1); let b=graph_fn2232((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1096(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3144((x*x+30)%65521,d-1); let b=graph_fn2249((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1097(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3145((x*x+31)%65521,d-1); let b=graph_fn2266((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1098(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3146((x*x+32)%65521,d-1); let b=graph_fn2283((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1099(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3147((x*x+33)%65521,d-1); let b=graph_fn2300((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1100(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3148((x*x+34)%65521,d-1); let b=graph_fn2317((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1101(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3149((x*x+35)%65521,d-1); let b=graph_fn2334((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1102(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3150((x*x+36)%65521,d-1); let b=graph_fn2351((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1103(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3151((x*x+37)%65521,d-1); let b=graph_fn2368((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1104(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3152((x*x+38)%65521,d-1); let b=graph_fn2385((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1105(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3153((x*x+39)%65521,d-1); let b=graph_fn2402((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1106(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3154((x*x+40)%65521,d-1); let b=graph_fn2419((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1107(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3155((x*x+41)%65521,d-1); let b=graph_fn2436((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1108(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3156((x*x+42)%65521,d-1); let b=graph_fn2453((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1109(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3157((x*x+43)%65521,d-1); let b=graph_fn2470((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1110(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3158((x*x+44)%65521,d-1); let b=graph_fn2487((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1111(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3159((x*x+45)%65521,d-1); let b=graph_fn2504((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1112(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3160((x*x+46)%65521,d-1); let b=graph_fn2521((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1113(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3161((x*x+47)%65521,d-1); let b=graph_fn2538((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1114(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3162((x*x+48)%65521,d-1); let b=graph_fn2555((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1115(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3163((x*x+49)%65521,d-1); let b=graph_fn2572((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1116(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3164((x*x+50)%65521,d-1); let b=graph_fn2589((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1117(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3165((x*x+51)%65521,d-1); let b=graph_fn2606((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1118(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3166((x*x+52)%65521,d-1); let b=graph_fn2623((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1119(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3167((x*x+53)%65521,d-1); let b=graph_fn2640((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1120(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3168((x*x+54)%65521,d-1); let b=graph_fn2657((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1121(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3169((x*x+55)%65521,d-1); let b=graph_fn2674((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1122(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3170((x*x+56)%65521,d-1); let b=graph_fn2691((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1123(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3171((x*x+57)%65521,d-1); let b=graph_fn2708((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1124(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3172((x*x+58)%65521,d-1); let b=graph_fn2725((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1125(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3173((x*x+59)%65521,d-1); let b=graph_fn2742((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1126(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3174((x*x+60)%65521,d-1); let b=graph_fn2759((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1127(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3175((x*x+61)%65521,d-1); let b=graph_fn2776((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1128(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3176((x*x+62)%65521,d-1); let b=graph_fn2793((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1129(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3177((x*x+63)%65521,d-1); let b=graph_fn2810((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1130(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3178((x*x+64)%65521,d-1); let b=graph_fn2827((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1131(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3179((x*x+65)%65521,d-1); let b=graph_fn2844((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1132(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3180((x*x+66)%65521,d-1); let b=graph_fn2861((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1133(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3181((x*x+67)%65521,d-1); let b=graph_fn2878((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1134(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3182((x*x+68)%65521,d-1); let b=graph_fn2895((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1135(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3183((x*x+69)%65521,d-1); let b=graph_fn2912((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1136(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3184((x*x+70)%65521,d-1); let b=graph_fn2929((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1137(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3185((x*x+71)%65521,d-1); let b=graph_fn2946((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1138(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3186((x*x+72)%65521,d-1); let b=graph_fn2963((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1139(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3187((x*x+73)%65521,d-1); let b=graph_fn2980((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1140(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3188((x*x+74)%65521,d-1); let b=graph_fn2997((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1141(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3189((x*x+75)%65521,d-1); let b=graph_fn3014((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1142(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3190((x*x+76)%65521,d-1); let b=graph_fn3031((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1143(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3191((x*x+77)%65521,d-1); let b=graph_fn3048((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1144(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3192((x*x+78)%65521,d-1); let b=graph_fn3065((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1145(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3193((x*x+79)%65521,d-1); let b=graph_fn3082((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1146(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3194((x*x+80)%65521,d-1); let b=graph_fn3099((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1147(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3195((x*x+81)%65521,d-1); let b=graph_fn3116((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1148(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3196((x*x+82)%65521,d-1); let b=graph_fn3133((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1149(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3197((x*x+83)%65521,d-1); let b=graph_fn3150((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1150(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3198((x*x+84)%65521,d-1); let b=graph_fn3167((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1151(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3199((x*x+85)%65521,d-1); let b=graph_fn3184((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1152(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3200((x*x+86)%65521,d-1); let b=graph_fn3201((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1153(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3201((x*x+87)%65521,d-1); let b=graph_fn3218((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1154(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3202((x*x+88)%65521,d-1); let b=graph_fn3235((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1155(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3203((x*x+89)%65521,d-1); let b=graph_fn3252((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1156(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3204((x*x+90)%65521,d-1); let b=graph_fn3269((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1157(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3205((x*x+91)%65521,d-1); let b=graph_fn3286((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1158(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3206((x*x+92)%65521,d-1); let b=graph_fn3303((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1159(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3207((x*x+93)%65521,d-1); let b=graph_fn3320((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1160(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3208((x*x+94)%65521,d-1); let b=graph_fn3337((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1161(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3209((x*x+95)%65521,d-1); let b=graph_fn3354((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1162(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3210((x*x+96)%65521,d-1); let b=graph_fn3371((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1163(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3211((x*x+97)%65521,d-1); let b=graph_fn3388((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1164(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3212((x*x+1)%65521,d-1); let b=graph_fn3405((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1165(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3213((x*x+2)%65521,d-1); let b=graph_fn3422((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1166(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3214((x*x+3)%65521,d-1); let b=graph_fn3439((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1167(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3215((x*x+4)%65521,d-1); let b=graph_fn3456((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1168(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3216((x*x+5)%65521,d-1); let b=graph_fn3473((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1169(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3217((x*x+6)%65521,d-1); let b=graph_fn3490((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1170(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3218((x*x+7)%65521,d-1); let b=graph_fn3507((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1171(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3219((x*x+8)%65521,d-1); let b=graph_fn3524((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1172(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3220((x*x+9)%65521,d-1); let b=graph_fn3541((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1173(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3221((x*x+10)%65521,d-1); let b=graph_fn3558((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1174(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3222((x*x+11)%65521,d-1); let b=graph_fn3575((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1175(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3223((x*x+12)%65521,d-1); let b=graph_fn3592((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1176(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3224((x*x+13)%65521,d-1); let b=graph_fn3609((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1177(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3225((x*x+14)%65521,d-1); let b=graph_fn3626((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1178(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3226((x*x+15)%65521,d-1); let b=graph_fn3643((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1179(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3227((x*x+16)%65521,d-1); let b=graph_fn3660((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1180(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3228((x*x+17)%65521,d-1); let b=graph_fn3677((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1181(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3229((x*x+18)%65521,d-1); let b=graph_fn3694((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1182(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3230((x*x+19)%65521,d-1); let b=graph_fn3711((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1183(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3231((x*x+20)%65521,d-1); let b=graph_fn3728((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1184(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3232((x*x+21)%65521,d-1); let b=graph_fn3745((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1185(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3233((x*x+22)%65521,d-1); let b=graph_fn3762((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1186(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3234((x*x+23)%65521,d-1); let b=graph_fn3779((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1187(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3235((x*x+24)%65521,d-1); let b=graph_fn3796((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1188(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3236((x*x+25)%65521,d-1); let b=graph_fn3813((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1189(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3237((x*x+26)%65521,d-1); let b=graph_fn3830((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1190(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3238((x*x+27)%65521,d-1); let b=graph_fn3847((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1191(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3239((x*x+28)%65521,d-1); let b=graph_fn3864((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1192(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3240((x*x+29)%65521,d-1); let b=graph_fn3881((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1193(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3241((x*x+30)%65521,d-1); let b=graph_fn3898((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1194(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3242((x*x+31)%65521,d-1); let b=graph_fn3915((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1195(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3243((x*x+32)%65521,d-1); let b=graph_fn3932((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1196(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3244((x*x+33)%65521,d-1); let b=graph_fn3949((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1197(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3245((x*x+34)%65521,d-1); let b=graph_fn3966((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1198(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3246((x*x+35)%65521,d-1); let b=graph_fn3983((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1199(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3247((x*x+36)%65521,d-1); let b=graph_fn4000((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1200(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3248((x*x+37)%65521,d-1); let b=graph_fn4017((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1201(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3249((x*x+38)%65521,d-1); let b=graph_fn4034((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1202(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3250((x*x+39)%65521,d-1); let b=graph_fn4051((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1203(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3251((x*x+40)%65521,d-1); let b=graph_fn4068((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1204(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3252((x*x+41)%65521,d-1); let b=graph_fn4085((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1205(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3253((x*x+42)%65521,d-1); let b=graph_fn2054((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1206(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3254((x*x+43)%65521,d-1); let b=graph_fn2071((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1207(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3255((x*x+44)%65521,d-1); let b=graph_fn2088((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1208(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3256((x*x+45)%65521,d-1); let b=graph_fn2105((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1209(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3257((x*x+46)%65521,d-1); let b=graph_fn2122((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1210(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3258((x*x+47)%65521,d-1); let b=graph_fn2139((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1211(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3259((x*x+48)%65521,d-1); let b=graph_fn2156((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1212(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3260((x*x+49)%65521,d-1); let b=graph_fn2173((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1213(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3261((x*x+50)%65521,d-1); let b=graph_fn2190((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1214(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3262((x*x+51)%65521,d-1); let b=graph_fn2207((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1215(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3263((x*x+52)%65521,d-1); let b=graph_fn2224((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1216(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3264((x*x+53)%65521,d-1); let b=graph_fn2241((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1217(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3265((x*x+54)%65521,d-1); let b=graph_fn2258((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1218(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3266((x*x+55)%65521,d-1); let b=graph_fn2275((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1219(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3267((x*x+56)%65521,d-1); let b=graph_fn2292((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1220(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3268((x*x+57)%65521,d-1); let b=graph_fn2309((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1221(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3269((x*x+58)%65521,d-1); let b=graph_fn2326((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1222(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3270((x*x+59)%65521,d-1); let b=graph_fn2343((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1223(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3271((x*x+60)%65521,d-1); let b=graph_fn2360((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1224(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3272((x*x+61)%65521,d-1); let b=graph_fn2377((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1225(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3273((x*x+62)%65521,d-1); let b=graph_fn2394((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1226(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3274((x*x+63)%65521,d-1); let b=graph_fn2411((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1227(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3275((x*x+64)%65521,d-1); let b=graph_fn2428((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1228(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3276((x*x+65)%65521,d-1); let b=graph_fn2445((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1229(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3277((x*x+66)%65521,d-1); let b=graph_fn2462((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1230(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3278((x*x+67)%65521,d-1); let b=graph_fn2479((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1231(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3279((x*x+68)%65521,d-1); let b=graph_fn2496((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1232(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3280((x*x+69)%65521,d-1); let b=graph_fn2513((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1233(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3281((x*x+70)%65521,d-1); let b=graph_fn2530((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1234(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3282((x*x+71)%65521,d-1); let b=graph_fn2547((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1235(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3283((x*x+72)%65521,d-1); let b=graph_fn2564((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1236(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3284((x*x+73)%65521,d-1); let b=graph_fn2581((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1237(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3285((x*x+74)%65521,d-1); let b=graph_fn2598((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1238(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3286((x*x+75)%65521,d-1); let b=graph_fn2615((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1239(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3287((x*x+76)%65521,d-1); let b=graph_fn2632((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1240(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3288((x*x+77)%65521,d-1); let b=graph_fn2649((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1241(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3289((x*x+78)%65521,d-1); let b=graph_fn2666((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1242(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3290((x*x+79)%65521,d-1); let b=graph_fn2683((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1243(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3291((x*x+80)%65521,d-1); let b=graph_fn2700((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1244(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3292((x*x+81)%65521,d-1); let b=graph_fn2717((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1245(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3293((x*x+82)%65521,d-1); let b=graph_fn2734((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1246(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3294((x*x+83)%65521,d-1); let b=graph_fn2751((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1247(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3295((x*x+84)%65521,d-1); let b=graph_fn2768((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1248(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3296((x*x+85)%65521,d-1); let b=graph_fn2785((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1249(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3297((x*x+86)%65521,d-1); let b=graph_fn2802((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1250(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3298((x*x+87)%65521,d-1); let b=graph_fn2819((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1251(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3299((x*x+88)%65521,d-1); let b=graph_fn2836((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1252(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3300((x*x+89)%65521,d-1); let b=graph_fn2853((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1253(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3301((x*x+90)%65521,d-1); let b=graph_fn2870((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1254(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3302((x*x+91)%65521,d-1); let b=graph_fn2887((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1255(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3303((x*x+92)%65521,d-1); let b=graph_fn2904((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1256(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3304((x*x+93)%65521,d-1); let b=graph_fn2921((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1257(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3305((x*x+94)%65521,d-1); let b=graph_fn2938((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1258(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3306((x*x+95)%65521,d-1); let b=graph_fn2955((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1259(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3307((x*x+96)%65521,d-1); let b=graph_fn2972((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1260(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3308((x*x+97)%65521,d-1); let b=graph_fn2989((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1261(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3309((x*x+1)%65521,d-1); let b=graph_fn3006((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1262(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3310((x*x+2)%65521,d-1); let b=graph_fn3023((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1263(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3311((x*x+3)%65521,d-1); let b=graph_fn3040((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1264(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3312((x*x+4)%65521,d-1); let b=graph_fn3057((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1265(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3313((x*x+5)%65521,d-1); let b=graph_fn3074((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1266(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3314((x*x+6)%65521,d-1); let b=graph_fn3091((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1267(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3315((x*x+7)%65521,d-1); let b=graph_fn3108((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1268(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3316((x*x+8)%65521,d-1); let b=graph_fn3125((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1269(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3317((x*x+9)%65521,d-1); let b=graph_fn3142((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1270(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3318((x*x+10)%65521,d-1); let b=graph_fn3159((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1271(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3319((x*x+11)%65521,d-1); let b=graph_fn3176((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1272(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3320((x*x+12)%65521,d-1); let b=graph_fn3193((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1273(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3321((x*x+13)%65521,d-1); let b=graph_fn3210((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1274(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3322((x*x+14)%65521,d-1); let b=graph_fn3227((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1275(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3323((x*x+15)%65521,d-1); let b=graph_fn3244((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1276(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3324((x*x+16)%65521,d-1); let b=graph_fn3261((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1277(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3325((x*x+17)%65521,d-1); let b=graph_fn3278((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1278(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3326((x*x+18)%65521,d-1); let b=graph_fn3295((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1279(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3327((x*x+19)%65521,d-1); let b=graph_fn3312((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1280(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3328((x*x+20)%65521,d-1); let b=graph_fn3329((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1281(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3329((x*x+21)%65521,d-1); let b=graph_fn3346((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1282(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3330((x*x+22)%65521,d-1); let b=graph_fn3363((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1283(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3331((x*x+23)%65521,d-1); let b=graph_fn3380((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1284(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3332((x*x+24)%65521,d-1); let b=graph_fn3397((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1285(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3333((x*x+25)%65521,d-1); let b=graph_fn3414((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1286(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3334((x*x+26)%65521,d-1); let b=graph_fn3431((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1287(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3335((x*x+27)%65521,d-1); let b=graph_fn3448((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1288(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3336((x*x+28)%65521,d-1); let b=graph_fn3465((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1289(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3337((x*x+29)%65521,d-1); let b=graph_fn3482((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1290(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3338((x*x+30)%65521,d-1); let b=graph_fn3499((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1291(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3339((x*x+31)%65521,d-1); let b=graph_fn3516((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1292(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3340((x*x+32)%65521,d-1); let b=graph_fn3533((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1293(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3341((x*x+33)%65521,d-1); let b=graph_fn3550((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1294(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3342((x*x+34)%65521,d-1); let b=graph_fn3567((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1295(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3343((x*x+35)%65521,d-1); let b=graph_fn3584((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1296(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3344((x*x+36)%65521,d-1); let b=graph_fn3601((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1297(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3345((x*x+37)%65521,d-1); let b=graph_fn3618((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1298(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3346((x*x+38)%65521,d-1); let b=graph_fn3635((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1299(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3347((x*x+39)%65521,d-1); let b=graph_fn3652((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1300(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3348((x*x+40)%65521,d-1); let b=graph_fn3669((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1301(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3349((x*x+41)%65521,d-1); let b=graph_fn3686((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1302(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3350((x*x+42)%65521,d-1); let b=graph_fn3703((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1303(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3351((x*x+43)%65521,d-1); let b=graph_fn3720((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1304(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3352((x*x+44)%65521,d-1); let b=graph_fn3737((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1305(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3353((x*x+45)%65521,d-1); let b=graph_fn3754((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1306(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3354((x*x+46)%65521,d-1); let b=graph_fn3771((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1307(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3355((x*x+47)%65521,d-1); let b=graph_fn3788((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1308(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3356((x*x+48)%65521,d-1); let b=graph_fn3805((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1309(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3357((x*x+49)%65521,d-1); let b=graph_fn3822((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1310(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3358((x*x+50)%65521,d-1); let b=graph_fn3839((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1311(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3359((x*x+51)%65521,d-1); let b=graph_fn3856((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1312(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3360((x*x+52)%65521,d-1); let b=graph_fn3873((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1313(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3361((x*x+53)%65521,d-1); let b=graph_fn3890((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1314(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3362((x*x+54)%65521,d-1); let b=graph_fn3907((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1315(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3363((x*x+55)%65521,d-1); let b=graph_fn3924((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1316(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3364((x*x+56)%65521,d-1); let b=graph_fn3941((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1317(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3365((x*x+57)%65521,d-1); let b=graph_fn3958((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1318(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3366((x*x+58)%65521,d-1); let b=graph_fn3975((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1319(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3367((x*x+59)%65521,d-1); let b=graph_fn3992((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1320(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3368((x*x+60)%65521,d-1); let b=graph_fn4009((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1321(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3369((x*x+61)%65521,d-1); let b=graph_fn4026((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1322(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3370((x*x+62)%65521,d-1); let b=graph_fn4043((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1323(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3371((x*x+63)%65521,d-1); let b=graph_fn4060((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1324(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3372((x*x+64)%65521,d-1); let b=graph_fn4077((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1325(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3373((x*x+65)%65521,d-1); let b=graph_fn4094((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1326(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3374((x*x+66)%65521,d-1); let b=graph_fn2063((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1327(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3375((x*x+67)%65521,d-1); let b=graph_fn2080((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1328(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3376((x*x+68)%65521,d-1); let b=graph_fn2097((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1329(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3377((x*x+69)%65521,d-1); let b=graph_fn2114((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1330(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3378((x*x+70)%65521,d-1); let b=graph_fn2131((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1331(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3379((x*x+71)%65521,d-1); let b=graph_fn2148((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1332(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3380((x*x+72)%65521,d-1); let b=graph_fn2165((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1333(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3381((x*x+73)%65521,d-1); let b=graph_fn2182((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1334(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3382((x*x+74)%65521,d-1); let b=graph_fn2199((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1335(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3383((x*x+75)%65521,d-1); let b=graph_fn2216((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1336(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3384((x*x+76)%65521,d-1); let b=graph_fn2233((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1337(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3385((x*x+77)%65521,d-1); let b=graph_fn2250((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1338(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3386((x*x+78)%65521,d-1); let b=graph_fn2267((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1339(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3387((x*x+79)%65521,d-1); let b=graph_fn2284((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1340(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3388((x*x+80)%65521,d-1); let b=graph_fn2301((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1341(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3389((x*x+81)%65521,d-1); let b=graph_fn2318((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1342(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3390((x*x+82)%65521,d-1); let b=graph_fn2335((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1343(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3391((x*x+83)%65521,d-1); let b=graph_fn2352((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1344(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3392((x*x+84)%65521,d-1); let b=graph_fn2369((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1345(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3393((x*x+85)%65521,d-1); let b=graph_fn2386((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1346(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3394((x*x+86)%65521,d-1); let b=graph_fn2403((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1347(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3395((x*x+87)%65521,d-1); let b=graph_fn2420((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1348(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3396((x*x+88)%65521,d-1); let b=graph_fn2437((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1349(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3397((x*x+89)%65521,d-1); let b=graph_fn2454((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1350(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3398((x*x+90)%65521,d-1); let b=graph_fn2471((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1351(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3399((x*x+91)%65521,d-1); let b=graph_fn2488((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1352(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3400((x*x+92)%65521,d-1); let b=graph_fn2505((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1353(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3401((x*x+93)%65521,d-1); let b=graph_fn2522((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1354(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3402((x*x+94)%65521,d-1); let b=graph_fn2539((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1355(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3403((x*x+95)%65521,d-1); let b=graph_fn2556((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1356(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3404((x*x+96)%65521,d-1); let b=graph_fn2573((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1357(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3405((x*x+97)%65521,d-1); let b=graph_fn2590((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1358(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3406((x*x+1)%65521,d-1); let b=graph_fn2607((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1359(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3407((x*x+2)%65521,d-1); let b=graph_fn2624((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1360(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3408((x*x+3)%65521,d-1); let b=graph_fn2641((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1361(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3409((x*x+4)%65521,d-1); let b=graph_fn2658((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1362(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3410((x*x+5)%65521,d-1); let b=graph_fn2675((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1363(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3411((x*x+6)%65521,d-1); let b=graph_fn2692((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1364(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3412((x*x+7)%65521,d-1); let b=graph_fn2709((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1365(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3413((x*x+8)%65521,d-1); let b=graph_fn2726((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1366(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3414((x*x+9)%65521,d-1); let b=graph_fn2743((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1367(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3415((x*x+10)%65521,d-1); let b=graph_fn2760((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1368(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3416((x*x+11)%65521,d-1); let b=graph_fn2777((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1369(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3417((x*x+12)%65521,d-1); let b=graph_fn2794((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1370(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3418((x*x+13)%65521,d-1); let b=graph_fn2811((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1371(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3419((x*x+14)%65521,d-1); let b=graph_fn2828((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1372(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3420((x*x+15)%65521,d-1); let b=graph_fn2845((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1373(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3421((x*x+16)%65521,d-1); let b=graph_fn2862((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1374(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3422((x*x+17)%65521,d-1); let b=graph_fn2879((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1375(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3423((x*x+18)%65521,d-1); let b=graph_fn2896((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1376(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3424((x*x+19)%65521,d-1); let b=graph_fn2913((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1377(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3425((x*x+20)%65521,d-1); let b=graph_fn2930((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1378(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3426((x*x+21)%65521,d-1); let b=graph_fn2947((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1379(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3427((x*x+22)%65521,d-1); let b=graph_fn2964((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1380(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3428((x*x+23)%65521,d-1); let b=graph_fn2981((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1381(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3429((x*x+24)%65521,d-1); let b=graph_fn2998((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1382(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3430((x*x+25)%65521,d-1); let b=graph_fn3015((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1383(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3431((x*x+26)%65521,d-1); let b=graph_fn3032((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1384(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3432((x*x+27)%65521,d-1); let b=graph_fn3049((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1385(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3433((x*x+28)%65521,d-1); let b=graph_fn3066((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1386(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3434((x*x+29)%65521,d-1); let b=graph_fn3083((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1387(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3435((x*x+30)%65521,d-1); let b=graph_fn3100((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1388(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3436((x*x+31)%65521,d-1); let b=graph_fn3117((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1389(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3437((x*x+32)%65521,d-1); let b=graph_fn3134((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1390(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3438((x*x+33)%65521,d-1); let b=graph_fn3151((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1391(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3439((x*x+34)%65521,d-1); let b=graph_fn3168((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1392(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3440((x*x+35)%65521,d-1); let b=graph_fn3185((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1393(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3441((x*x+36)%65521,d-1); let b=graph_fn3202((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1394(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3442((x*x+37)%65521,d-1); let b=graph_fn3219((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1395(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3443((x*x+38)%65521,d-1); let b=graph_fn3236((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1396(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3444((x*x+39)%65521,d-1); let b=graph_fn3253((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1397(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3445((x*x+40)%65521,d-1); let b=graph_fn3270((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1398(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3446((x*x+41)%65521,d-1); let b=graph_fn3287((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1399(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3447((x*x+42)%65521,d-1); let b=graph_fn3304((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1400(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3448((x*x+43)%65521,d-1); let b=graph_fn3321((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1401(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3449((x*x+44)%65521,d-1); let b=graph_fn3338((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1402(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3450((x*x+45)%65521,d-1); let b=graph_fn3355((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1403(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3451((x*x+46)%65521,d-1); let b=graph_fn3372((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1404(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3452((x*x+47)%65521,d-1); let b=graph_fn3389((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1405(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3453((x*x+48)%65521,d-1); let b=graph_fn3406((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1406(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3454((x*x+49)%65521,d-1); let b=graph_fn3423((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1407(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3455((x*x+50)%65521,d-1); let b=graph_fn3440((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1408(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3456((x*x+51)%65521,d-1); let b=graph_fn3457((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1409(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3457((x*x+52)%65521,d-1); let b=graph_fn3474((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1410(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3458((x*x+53)%65521,d-1); let b=graph_fn3491((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1411(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3459((x*x+54)%65521,d-1); let b=graph_fn3508((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1412(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3460((x*x+55)%65521,d-1); let b=graph_fn3525((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1413(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3461((x*x+56)%65521,d-1); let b=graph_fn3542((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1414(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3462((x*x+57)%65521,d-1); let b=graph_fn3559((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1415(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3463((x*x+58)%65521,d-1); let b=graph_fn3576((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1416(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3464((x*x+59)%65521,d-1); let b=graph_fn3593((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1417(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3465((x*x+60)%65521,d-1); let b=graph_fn3610((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1418(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3466((x*x+61)%65521,d-1); let b=graph_fn3627((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1419(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3467((x*x+62)%65521,d-1); let b=graph_fn3644((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1420(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3468((x*x+63)%65521,d-1); let b=graph_fn3661((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1421(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3469((x*x+64)%65521,d-1); let b=graph_fn3678((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1422(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3470((x*x+65)%65521,d-1); let b=graph_fn3695((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1423(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3471((x*x+66)%65521,d-1); let b=graph_fn3712((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1424(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3472((x*x+67)%65521,d-1); let b=graph_fn3729((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1425(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3473((x*x+68)%65521,d-1); let b=graph_fn3746((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1426(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3474((x*x+69)%65521,d-1); let b=graph_fn3763((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1427(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3475((x*x+70)%65521,d-1); let b=graph_fn3780((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1428(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3476((x*x+71)%65521,d-1); let b=graph_fn3797((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1429(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3477((x*x+72)%65521,d-1); let b=graph_fn3814((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1430(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3478((x*x+73)%65521,d-1); let b=graph_fn3831((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1431(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3479((x*x+74)%65521,d-1); let b=graph_fn3848((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1432(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3480((x*x+75)%65521,d-1); let b=graph_fn3865((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1433(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3481((x*x+76)%65521,d-1); let b=graph_fn3882((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1434(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3482((x*x+77)%65521,d-1); let b=graph_fn3899((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1435(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3483((x*x+78)%65521,d-1); let b=graph_fn3916((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1436(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3484((x*x+79)%65521,d-1); let b=graph_fn3933((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1437(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3485((x*x+80)%65521,d-1); let b=graph_fn3950((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1438(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3486((x*x+81)%65521,d-1); let b=graph_fn3967((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1439(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3487((x*x+82)%65521,d-1); let b=graph_fn3984((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1440(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3488((x*x+83)%65521,d-1); let b=graph_fn4001((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1441(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3489((x*x+84)%65521,d-1); let b=graph_fn4018((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1442(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3490((x*x+85)%65521,d-1); let b=graph_fn4035((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1443(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3491((x*x+86)%65521,d-1); let b=graph_fn4052((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1444(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3492((x*x+87)%65521,d-1); let b=graph_fn4069((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1445(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3493((x*x+88)%65521,d-1); let b=graph_fn4086((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1446(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3494((x*x+89)%65521,d-1); let b=graph_fn2055((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1447(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3495((x*x+90)%65521,d-1); let b=graph_fn2072((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1448(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3496((x*x+91)%65521,d-1); let b=graph_fn2089((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1449(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3497((x*x+92)%65521,d-1); let b=graph_fn2106((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1450(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3498((x*x+93)%65521,d-1); let b=graph_fn2123((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1451(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3499((x*x+94)%65521,d-1); let b=graph_fn2140((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1452(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3500((x*x+95)%65521,d-1); let b=graph_fn2157((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1453(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3501((x*x+96)%65521,d-1); let b=graph_fn2174((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1454(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3502((x*x+97)%65521,d-1); let b=graph_fn2191((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1455(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3503((x*x+1)%65521,d-1); let b=graph_fn2208((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1456(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3504((x*x+2)%65521,d-1); let b=graph_fn2225((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1457(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3505((x*x+3)%65521,d-1); let b=graph_fn2242((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1458(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3506((x*x+4)%65521,d-1); let b=graph_fn2259((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1459(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3507((x*x+5)%65521,d-1); let b=graph_fn2276((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1460(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3508((x*x+6)%65521,d-1); let b=graph_fn2293((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1461(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3509((x*x+7)%65521,d-1); let b=graph_fn2310((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1462(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3510((x*x+8)%65521,d-1); let b=graph_fn2327((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1463(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3511((x*x+9)%65521,d-1); let b=graph_fn2344((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1464(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3512((x*x+10)%65521,d-1); let b=graph_fn2361((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1465(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3513((x*x+11)%65521,d-1); let b=graph_fn2378((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1466(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3514((x*x+12)%65521,d-1); let b=graph_fn2395((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1467(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3515((x*x+13)%65521,d-1); let b=graph_fn2412((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1468(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3516((x*x+14)%65521,d-1); let b=graph_fn2429((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1469(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3517((x*x+15)%65521,d-1); let b=graph_fn2446((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1470(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3518((x*x+16)%65521,d-1); let b=graph_fn2463((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1471(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3519((x*x+17)%65521,d-1); let b=graph_fn2480((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1472(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3520((x*x+18)%65521,d-1); let b=graph_fn2497((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1473(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3521((x*x+19)%65521,d-1); let b=graph_fn2514((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1474(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3522((x*x+20)%65521,d-1); let b=graph_fn2531((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1475(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3523((x*x+21)%65521,d-1); let b=graph_fn2548((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1476(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3524((x*x+22)%65521,d-1); let b=graph_fn2565((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1477(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3525((x*x+23)%65521,d-1); let b=graph_fn2582((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1478(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3526((x*x+24)%65521,d-1); let b=graph_fn2599((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1479(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3527((x*x+25)%65521,d-1); let b=graph_fn2616((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1480(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3528((x*x+26)%65521,d-1); let b=graph_fn2633((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1481(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3529((x*x+27)%65521,d-1); let b=graph_fn2650((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1482(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3530((x*x+28)%65521,d-1); let b=graph_fn2667((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1483(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3531((x*x+29)%65521,d-1); let b=graph_fn2684((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1484(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3532((x*x+30)%65521,d-1); let b=graph_fn2701((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1485(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3533((x*x+31)%65521,d-1); let b=graph_fn2718((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1486(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3534((x*x+32)%65521,d-1); let b=graph_fn2735((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1487(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3535((x*x+33)%65521,d-1); let b=graph_fn2752((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1488(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3536((x*x+34)%65521,d-1); let b=graph_fn2769((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1489(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3537((x*x+35)%65521,d-1); let b=graph_fn2786((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1490(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3538((x*x+36)%65521,d-1); let b=graph_fn2803((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1491(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3539((x*x+37)%65521,d-1); let b=graph_fn2820((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1492(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3540((x*x+38)%65521,d-1); let b=graph_fn2837((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1493(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3541((x*x+39)%65521,d-1); let b=graph_fn2854((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1494(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3542((x*x+40)%65521,d-1); let b=graph_fn2871((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1495(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3543((x*x+41)%65521,d-1); let b=graph_fn2888((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1496(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3544((x*x+42)%65521,d-1); let b=graph_fn2905((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1497(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3545((x*x+43)%65521,d-1); let b=graph_fn2922((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1498(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3546((x*x+44)%65521,d-1); let b=graph_fn2939((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1499(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3547((x*x+45)%65521,d-1); let b=graph_fn2956((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1500(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3548((x*x+46)%65521,d-1); let b=graph_fn2973((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1501(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3549((x*x+47)%65521,d-1); let b=graph_fn2990((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1502(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3550((x*x+48)%65521,d-1); let b=graph_fn3007((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1503(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3551((x*x+49)%65521,d-1); let b=graph_fn3024((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1504(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3552((x*x+50)%65521,d-1); let b=graph_fn3041((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1505(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3553((x*x+51)%65521,d-1); let b=graph_fn3058((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1506(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3554((x*x+52)%65521,d-1); let b=graph_fn3075((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1507(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3555((x*x+53)%65521,d-1); let b=graph_fn3092((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1508(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3556((x*x+54)%65521,d-1); let b=graph_fn3109((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1509(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3557((x*x+55)%65521,d-1); let b=graph_fn3126((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1510(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3558((x*x+56)%65521,d-1); let b=graph_fn3143((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1511(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3559((x*x+57)%65521,d-1); let b=graph_fn3160((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1512(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3560((x*x+58)%65521,d-1); let b=graph_fn3177((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1513(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3561((x*x+59)%65521,d-1); let b=graph_fn3194((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1514(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3562((x*x+60)%65521,d-1); let b=graph_fn3211((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1515(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3563((x*x+61)%65521,d-1); let b=graph_fn3228((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1516(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3564((x*x+62)%65521,d-1); let b=graph_fn3245((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1517(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3565((x*x+63)%65521,d-1); let b=graph_fn3262((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1518(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3566((x*x+64)%65521,d-1); let b=graph_fn3279((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1519(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3567((x*x+65)%65521,d-1); let b=graph_fn3296((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1520(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3568((x*x+66)%65521,d-1); let b=graph_fn3313((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1521(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3569((x*x+67)%65521,d-1); let b=graph_fn3330((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1522(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3570((x*x+68)%65521,d-1); let b=graph_fn3347((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1523(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3571((x*x+69)%65521,d-1); let b=graph_fn3364((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1524(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3572((x*x+70)%65521,d-1); let b=graph_fn3381((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1525(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3573((x*x+71)%65521,d-1); let b=graph_fn3398((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1526(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3574((x*x+72)%65521,d-1); let b=graph_fn3415((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1527(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3575((x*x+73)%65521,d-1); let b=graph_fn3432((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1528(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3576((x*x+74)%65521,d-1); let b=graph_fn3449((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1529(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3577((x*x+75)%65521,d-1); let b=graph_fn3466((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1530(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3578((x*x+76)%65521,d-1); let b=graph_fn3483((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1531(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3579((x*x+77)%65521,d-1); let b=graph_fn3500((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1532(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3580((x*x+78)%65521,d-1); let b=graph_fn3517((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1533(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3581((x*x+79)%65521,d-1); let b=graph_fn3534((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1534(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3582((x*x+80)%65521,d-1); let b=graph_fn3551((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1535(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3583((x*x+81)%65521,d-1); let b=graph_fn3568((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1536(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3584((x*x+82)%65521,d-1); let b=graph_fn3585((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1537(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3585((x*x+83)%65521,d-1); let b=graph_fn3602((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1538(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3586((x*x+84)%65521,d-1); let b=graph_fn3619((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1539(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3587((x*x+85)%65521,d-1); let b=graph_fn3636((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1540(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3588((x*x+86)%65521,d-1); let b=graph_fn3653((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1541(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3589((x*x+87)%65521,d-1); let b=graph_fn3670((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1542(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3590((x*x+88)%65521,d-1); let b=graph_fn3687((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1543(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3591((x*x+89)%65521,d-1); let b=graph_fn3704((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1544(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3592((x*x+90)%65521,d-1); let b=graph_fn3721((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1545(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3593((x*x+91)%65521,d-1); let b=graph_fn3738((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1546(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3594((x*x+92)%65521,d-1); let b=graph_fn3755((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1547(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3595((x*x+93)%65521,d-1); let b=graph_fn3772((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1548(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3596((x*x+94)%65521,d-1); let b=graph_fn3789((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1549(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3597((x*x+95)%65521,d-1); let b=graph_fn3806((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1550(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3598((x*x+96)%65521,d-1); let b=graph_fn3823((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1551(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3599((x*x+97)%65521,d-1); let b=graph_fn3840((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1552(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3600((x*x+1)%65521,d-1); let b=graph_fn3857((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1553(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3601((x*x+2)%65521,d-1); let b=graph_fn3874((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1554(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3602((x*x+3)%65521,d-1); let b=graph_fn3891((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1555(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3603((x*x+4)%65521,d-1); let b=graph_fn3908((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1556(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3604((x*x+5)%65521,d-1); let b=graph_fn3925((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1557(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3605((x*x+6)%65521,d-1); let b=graph_fn3942((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1558(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3606((x*x+7)%65521,d-1); let b=graph_fn3959((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1559(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3607((x*x+8)%65521,d-1); let b=graph_fn3976((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1560(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3608((x*x+9)%65521,d-1); let b=graph_fn3993((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1561(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3609((x*x+10)%65521,d-1); let b=graph_fn4010((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1562(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3610((x*x+11)%65521,d-1); let b=graph_fn4027((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1563(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3611((x*x+12)%65521,d-1); let b=graph_fn4044((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1564(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3612((x*x+13)%65521,d-1); let b=graph_fn4061((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1565(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3613((x*x+14)%65521,d-1); let b=graph_fn4078((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1566(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3614((x*x+15)%65521,d-1); let b=graph_fn4095((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1567(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3615((x*x+16)%65521,d-1); let b=graph_fn2064((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1568(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3616((x*x+17)%65521,d-1); let b=graph_fn2081((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1569(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3617((x*x+18)%65521,d-1); let b=graph_fn2098((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1570(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3618((x*x+19)%65521,d-1); let b=graph_fn2115((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1571(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3619((x*x+20)%65521,d-1); let b=graph_fn2132((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1572(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3620((x*x+21)%65521,d-1); let b=graph_fn2149((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1573(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3621((x*x+22)%65521,d-1); let b=graph_fn2166((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1574(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3622((x*x+23)%65521,d-1); let b=graph_fn2183((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1575(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3623((x*x+24)%65521,d-1); let b=graph_fn2200((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1576(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3624((x*x+25)%65521,d-1); let b=graph_fn2217((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1577(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3625((x*x+26)%65521,d-1); let b=graph_fn2234((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1578(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3626((x*x+27)%65521,d-1); let b=graph_fn2251((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1579(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3627((x*x+28)%65521,d-1); let b=graph_fn2268((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1580(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3628((x*x+29)%65521,d-1); let b=graph_fn2285((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1581(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3629((x*x+30)%65521,d-1); let b=graph_fn2302((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1582(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3630((x*x+31)%65521,d-1); let b=graph_fn2319((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1583(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3631((x*x+32)%65521,d-1); let b=graph_fn2336((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1584(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3632((x*x+33)%65521,d-1); let b=graph_fn2353((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1585(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3633((x*x+34)%65521,d-1); let b=graph_fn2370((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1586(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3634((x*x+35)%65521,d-1); let b=graph_fn2387((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1587(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3635((x*x+36)%65521,d-1); let b=graph_fn2404((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1588(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3636((x*x+37)%65521,d-1); let b=graph_fn2421((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1589(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3637((x*x+38)%65521,d-1); let b=graph_fn2438((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1590(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3638((x*x+39)%65521,d-1); let b=graph_fn2455((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1591(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3639((x*x+40)%65521,d-1); let b=graph_fn2472((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1592(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3640((x*x+41)%65521,d-1); let b=graph_fn2489((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1593(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3641((x*x+42)%65521,d-1); let b=graph_fn2506((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1594(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3642((x*x+43)%65521,d-1); let b=graph_fn2523((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1595(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3643((x*x+44)%65521,d-1); let b=graph_fn2540((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1596(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3644((x*x+45)%65521,d-1); let b=graph_fn2557((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1597(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3645((x*x+46)%65521,d-1); let b=graph_fn2574((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1598(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3646((x*x+47)%65521,d-1); let b=graph_fn2591((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1599(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3647((x*x+48)%65521,d-1); let b=graph_fn2608((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1600(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3648((x*x+49)%65521,d-1); let b=graph_fn2625((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1601(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3649((x*x+50)%65521,d-1); let b=graph_fn2642((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1602(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3650((x*x+51)%65521,d-1); let b=graph_fn2659((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1603(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3651((x*x+52)%65521,d-1); let b=graph_fn2676((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1604(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3652((x*x+53)%65521,d-1); let b=graph_fn2693((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1605(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3653((x*x+54)%65521,d-1); let b=graph_fn2710((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1606(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3654((x*x+55)%65521,d-1); let b=graph_fn2727((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1607(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3655((x*x+56)%65521,d-1); let b=graph_fn2744((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1608(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3656((x*x+57)%65521,d-1); let b=graph_fn2761((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1609(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3657((x*x+58)%65521,d-1); let b=graph_fn2778((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1610(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3658((x*x+59)%65521,d-1); let b=graph_fn2795((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1611(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3659((x*x+60)%65521,d-1); let b=graph_fn2812((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1612(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3660((x*x+61)%65521,d-1); let b=graph_fn2829((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1613(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3661((x*x+62)%65521,d-1); let b=graph_fn2846((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1614(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3662((x*x+63)%65521,d-1); let b=graph_fn2863((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1615(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3663((x*x+64)%65521,d-1); let b=graph_fn2880((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1616(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3664((x*x+65)%65521,d-1); let b=graph_fn2897((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1617(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3665((x*x+66)%65521,d-1); let b=graph_fn2914((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1618(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3666((x*x+67)%65521,d-1); let b=graph_fn2931((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1619(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3667((x*x+68)%65521,d-1); let b=graph_fn2948((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1620(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3668((x*x+69)%65521,d-1); let b=graph_fn2965((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1621(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3669((x*x+70)%65521,d-1); let b=graph_fn2982((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1622(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3670((x*x+71)%65521,d-1); let b=graph_fn2999((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1623(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3671((x*x+72)%65521,d-1); let b=graph_fn3016((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1624(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3672((x*x+73)%65521,d-1); let b=graph_fn3033((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1625(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3673((x*x+74)%65521,d-1); let b=graph_fn3050((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1626(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3674((x*x+75)%65521,d-1); let b=graph_fn3067((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1627(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3675((x*x+76)%65521,d-1); let b=graph_fn3084((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1628(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3676((x*x+77)%65521,d-1); let b=graph_fn3101((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1629(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3677((x*x+78)%65521,d-1); let b=graph_fn3118((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1630(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3678((x*x+79)%65521,d-1); let b=graph_fn3135((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1631(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3679((x*x+80)%65521,d-1); let b=graph_fn3152((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1632(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3680((x*x+81)%65521,d-1); let b=graph_fn3169((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1633(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3681((x*x+82)%65521,d-1); let b=graph_fn3186((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1634(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3682((x*x+83)%65521,d-1); let b=graph_fn3203((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1635(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3683((x*x+84)%65521,d-1); let b=graph_fn3220((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1636(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3684((x*x+85)%65521,d-1); let b=graph_fn3237((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1637(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3685((x*x+86)%65521,d-1); let b=graph_fn3254((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1638(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3686((x*x+87)%65521,d-1); let b=graph_fn3271((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1639(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3687((x*x+88)%65521,d-1); let b=graph_fn3288((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1640(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3688((x*x+89)%65521,d-1); let b=graph_fn3305((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1641(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3689((x*x+90)%65521,d-1); let b=graph_fn3322((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1642(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3690((x*x+91)%65521,d-1); let b=graph_fn3339((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1643(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3691((x*x+92)%65521,d-1); let b=graph_fn3356((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1644(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3692((x*x+93)%65521,d-1); let b=graph_fn3373((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1645(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3693((x*x+94)%65521,d-1); let b=graph_fn3390((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1646(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3694((x*x+95)%65521,d-1); let b=graph_fn3407((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1647(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3695((x*x+96)%65521,d-1); let b=graph_fn3424((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1648(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3696((x*x+97)%65521,d-1); let b=graph_fn3441((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1649(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3697((x*x+1)%65521,d-1); let b=graph_fn3458((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1650(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3698((x*x+2)%65521,d-1); let b=graph_fn3475((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1651(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3699((x*x+3)%65521,d-1); let b=graph_fn3492((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1652(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3700((x*x+4)%65521,d-1); let b=graph_fn3509((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1653(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3701((x*x+5)%65521,d-1); let b=graph_fn3526((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1654(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3702((x*x+6)%65521,d-1); let b=graph_fn3543((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1655(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3703((x*x+7)%65521,d-1); let b=graph_fn3560((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1656(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3704((x*x+8)%65521,d-1); let b=graph_fn3577((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1657(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3705((x*x+9)%65521,d-1); let b=graph_fn3594((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1658(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3706((x*x+10)%65521,d-1); let b=graph_fn3611((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1659(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3707((x*x+11)%65521,d-1); let b=graph_fn3628((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1660(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3708((x*x+12)%65521,d-1); let b=graph_fn3645((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1661(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3709((x*x+13)%65521,d-1); let b=graph_fn3662((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1662(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3710((x*x+14)%65521,d-1); let b=graph_fn3679((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1663(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3711((x*x+15)%65521,d-1); let b=graph_fn3696((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1664(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3712((x*x+16)%65521,d-1); let b=graph_fn3713((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1665(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3713((x*x+17)%65521,d-1); let b=graph_fn3730((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1666(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3714((x*x+18)%65521,d-1); let b=graph_fn3747((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1667(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3715((x*x+19)%65521,d-1); let b=graph_fn3764((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1668(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3716((x*x+20)%65521,d-1); let b=graph_fn3781((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1669(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3717((x*x+21)%65521,d-1); let b=graph_fn3798((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1670(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3718((x*x+22)%65521,d-1); let b=graph_fn3815((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1671(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3719((x*x+23)%65521,d-1); let b=graph_fn3832((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1672(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3720((x*x+24)%65521,d-1); let b=graph_fn3849((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1673(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3721((x*x+25)%65521,d-1); let b=graph_fn3866((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1674(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3722((x*x+26)%65521,d-1); let b=graph_fn3883((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1675(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3723((x*x+27)%65521,d-1); let b=graph_fn3900((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1676(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3724((x*x+28)%65521,d-1); let b=graph_fn3917((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1677(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3725((x*x+29)%65521,d-1); let b=graph_fn3934((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1678(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3726((x*x+30)%65521,d-1); let b=graph_fn3951((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1679(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3727((x*x+31)%65521,d-1); let b=graph_fn3968((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1680(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3728((x*x+32)%65521,d-1); let b=graph_fn3985((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1681(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3729((x*x+33)%65521,d-1); let b=graph_fn4002((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1682(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3730((x*x+34)%65521,d-1); let b=graph_fn4019((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1683(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3731((x*x+35)%65521,d-1); let b=graph_fn4036((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1684(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3732((x*x+36)%65521,d-1); let b=graph_fn4053((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1685(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3733((x*x+37)%65521,d-1); let b=graph_fn4070((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1686(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3734((x*x+38)%65521,d-1); let b=graph_fn4087((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1687(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3735((x*x+39)%65521,d-1); let b=graph_fn2056((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1688(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3736((x*x+40)%65521,d-1); let b=graph_fn2073((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1689(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3737((x*x+41)%65521,d-1); let b=graph_fn2090((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1690(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3738((x*x+42)%65521,d-1); let b=graph_fn2107((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1691(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3739((x*x+43)%65521,d-1); let b=graph_fn2124((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1692(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3740((x*x+44)%65521,d-1); let b=graph_fn2141((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1693(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3741((x*x+45)%65521,d-1); let b=graph_fn2158((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1694(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3742((x*x+46)%65521,d-1); let b=graph_fn2175((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1695(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3743((x*x+47)%65521,d-1); let b=graph_fn2192((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1696(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3744((x*x+48)%65521,d-1); let b=graph_fn2209((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1697(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3745((x*x+49)%65521,d-1); let b=graph_fn2226((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1698(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3746((x*x+50)%65521,d-1); let b=graph_fn2243((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1699(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3747((x*x+51)%65521,d-1); let b=graph_fn2260((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1700(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3748((x*x+52)%65521,d-1); let b=graph_fn2277((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1701(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3749((x*x+53)%65521,d-1); let b=graph_fn2294((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1702(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3750((x*x+54)%65521,d-1); let b=graph_fn2311((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1703(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3751((x*x+55)%65521,d-1); let b=graph_fn2328((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1704(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3752((x*x+56)%65521,d-1); let b=graph_fn2345((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1705(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3753((x*x+57)%65521,d-1); let b=graph_fn2362((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1706(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3754((x*x+58)%65521,d-1); let b=graph_fn2379((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1707(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3755((x*x+59)%65521,d-1); let b=graph_fn2396((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1708(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3756((x*x+60)%65521,d-1); let b=graph_fn2413((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1709(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3757((x*x+61)%65521,d-1); let b=graph_fn2430((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1710(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3758((x*x+62)%65521,d-1); let b=graph_fn2447((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1711(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3759((x*x+63)%65521,d-1); let b=graph_fn2464((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1712(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3760((x*x+64)%65521,d-1); let b=graph_fn2481((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1713(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3761((x*x+65)%65521,d-1); let b=graph_fn2498((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1714(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3762((x*x+66)%65521,d-1); let b=graph_fn2515((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1715(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3763((x*x+67)%65521,d-1); let b=graph_fn2532((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1716(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3764((x*x+68)%65521,d-1); let b=graph_fn2549((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1717(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3765((x*x+69)%65521,d-1); let b=graph_fn2566((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1718(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3766((x*x+70)%65521,d-1); let b=graph_fn2583((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1719(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3767((x*x+71)%65521,d-1); let b=graph_fn2600((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1720(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3768((x*x+72)%65521,d-1); let b=graph_fn2617((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1721(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3769((x*x+73)%65521,d-1); let b=graph_fn2634((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1722(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3770((x*x+74)%65521,d-1); let b=graph_fn2651((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1723(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3771((x*x+75)%65521,d-1); let b=graph_fn2668((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1724(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3772((x*x+76)%65521,d-1); let b=graph_fn2685((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1725(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3773((x*x+77)%65521,d-1); let b=graph_fn2702((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1726(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3774((x*x+78)%65521,d-1); let b=graph_fn2719((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1727(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3775((x*x+79)%65521,d-1); let b=graph_fn2736((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1728(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3776((x*x+80)%65521,d-1); let b=graph_fn2753((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1729(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3777((x*x+81)%65521,d-1); let b=graph_fn2770((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1730(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3778((x*x+82)%65521,d-1); let b=graph_fn2787((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1731(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3779((x*x+83)%65521,d-1); let b=graph_fn2804((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1732(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3780((x*x+84)%65521,d-1); let b=graph_fn2821((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1733(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3781((x*x+85)%65521,d-1); let b=graph_fn2838((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1734(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3782((x*x+86)%65521,d-1); let b=graph_fn2855((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1735(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3783((x*x+87)%65521,d-1); let b=graph_fn2872((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1736(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3784((x*x+88)%65521,d-1); let b=graph_fn2889((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1737(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3785((x*x+89)%65521,d-1); let b=graph_fn2906((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1738(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3786((x*x+90)%65521,d-1); let b=graph_fn2923((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1739(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3787((x*x+91)%65521,d-1); let b=graph_fn2940((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1740(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3788((x*x+92)%65521,d-1); let b=graph_fn2957((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1741(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3789((x*x+93)%65521,d-1); let b=graph_fn2974((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1742(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3790((x*x+94)%65521,d-1); let b=graph_fn2991((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1743(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3791((x*x+95)%65521,d-1); let b=graph_fn3008((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1744(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3792((x*x+96)%65521,d-1); let b=graph_fn3025((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1745(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3793((x*x+97)%65521,d-1); let b=graph_fn3042((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1746(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3794((x*x+1)%65521,d-1); let b=graph_fn3059((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1747(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3795((x*x+2)%65521,d-1); let b=graph_fn3076((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1748(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3796((x*x+3)%65521,d-1); let b=graph_fn3093((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1749(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3797((x*x+4)%65521,d-1); let b=graph_fn3110((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1750(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3798((x*x+5)%65521,d-1); let b=graph_fn3127((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1751(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3799((x*x+6)%65521,d-1); let b=graph_fn3144((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1752(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3800((x*x+7)%65521,d-1); let b=graph_fn3161((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1753(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3801((x*x+8)%65521,d-1); let b=graph_fn3178((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1754(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3802((x*x+9)%65521,d-1); let b=graph_fn3195((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1755(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3803((x*x+10)%65521,d-1); let b=graph_fn3212((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1756(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3804((x*x+11)%65521,d-1); let b=graph_fn3229((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1757(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3805((x*x+12)%65521,d-1); let b=graph_fn3246((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1758(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3806((x*x+13)%65521,d-1); let b=graph_fn3263((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1759(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3807((x*x+14)%65521,d-1); let b=graph_fn3280((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1760(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3808((x*x+15)%65521,d-1); let b=graph_fn3297((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1761(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3809((x*x+16)%65521,d-1); let b=graph_fn3314((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1762(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3810((x*x+17)%65521,d-1); let b=graph_fn3331((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1763(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3811((x*x+18)%65521,d-1); let b=graph_fn3348((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1764(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3812((x*x+19)%65521,d-1); let b=graph_fn3365((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1765(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3813((x*x+20)%65521,d-1); let b=graph_fn3382((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1766(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3814((x*x+21)%65521,d-1); let b=graph_fn3399((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1767(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3815((x*x+22)%65521,d-1); let b=graph_fn3416((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1768(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3816((x*x+23)%65521,d-1); let b=graph_fn3433((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1769(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3817((x*x+24)%65521,d-1); let b=graph_fn3450((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1770(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3818((x*x+25)%65521,d-1); let b=graph_fn3467((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1771(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3819((x*x+26)%65521,d-1); let b=graph_fn3484((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1772(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3820((x*x+27)%65521,d-1); let b=graph_fn3501((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1773(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3821((x*x+28)%65521,d-1); let b=graph_fn3518((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1774(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3822((x*x+29)%65521,d-1); let b=graph_fn3535((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1775(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3823((x*x+30)%65521,d-1); let b=graph_fn3552((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1776(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3824((x*x+31)%65521,d-1); let b=graph_fn3569((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1777(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3825((x*x+32)%65521,d-1); let b=graph_fn3586((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1778(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3826((x*x+33)%65521,d-1); let b=graph_fn3603((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1779(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3827((x*x+34)%65521,d-1); let b=graph_fn3620((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1780(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3828((x*x+35)%65521,d-1); let b=graph_fn3637((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1781(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3829((x*x+36)%65521,d-1); let b=graph_fn3654((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1782(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3830((x*x+37)%65521,d-1); let b=graph_fn3671((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1783(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3831((x*x+38)%65521,d-1); let b=graph_fn3688((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1784(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3832((x*x+39)%65521,d-1); let b=graph_fn3705((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1785(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3833((x*x+40)%65521,d-1); let b=graph_fn3722((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1786(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3834((x*x+41)%65521,d-1); let b=graph_fn3739((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1787(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3835((x*x+42)%65521,d-1); let b=graph_fn3756((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1788(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3836((x*x+43)%65521,d-1); let b=graph_fn3773((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1789(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3837((x*x+44)%65521,d-1); let b=graph_fn3790((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1790(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3838((x*x+45)%65521,d-1); let b=graph_fn3807((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1791(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3839((x*x+46)%65521,d-1); let b=graph_fn3824((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1792(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3840((x*x+47)%65521,d-1); let b=graph_fn3841((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1793(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3841((x*x+48)%65521,d-1); let b=graph_fn3858((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1794(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3842((x*x+49)%65521,d-1); let b=graph_fn3875((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1795(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3843((x*x+50)%65521,d-1); let b=graph_fn3892((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1796(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3844((x*x+51)%65521,d-1); let b=graph_fn3909((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1797(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3845((x*x+52)%65521,d-1); let b=graph_fn3926((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1798(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3846((x*x+53)%65521,d-1); let b=graph_fn3943((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1799(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3847((x*x+54)%65521,d-1); let b=graph_fn3960((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1800(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3848((x*x+55)%65521,d-1); let b=graph_fn3977((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1801(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3849((x*x+56)%65521,d-1); let b=graph_fn3994((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1802(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3850((x*x+57)%65521,d-1); let b=graph_fn4011((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1803(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3851((x*x+58)%65521,d-1); let b=graph_fn4028((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1804(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3852((x*x+59)%65521,d-1); let b=graph_fn4045((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1805(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3853((x*x+60)%65521,d-1); let b=graph_fn4062((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1806(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3854((x*x+61)%65521,d-1); let b=graph_fn4079((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1807(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3855((x*x+62)%65521,d-1); let b=graph_fn2048((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1808(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3856((x*x+63)%65521,d-1); let b=graph_fn2065((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1809(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3857((x*x+64)%65521,d-1); let b=graph_fn2082((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1810(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3858((x*x+65)%65521,d-1); let b=graph_fn2099((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1811(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3859((x*x+66)%65521,d-1); let b=graph_fn2116((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1812(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3860((x*x+67)%65521,d-1); let b=graph_fn2133((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1813(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3861((x*x+68)%65521,d-1); let b=graph_fn2150((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1814(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3862((x*x+69)%65521,d-1); let b=graph_fn2167((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1815(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3863((x*x+70)%65521,d-1); let b=graph_fn2184((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1816(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3864((x*x+71)%65521,d-1); let b=graph_fn2201((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1817(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3865((x*x+72)%65521,d-1); let b=graph_fn2218((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1818(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3866((x*x+73)%65521,d-1); let b=graph_fn2235((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1819(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3867((x*x+74)%65521,d-1); let b=graph_fn2252((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1820(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3868((x*x+75)%65521,d-1); let b=graph_fn2269((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1821(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3869((x*x+76)%65521,d-1); let b=graph_fn2286((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1822(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3870((x*x+77)%65521,d-1); let b=graph_fn2303((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1823(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3871((x*x+78)%65521,d-1); let b=graph_fn2320((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1824(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3872((x*x+79)%65521,d-1); let b=graph_fn2337((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1825(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3873((x*x+80)%65521,d-1); let b=graph_fn2354((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1826(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3874((x*x+81)%65521,d-1); let b=graph_fn2371((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1827(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3875((x*x+82)%65521,d-1); let b=graph_fn2388((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1828(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3876((x*x+83)%65521,d-1); let b=graph_fn2405((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1829(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3877((x*x+84)%65521,d-1); let b=graph_fn2422((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1830(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3878((x*x+85)%65521,d-1); let b=graph_fn2439((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1831(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3879((x*x+86)%65521,d-1); let b=graph_fn2456((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1832(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3880((x*x+87)%65521,d-1); let b=graph_fn2473((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1833(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3881((x*x+88)%65521,d-1); let b=graph_fn2490((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1834(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3882((x*x+89)%65521,d-1); let b=graph_fn2507((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1835(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3883((x*x+90)%65521,d-1); let b=graph_fn2524((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1836(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3884((x*x+91)%65521,d-1); let b=graph_fn2541((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1837(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3885((x*x+92)%65521,d-1); let b=graph_fn2558((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1838(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3886((x*x+93)%65521,d-1); let b=graph_fn2575((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1839(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3887((x*x+94)%65521,d-1); let b=graph_fn2592((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1840(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3888((x*x+95)%65521,d-1); let b=graph_fn2609((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1841(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3889((x*x+96)%65521,d-1); let b=graph_fn2626((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1842(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3890((x*x+97)%65521,d-1); let b=graph_fn2643((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1843(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3891((x*x+1)%65521,d-1); let b=graph_fn2660((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1844(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3892((x*x+2)%65521,d-1); let b=graph_fn2677((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1845(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3893((x*x+3)%65521,d-1); let b=graph_fn2694((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1846(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3894((x*x+4)%65521,d-1); let b=graph_fn2711((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1847(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3895((x*x+5)%65521,d-1); let b=graph_fn2728((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1848(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3896((x*x+6)%65521,d-1); let b=graph_fn2745((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1849(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3897((x*x+7)%65521,d-1); let b=graph_fn2762((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1850(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3898((x*x+8)%65521,d-1); let b=graph_fn2779((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1851(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3899((x*x+9)%65521,d-1); let b=graph_fn2796((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1852(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3900((x*x+10)%65521,d-1); let b=graph_fn2813((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1853(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3901((x*x+11)%65521,d-1); let b=graph_fn2830((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1854(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3902((x*x+12)%65521,d-1); let b=graph_fn2847((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1855(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn3903((x*x+13)%65521,d-1); let b=graph_fn2864((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1856(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn3904((x*x+14)%65521,d-1); let b=graph_fn2881((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1857(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn3905((x*x+15)%65521,d-1); let b=graph_fn2898((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1858(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn3906((x*x+16)%65521,d-1); let b=graph_fn2915((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1859(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn3907((x*x+17)%65521,d-1); let b=graph_fn2932((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1860(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn3908((x*x+18)%65521,d-1); let b=graph_fn2949((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1861(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn3909((x*x+19)%65521,d-1); let b=graph_fn2966((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1862(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn3910((x*x+20)%65521,d-1); let b=graph_fn2983((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1863(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn3911((x*x+21)%65521,d-1); let b=graph_fn3000((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1864(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn3912((x*x+22)%65521,d-1); let b=graph_fn3017((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1865(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn3913((x*x+23)%65521,d-1); let b=graph_fn3034((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1866(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn3914((x*x+24)%65521,d-1); let b=graph_fn3051((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1867(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn3915((x*x+25)%65521,d-1); let b=graph_fn3068((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1868(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn3916((x*x+26)%65521,d-1); let b=graph_fn3085((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1869(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn3917((x*x+27)%65521,d-1); let b=graph_fn3102((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1870(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn3918((x*x+28)%65521,d-1); let b=graph_fn3119((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1871(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn3919((x*x+29)%65521,d-1); let b=graph_fn3136((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1872(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn3920((x*x+30)%65521,d-1); let b=graph_fn3153((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1873(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn3921((x*x+31)%65521,d-1); let b=graph_fn3170((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1874(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn3922((x*x+32)%65521,d-1); let b=graph_fn3187((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1875(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn3923((x*x+33)%65521,d-1); let b=graph_fn3204((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1876(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn3924((x*x+34)%65521,d-1); let b=graph_fn3221((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1877(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn3925((x*x+35)%65521,d-1); let b=graph_fn3238((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1878(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn3926((x*x+36)%65521,d-1); let b=graph_fn3255((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1879(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn3927((x*x+37)%65521,d-1); let b=graph_fn3272((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1880(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn3928((x*x+38)%65521,d-1); let b=graph_fn3289((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1881(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn3929((x*x+39)%65521,d-1); let b=graph_fn3306((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1882(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn3930((x*x+40)%65521,d-1); let b=graph_fn3323((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1883(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn3931((x*x+41)%65521,d-1); let b=graph_fn3340((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1884(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn3932((x*x+42)%65521,d-1); let b=graph_fn3357((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1885(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn3933((x*x+43)%65521,d-1); let b=graph_fn3374((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1886(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn3934((x*x+44)%65521,d-1); let b=graph_fn3391((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1887(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn3935((x*x+45)%65521,d-1); let b=graph_fn3408((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1888(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn3936((x*x+46)%65521,d-1); let b=graph_fn3425((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1889(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn3937((x*x+47)%65521,d-1); let b=graph_fn3442((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1890(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn3938((x*x+48)%65521,d-1); let b=graph_fn3459((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1891(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn3939((x*x+49)%65521,d-1); let b=graph_fn3476((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1892(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn3940((x*x+50)%65521,d-1); let b=graph_fn3493((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1893(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn3941((x*x+51)%65521,d-1); let b=graph_fn3510((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1894(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn3942((x*x+52)%65521,d-1); let b=graph_fn3527((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1895(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn3943((x*x+53)%65521,d-1); let b=graph_fn3544((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1896(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn3944((x*x+54)%65521,d-1); let b=graph_fn3561((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1897(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn3945((x*x+55)%65521,d-1); let b=graph_fn3578((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1898(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn3946((x*x+56)%65521,d-1); let b=graph_fn3595((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1899(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn3947((x*x+57)%65521,d-1); let b=graph_fn3612((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1900(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn3948((x*x+58)%65521,d-1); let b=graph_fn3629((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1901(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn3949((x*x+59)%65521,d-1); let b=graph_fn3646((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1902(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn3950((x*x+60)%65521,d-1); let b=graph_fn3663((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn1903(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn3951((x*x+61)%65521,d-1); let b=graph_fn3680((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn1904(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn3952((x*x+62)%65521,d-1); let b=graph_fn3697((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn1905(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn3953((x*x+63)%65521,d-1); let b=graph_fn3714((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn1906(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn3954((x*x+64)%65521,d-1); let b=graph_fn3731((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn1907(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn3955((x*x+65)%65521,d-1); let b=graph_fn3748((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn1908(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn3956((x*x+66)%65521,d-1); let b=graph_fn3765((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn1909(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn3957((x*x+67)%65521,d-1); let b=graph_fn3782((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn1910(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn3958((x*x+68)%65521,d-1); let b=graph_fn3799((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn1911(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn3959((x*x+69)%65521,d-1); let b=graph_fn3816((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn1912(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn3960((x*x+70)%65521,d-1); let b=graph_fn3833((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn1913(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn3961((x*x+71)%65521,d-1); let b=graph_fn3850((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn1914(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn3962((x*x+72)%65521,d-1); let b=graph_fn3867((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn1915(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn3963((x*x+73)%65521,d-1); let b=graph_fn3884((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn1916(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn3964((x*x+74)%65521,d-1); let b=graph_fn3901((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn1917(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn3965((x*x+75)%65521,d-1); let b=graph_fn3918((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn1918(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn3966((x*x+76)%65521,d-1); let b=graph_fn3935((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn1919(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn3967((x*x+77)%65521,d-1); let b=graph_fn3952((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn1920(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn3968((x*x+78)%65521,d-1); let b=graph_fn3969((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn1921(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn3969((x*x+79)%65521,d-1); let b=graph_fn3986((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn1922(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn3970((x*x+80)%65521,d-1); let b=graph_fn4003((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn1923(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn3971((x*x+81)%65521,d-1); let b=graph_fn4020((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn1924(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn3972((x*x+82)%65521,d-1); let b=graph_fn4037((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn1925(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn3973((x*x+83)%65521,d-1); let b=graph_fn4054((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn1926(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn3974((x*x+84)%65521,d-1); let b=graph_fn4071((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn1927(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn3975((x*x+85)%65521,d-1); let b=graph_fn4088((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn1928(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn3976((x*x+86)%65521,d-1); let b=graph_fn2057((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn1929(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn3977((x*x+87)%65521,d-1); let b=graph_fn2074((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn1930(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn3978((x*x+88)%65521,d-1); let b=graph_fn2091((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn1931(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn3979((x*x+89)%65521,d-1); let b=graph_fn2108((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn1932(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn3980((x*x+90)%65521,d-1); let b=graph_fn2125((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn1933(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn3981((x*x+91)%65521,d-1); let b=graph_fn2142((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn1934(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn3982((x*x+92)%65521,d-1); let b=graph_fn2159((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn1935(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn3983((x*x+93)%65521,d-1); let b=graph_fn2176((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn1936(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn3984((x*x+94)%65521,d-1); let b=graph_fn2193((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn1937(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn3985((x*x+95)%65521,d-1); let b=graph_fn2210((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn1938(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn3986((x*x+96)%65521,d-1); let b=graph_fn2227((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn1939(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn3987((x*x+97)%65521,d-1); let b=graph_fn2244((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn1940(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn3988((x*x+1)%65521,d-1); let b=graph_fn2261((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn1941(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn3989((x*x+2)%65521,d-1); let b=graph_fn2278((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn1942(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn3990((x*x+3)%65521,d-1); let b=graph_fn2295((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn1943(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn3991((x*x+4)%65521,d-1); let b=graph_fn2312((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn1944(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn3992((x*x+5)%65521,d-1); let b=graph_fn2329((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn1945(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn3993((x*x+6)%65521,d-1); let b=graph_fn2346((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn1946(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn3994((x*x+7)%65521,d-1); let b=graph_fn2363((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn1947(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn3995((x*x+8)%65521,d-1); let b=graph_fn2380((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn1948(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn3996((x*x+9)%65521,d-1); let b=graph_fn2397((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn1949(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn3997((x*x+10)%65521,d-1); let b=graph_fn2414((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn1950(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn3998((x*x+11)%65521,d-1); let b=graph_fn2431((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn1951(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} let a=graph_fn3999((x*x+12)%65521,d-1); let b=graph_fn2448((a+x+3)%65521,d-1); return (b*31+x+12)%65521; }
fn graph_fn1952(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} let a=graph_fn4000((x*x+13)%65521,d-1); let b=graph_fn2465((a+x+3)%65521,d-1); return (b*31+x+13)%65521; }
fn graph_fn1953(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} let a=graph_fn4001((x*x+14)%65521,d-1); let b=graph_fn2482((a+x+3)%65521,d-1); return (b*31+x+14)%65521; }
fn graph_fn1954(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} let a=graph_fn4002((x*x+15)%65521,d-1); let b=graph_fn2499((a+x+3)%65521,d-1); return (b*31+x+15)%65521; }
fn graph_fn1955(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} let a=graph_fn4003((x*x+16)%65521,d-1); let b=graph_fn2516((a+x+3)%65521,d-1); return (b*31+x+16)%65521; }
fn graph_fn1956(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} let a=graph_fn4004((x*x+17)%65521,d-1); let b=graph_fn2533((a+x+3)%65521,d-1); return (b*31+x+17)%65521; }
fn graph_fn1957(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} let a=graph_fn4005((x*x+18)%65521,d-1); let b=graph_fn2550((a+x+3)%65521,d-1); return (b*31+x+18)%65521; }
fn graph_fn1958(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} let a=graph_fn4006((x*x+19)%65521,d-1); let b=graph_fn2567((a+x+3)%65521,d-1); return (b*31+x+19)%65521; }
fn graph_fn1959(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} let a=graph_fn4007((x*x+20)%65521,d-1); let b=graph_fn2584((a+x+3)%65521,d-1); return (b*31+x+20)%65521; }
fn graph_fn1960(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} let a=graph_fn4008((x*x+21)%65521,d-1); let b=graph_fn2601((a+x+3)%65521,d-1); return (b*31+x+21)%65521; }
fn graph_fn1961(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} let a=graph_fn4009((x*x+22)%65521,d-1); let b=graph_fn2618((a+x+3)%65521,d-1); return (b*31+x+22)%65521; }
fn graph_fn1962(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} let a=graph_fn4010((x*x+23)%65521,d-1); let b=graph_fn2635((a+x+3)%65521,d-1); return (b*31+x+23)%65521; }
fn graph_fn1963(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} let a=graph_fn4011((x*x+24)%65521,d-1); let b=graph_fn2652((a+x+3)%65521,d-1); return (b*31+x+24)%65521; }
fn graph_fn1964(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} let a=graph_fn4012((x*x+25)%65521,d-1); let b=graph_fn2669((a+x+3)%65521,d-1); return (b*31+x+25)%65521; }
fn graph_fn1965(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} let a=graph_fn4013((x*x+26)%65521,d-1); let b=graph_fn2686((a+x+3)%65521,d-1); return (b*31+x+26)%65521; }
fn graph_fn1966(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} let a=graph_fn4014((x*x+27)%65521,d-1); let b=graph_fn2703((a+x+3)%65521,d-1); return (b*31+x+27)%65521; }
fn graph_fn1967(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} let a=graph_fn4015((x*x+28)%65521,d-1); let b=graph_fn2720((a+x+3)%65521,d-1); return (b*31+x+28)%65521; }
fn graph_fn1968(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} let a=graph_fn4016((x*x+29)%65521,d-1); let b=graph_fn2737((a+x+3)%65521,d-1); return (b*31+x+29)%65521; }
fn graph_fn1969(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} let a=graph_fn4017((x*x+30)%65521,d-1); let b=graph_fn2754((a+x+3)%65521,d-1); return (b*31+x+30)%65521; }
fn graph_fn1970(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} let a=graph_fn4018((x*x+31)%65521,d-1); let b=graph_fn2771((a+x+3)%65521,d-1); return (b*31+x+31)%65521; }
fn graph_fn1971(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} let a=graph_fn4019((x*x+32)%65521,d-1); let b=graph_fn2788((a+x+3)%65521,d-1); return (b*31+x+32)%65521; }
fn graph_fn1972(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} let a=graph_fn4020((x*x+33)%65521,d-1); let b=graph_fn2805((a+x+3)%65521,d-1); return (b*31+x+33)%65521; }
fn graph_fn1973(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} let a=graph_fn4021((x*x+34)%65521,d-1); let b=graph_fn2822((a+x+3)%65521,d-1); return (b*31+x+34)%65521; }
fn graph_fn1974(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} let a=graph_fn4022((x*x+35)%65521,d-1); let b=graph_fn2839((a+x+3)%65521,d-1); return (b*31+x+35)%65521; }
fn graph_fn1975(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} let a=graph_fn4023((x*x+36)%65521,d-1); let b=graph_fn2856((a+x+3)%65521,d-1); return (b*31+x+36)%65521; }
fn graph_fn1976(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} let a=graph_fn4024((x*x+37)%65521,d-1); let b=graph_fn2873((a+x+3)%65521,d-1); return (b*31+x+37)%65521; }
fn graph_fn1977(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} let a=graph_fn4025((x*x+38)%65521,d-1); let b=graph_fn2890((a+x+3)%65521,d-1); return (b*31+x+38)%65521; }
fn graph_fn1978(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} let a=graph_fn4026((x*x+39)%65521,d-1); let b=graph_fn2907((a+x+3)%65521,d-1); return (b*31+x+39)%65521; }
fn graph_fn1979(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} let a=graph_fn4027((x*x+40)%65521,d-1); let b=graph_fn2924((a+x+3)%65521,d-1); return (b*31+x+40)%65521; }
fn graph_fn1980(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} let a=graph_fn4028((x*x+41)%65521,d-1); let b=graph_fn2941((a+x+3)%65521,d-1); return (b*31+x+41)%65521; }
fn graph_fn1981(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} let a=graph_fn4029((x*x+42)%65521,d-1); let b=graph_fn2958((a+x+3)%65521,d-1); return (b*31+x+42)%65521; }
fn graph_fn1982(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} let a=graph_fn4030((x*x+43)%65521,d-1); let b=graph_fn2975((a+x+3)%65521,d-1); return (b*31+x+43)%65521; }
fn graph_fn1983(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} let a=graph_fn4031((x*x+44)%65521,d-1); let b=graph_fn2992((a+x+3)%65521,d-1); return (b*31+x+44)%65521; }
fn graph_fn1984(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} let a=graph_fn4032((x*x+45)%65521,d-1); let b=graph_fn3009((a+x+3)%65521,d-1); return (b*31+x+45)%65521; }
fn graph_fn1985(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} let a=graph_fn4033((x*x+46)%65521,d-1); let b=graph_fn3026((a+x+3)%65521,d-1); return (b*31+x+46)%65521; }
fn graph_fn1986(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} let a=graph_fn4034((x*x+47)%65521,d-1); let b=graph_fn3043((a+x+3)%65521,d-1); return (b*31+x+47)%65521; }
fn graph_fn1987(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} let a=graph_fn4035((x*x+48)%65521,d-1); let b=graph_fn3060((a+x+3)%65521,d-1); return (b*31+x+48)%65521; }
fn graph_fn1988(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} let a=graph_fn4036((x*x+49)%65521,d-1); let b=graph_fn3077((a+x+3)%65521,d-1); return (b*31+x+49)%65521; }
fn graph_fn1989(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} let a=graph_fn4037((x*x+50)%65521,d-1); let b=graph_fn3094((a+x+3)%65521,d-1); return (b*31+x+50)%65521; }
fn graph_fn1990(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} let a=graph_fn4038((x*x+51)%65521,d-1); let b=graph_fn3111((a+x+3)%65521,d-1); return (b*31+x+51)%65521; }
fn graph_fn1991(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} let a=graph_fn4039((x*x+52)%65521,d-1); let b=graph_fn3128((a+x+3)%65521,d-1); return (b*31+x+52)%65521; }
fn graph_fn1992(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} let a=graph_fn4040((x*x+53)%65521,d-1); let b=graph_fn3145((a+x+3)%65521,d-1); return (b*31+x+53)%65521; }
fn graph_fn1993(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} let a=graph_fn4041((x*x+54)%65521,d-1); let b=graph_fn3162((a+x+3)%65521,d-1); return (b*31+x+54)%65521; }
fn graph_fn1994(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} let a=graph_fn4042((x*x+55)%65521,d-1); let b=graph_fn3179((a+x+3)%65521,d-1); return (b*31+x+55)%65521; }
fn graph_fn1995(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} let a=graph_fn4043((x*x+56)%65521,d-1); let b=graph_fn3196((a+x+3)%65521,d-1); return (b*31+x+56)%65521; }
fn graph_fn1996(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} let a=graph_fn4044((x*x+57)%65521,d-1); let b=graph_fn3213((a+x+3)%65521,d-1); return (b*31+x+57)%65521; }
fn graph_fn1997(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} let a=graph_fn4045((x*x+58)%65521,d-1); let b=graph_fn3230((a+x+3)%65521,d-1); return (b*31+x+58)%65521; }
fn graph_fn1998(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} let a=graph_fn4046((x*x+59)%65521,d-1); let b=graph_fn3247((a+x+3)%65521,d-1); return (b*31+x+59)%65521; }
fn graph_fn1999(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} let a=graph_fn4047((x*x+60)%65521,d-1); let b=graph_fn3264((a+x+3)%65521,d-1); return (b*31+x+60)%65521; }
fn graph_fn2000(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} let a=graph_fn4048((x*x+61)%65521,d-1); let b=graph_fn3281((a+x+3)%65521,d-1); return (b*31+x+61)%65521; }
fn graph_fn2001(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} let a=graph_fn4049((x*x+62)%65521,d-1); let b=graph_fn3298((a+x+3)%65521,d-1); return (b*31+x+62)%65521; }
fn graph_fn2002(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} let a=graph_fn4050((x*x+63)%65521,d-1); let b=graph_fn3315((a+x+3)%65521,d-1); return (b*31+x+63)%65521; }
fn graph_fn2003(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} let a=graph_fn4051((x*x+64)%65521,d-1); let b=graph_fn3332((a+x+3)%65521,d-1); return (b*31+x+64)%65521; }
fn graph_fn2004(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} let a=graph_fn4052((x*x+65)%65521,d-1); let b=graph_fn3349((a+x+3)%65521,d-1); return (b*31+x+65)%65521; }
fn graph_fn2005(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} let a=graph_fn4053((x*x+66)%65521,d-1); let b=graph_fn3366((a+x+3)%65521,d-1); return (b*31+x+66)%65521; }
fn graph_fn2006(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} let a=graph_fn4054((x*x+67)%65521,d-1); let b=graph_fn3383((a+x+3)%65521,d-1); return (b*31+x+67)%65521; }
fn graph_fn2007(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} let a=graph_fn4055((x*x+68)%65521,d-1); let b=graph_fn3400((a+x+3)%65521,d-1); return (b*31+x+68)%65521; }
fn graph_fn2008(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} let a=graph_fn4056((x*x+69)%65521,d-1); let b=graph_fn3417((a+x+3)%65521,d-1); return (b*31+x+69)%65521; }
fn graph_fn2009(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} let a=graph_fn4057((x*x+70)%65521,d-1); let b=graph_fn3434((a+x+3)%65521,d-1); return (b*31+x+70)%65521; }
fn graph_fn2010(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} let a=graph_fn4058((x*x+71)%65521,d-1); let b=graph_fn3451((a+x+3)%65521,d-1); return (b*31+x+71)%65521; }
fn graph_fn2011(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} let a=graph_fn4059((x*x+72)%65521,d-1); let b=graph_fn3468((a+x+3)%65521,d-1); return (b*31+x+72)%65521; }
fn graph_fn2012(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} let a=graph_fn4060((x*x+73)%65521,d-1); let b=graph_fn3485((a+x+3)%65521,d-1); return (b*31+x+73)%65521; }
fn graph_fn2013(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} let a=graph_fn4061((x*x+74)%65521,d-1); let b=graph_fn3502((a+x+3)%65521,d-1); return (b*31+x+74)%65521; }
fn graph_fn2014(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} let a=graph_fn4062((x*x+75)%65521,d-1); let b=graph_fn3519((a+x+3)%65521,d-1); return (b*31+x+75)%65521; }
fn graph_fn2015(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} let a=graph_fn4063((x*x+76)%65521,d-1); let b=graph_fn3536((a+x+3)%65521,d-1); return (b*31+x+76)%65521; }
fn graph_fn2016(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} let a=graph_fn4064((x*x+77)%65521,d-1); let b=graph_fn3553((a+x+3)%65521,d-1); return (b*31+x+77)%65521; }
fn graph_fn2017(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} let a=graph_fn4065((x*x+78)%65521,d-1); let b=graph_fn3570((a+x+3)%65521,d-1); return (b*31+x+78)%65521; }
fn graph_fn2018(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} let a=graph_fn4066((x*x+79)%65521,d-1); let b=graph_fn3587((a+x+3)%65521,d-1); return (b*31+x+79)%65521; }
fn graph_fn2019(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} let a=graph_fn4067((x*x+80)%65521,d-1); let b=graph_fn3604((a+x+3)%65521,d-1); return (b*31+x+80)%65521; }
fn graph_fn2020(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} let a=graph_fn4068((x*x+81)%65521,d-1); let b=graph_fn3621((a+x+3)%65521,d-1); return (b*31+x+81)%65521; }
fn graph_fn2021(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} let a=graph_fn4069((x*x+82)%65521,d-1); let b=graph_fn3638((a+x+3)%65521,d-1); return (b*31+x+82)%65521; }
fn graph_fn2022(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} let a=graph_fn4070((x*x+83)%65521,d-1); let b=graph_fn3655((a+x+3)%65521,d-1); return (b*31+x+83)%65521; }
fn graph_fn2023(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} let a=graph_fn4071((x*x+84)%65521,d-1); let b=graph_fn3672((a+x+3)%65521,d-1); return (b*31+x+84)%65521; }
fn graph_fn2024(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} let a=graph_fn4072((x*x+85)%65521,d-1); let b=graph_fn3689((a+x+3)%65521,d-1); return (b*31+x+85)%65521; }
fn graph_fn2025(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} let a=graph_fn4073((x*x+86)%65521,d-1); let b=graph_fn3706((a+x+3)%65521,d-1); return (b*31+x+86)%65521; }
fn graph_fn2026(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} let a=graph_fn4074((x*x+87)%65521,d-1); let b=graph_fn3723((a+x+3)%65521,d-1); return (b*31+x+87)%65521; }
fn graph_fn2027(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} let a=graph_fn4075((x*x+88)%65521,d-1); let b=graph_fn3740((a+x+3)%65521,d-1); return (b*31+x+88)%65521; }
fn graph_fn2028(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} let a=graph_fn4076((x*x+89)%65521,d-1); let b=graph_fn3757((a+x+3)%65521,d-1); return (b*31+x+89)%65521; }
fn graph_fn2029(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} let a=graph_fn4077((x*x+90)%65521,d-1); let b=graph_fn3774((a+x+3)%65521,d-1); return (b*31+x+90)%65521; }
fn graph_fn2030(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} let a=graph_fn4078((x*x+91)%65521,d-1); let b=graph_fn3791((a+x+3)%65521,d-1); return (b*31+x+91)%65521; }
fn graph_fn2031(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} let a=graph_fn4079((x*x+92)%65521,d-1); let b=graph_fn3808((a+x+3)%65521,d-1); return (b*31+x+92)%65521; }
fn graph_fn2032(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} let a=graph_fn4080((x*x+93)%65521,d-1); let b=graph_fn3825((a+x+3)%65521,d-1); return (b*31+x+93)%65521; }
fn graph_fn2033(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} let a=graph_fn4081((x*x+94)%65521,d-1); let b=graph_fn3842((a+x+3)%65521,d-1); return (b*31+x+94)%65521; }
fn graph_fn2034(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} let a=graph_fn4082((x*x+95)%65521,d-1); let b=graph_fn3859((a+x+3)%65521,d-1); return (b*31+x+95)%65521; }
fn graph_fn2035(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} let a=graph_fn4083((x*x+96)%65521,d-1); let b=graph_fn3876((a+x+3)%65521,d-1); return (b*31+x+96)%65521; }
fn graph_fn2036(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} let a=graph_fn4084((x*x+97)%65521,d-1); let b=graph_fn3893((a+x+3)%65521,d-1); return (b*31+x+97)%65521; }
fn graph_fn2037(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} let a=graph_fn4085((x*x+1)%65521,d-1); let b=graph_fn3910((a+x+3)%65521,d-1); return (b*31+x+1)%65521; }
fn graph_fn2038(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} let a=graph_fn4086((x*x+2)%65521,d-1); let b=graph_fn3927((a+x+3)%65521,d-1); return (b*31+x+2)%65521; }
fn graph_fn2039(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} let a=graph_fn4087((x*x+3)%65521,d-1); let b=graph_fn3944((a+x+3)%65521,d-1); return (b*31+x+3)%65521; }
fn graph_fn2040(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} let a=graph_fn4088((x*x+4)%65521,d-1); let b=graph_fn3961((a+x+3)%65521,d-1); return (b*31+x+4)%65521; }
fn graph_fn2041(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} let a=graph_fn4089((x*x+5)%65521,d-1); let b=graph_fn3978((a+x+3)%65521,d-1); return (b*31+x+5)%65521; }
fn graph_fn2042(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} let a=graph_fn4090((x*x+6)%65521,d-1); let b=graph_fn3995((a+x+3)%65521,d-1); return (b*31+x+6)%65521; }
fn graph_fn2043(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} let a=graph_fn4091((x*x+7)%65521,d-1); let b=graph_fn4012((a+x+3)%65521,d-1); return (b*31+x+7)%65521; }
fn graph_fn2044(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} let a=graph_fn4092((x*x+8)%65521,d-1); let b=graph_fn4029((a+x+3)%65521,d-1); return (b*31+x+8)%65521; }
fn graph_fn2045(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} let a=graph_fn4093((x*x+9)%65521,d-1); let b=graph_fn4046((a+x+3)%65521,d-1); return (b*31+x+9)%65521; }
fn graph_fn2046(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} let a=graph_fn4094((x*x+10)%65521,d-1); let b=graph_fn4063((a+x+3)%65521,d-1); return (b*31+x+10)%65521; }
fn graph_fn2047(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} let a=graph_fn4095((x*x+11)%65521,d-1); let b=graph_fn4080((a+x+3)%65521,d-1); return (b*31+x+11)%65521; }
fn graph_fn2048(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2049(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2050(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2051(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2052(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2053(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2054(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2055(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2056(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2057(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2058(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2059(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2060(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2061(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2062(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2063(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2064(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2065(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2066(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2067(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2068(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2069(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2070(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2071(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2072(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2073(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2074(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2075(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2076(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2077(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2078(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2079(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2080(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2081(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2082(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2083(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2084(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2085(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2086(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2087(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2088(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2089(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2090(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2091(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2092(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2093(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2094(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2095(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2096(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2097(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2098(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2099(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2100(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2101(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2102(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2103(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2104(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2105(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2106(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2107(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2108(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2109(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2110(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2111(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2112(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2113(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2114(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2115(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2116(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2117(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2118(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2119(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2120(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2121(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2122(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2123(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2124(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2125(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2126(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2127(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2128(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2129(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2130(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2131(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2132(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2133(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2134(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2135(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2136(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2137(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2138(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2139(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2140(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2141(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2142(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2143(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2144(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2145(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2146(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2147(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2148(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2149(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2150(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2151(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2152(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2153(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2154(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2155(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2156(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2157(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2158(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2159(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2160(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2161(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2162(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2163(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2164(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2165(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2166(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2167(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2168(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2169(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2170(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2171(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2172(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2173(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2174(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2175(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2176(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2177(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2178(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2179(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2180(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2181(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2182(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2183(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2184(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2185(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2186(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2187(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2188(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2189(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2190(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2191(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2192(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2193(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2194(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2195(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2196(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2197(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2198(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2199(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2200(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2201(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2202(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2203(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2204(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2205(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2206(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2207(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2208(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2209(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2210(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2211(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2212(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2213(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2214(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2215(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2216(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2217(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2218(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2219(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2220(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2221(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2222(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2223(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2224(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2225(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2226(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2227(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2228(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2229(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2230(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2231(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2232(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2233(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2234(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2235(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2236(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2237(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2238(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2239(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2240(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2241(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2242(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2243(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2244(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2245(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2246(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2247(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2248(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2249(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2250(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2251(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2252(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2253(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2254(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2255(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2256(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2257(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2258(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2259(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2260(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2261(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2262(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2263(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2264(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2265(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2266(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2267(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2268(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2269(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2270(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2271(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2272(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2273(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2274(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2275(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2276(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2277(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2278(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2279(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2280(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2281(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2282(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2283(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2284(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2285(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2286(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2287(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2288(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2289(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2290(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2291(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2292(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2293(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2294(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2295(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2296(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2297(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2298(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2299(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2300(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2301(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2302(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2303(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2304(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2305(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2306(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2307(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2308(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2309(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2310(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2311(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2312(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2313(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2314(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2315(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2316(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2317(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2318(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2319(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2320(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2321(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2322(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2323(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2324(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2325(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2326(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2327(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2328(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2329(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2330(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2331(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2332(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2333(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2334(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2335(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2336(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2337(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2338(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2339(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2340(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2341(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2342(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2343(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2344(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2345(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2346(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2347(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2348(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2349(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2350(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2351(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2352(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2353(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2354(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2355(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2356(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2357(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2358(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2359(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2360(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2361(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2362(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2363(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2364(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2365(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2366(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2367(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2368(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2369(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2370(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2371(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2372(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2373(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2374(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2375(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2376(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2377(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2378(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2379(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2380(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2381(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2382(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2383(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2384(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2385(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2386(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2387(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2388(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2389(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2390(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2391(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2392(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2393(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2394(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2395(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2396(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2397(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2398(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2399(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2400(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2401(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2402(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2403(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2404(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2405(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2406(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2407(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2408(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2409(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2410(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2411(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2412(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2413(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2414(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2415(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2416(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2417(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2418(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2419(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2420(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2421(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2422(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2423(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2424(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2425(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2426(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2427(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2428(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2429(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2430(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2431(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2432(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2433(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2434(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2435(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2436(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2437(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2438(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2439(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2440(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2441(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2442(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2443(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2444(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2445(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2446(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2447(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2448(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2449(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2450(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2451(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2452(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2453(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2454(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2455(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2456(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2457(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2458(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2459(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2460(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2461(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2462(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2463(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2464(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2465(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2466(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2467(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2468(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2469(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2470(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2471(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2472(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2473(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2474(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2475(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2476(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2477(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2478(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2479(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2480(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2481(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2482(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2483(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2484(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2485(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2486(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2487(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2488(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2489(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2490(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2491(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2492(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2493(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2494(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2495(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2496(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2497(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2498(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2499(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2500(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2501(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2502(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2503(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2504(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2505(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2506(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2507(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2508(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2509(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2510(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2511(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2512(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2513(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2514(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2515(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2516(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2517(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2518(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2519(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2520(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2521(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2522(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2523(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2524(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2525(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2526(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2527(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2528(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2529(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2530(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2531(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2532(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2533(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2534(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2535(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2536(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2537(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2538(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2539(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2540(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2541(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2542(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2543(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2544(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2545(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2546(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2547(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2548(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2549(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2550(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2551(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2552(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2553(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2554(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2555(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2556(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2557(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2558(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2559(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2560(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2561(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2562(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2563(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2564(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2565(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2566(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2567(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2568(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2569(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2570(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2571(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2572(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2573(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2574(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2575(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2576(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2577(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2578(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2579(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2580(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2581(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2582(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2583(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2584(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2585(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2586(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2587(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2588(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2589(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2590(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2591(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2592(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2593(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2594(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2595(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2596(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2597(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2598(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2599(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2600(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2601(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2602(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2603(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2604(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2605(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2606(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2607(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2608(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2609(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2610(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2611(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2612(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2613(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2614(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2615(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2616(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2617(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2618(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2619(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2620(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2621(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2622(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2623(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2624(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2625(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2626(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2627(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2628(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2629(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2630(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2631(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2632(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2633(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2634(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2635(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2636(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2637(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2638(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2639(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2640(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2641(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2642(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2643(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2644(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2645(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2646(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2647(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2648(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2649(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2650(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2651(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2652(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2653(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2654(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2655(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2656(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2657(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2658(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2659(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2660(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2661(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2662(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2663(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2664(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2665(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2666(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2667(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2668(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2669(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2670(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2671(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2672(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2673(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2674(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2675(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2676(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2677(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2678(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2679(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2680(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2681(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2682(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2683(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2684(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2685(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2686(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2687(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2688(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2689(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2690(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2691(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2692(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2693(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2694(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2695(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2696(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2697(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2698(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2699(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2700(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2701(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2702(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2703(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2704(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2705(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2706(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2707(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2708(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2709(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2710(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2711(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2712(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2713(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2714(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2715(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2716(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2717(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2718(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2719(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2720(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2721(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2722(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2723(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2724(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2725(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2726(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2727(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2728(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2729(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2730(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2731(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2732(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2733(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2734(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2735(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2736(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2737(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2738(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2739(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2740(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2741(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2742(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2743(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2744(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2745(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2746(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2747(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2748(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2749(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2750(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2751(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2752(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2753(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2754(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2755(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2756(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2757(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2758(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2759(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2760(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2761(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2762(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2763(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2764(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2765(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2766(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2767(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2768(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2769(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2770(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2771(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2772(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2773(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2774(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2775(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2776(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2777(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2778(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2779(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2780(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2781(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2782(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2783(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2784(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2785(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2786(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2787(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2788(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2789(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2790(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2791(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2792(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2793(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2794(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2795(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2796(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2797(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2798(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2799(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2800(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2801(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2802(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2803(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2804(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2805(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2806(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2807(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2808(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2809(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2810(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2811(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2812(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2813(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2814(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2815(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2816(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2817(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2818(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2819(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2820(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2821(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2822(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2823(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2824(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2825(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2826(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2827(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2828(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2829(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2830(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2831(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2832(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2833(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2834(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2835(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2836(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2837(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2838(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2839(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2840(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2841(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2842(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2843(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2844(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2845(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2846(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2847(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2848(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2849(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2850(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2851(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2852(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2853(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2854(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2855(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2856(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2857(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2858(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2859(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2860(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2861(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2862(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2863(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2864(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2865(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2866(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2867(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2868(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2869(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2870(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2871(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2872(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2873(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2874(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2875(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2876(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2877(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2878(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2879(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2880(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2881(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2882(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2883(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2884(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2885(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2886(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2887(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2888(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2889(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2890(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2891(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2892(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2893(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2894(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2895(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2896(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2897(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2898(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2899(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2900(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2901(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2902(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn2903(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn2904(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn2905(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn2906(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn2907(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn2908(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn2909(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn2910(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn2911(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn2912(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn2913(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn2914(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn2915(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn2916(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn2917(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn2918(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn2919(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn2920(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn2921(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn2922(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn2923(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn2924(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn2925(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn2926(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn2927(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn2928(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn2929(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn2930(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn2931(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn2932(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn2933(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn2934(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn2935(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn2936(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn2937(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn2938(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn2939(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn2940(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn2941(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn2942(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn2943(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn2944(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn2945(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn2946(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn2947(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn2948(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn2949(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn2950(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn2951(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn2952(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn2953(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn2954(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn2955(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn2956(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn2957(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn2958(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn2959(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn2960(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn2961(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn2962(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn2963(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn2964(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn2965(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn2966(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn2967(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn2968(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn2969(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn2970(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn2971(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn2972(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn2973(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn2974(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn2975(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn2976(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn2977(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn2978(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn2979(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn2980(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn2981(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn2982(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn2983(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn2984(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn2985(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn2986(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn2987(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn2988(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn2989(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn2990(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn2991(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn2992(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn2993(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn2994(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn2995(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn2996(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn2997(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn2998(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn2999(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3000(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3001(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3002(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3003(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3004(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3005(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3006(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3007(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3008(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3009(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3010(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3011(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3012(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3013(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3014(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3015(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3016(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3017(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3018(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3019(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3020(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3021(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3022(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3023(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3024(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3025(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3026(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3027(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3028(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3029(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3030(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3031(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3032(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3033(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3034(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3035(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3036(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3037(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3038(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3039(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3040(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3041(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3042(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3043(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3044(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3045(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3046(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3047(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3048(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3049(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3050(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3051(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3052(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3053(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3054(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3055(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3056(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3057(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3058(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3059(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3060(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3061(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3062(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3063(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3064(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3065(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3066(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3067(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3068(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3069(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3070(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3071(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3072(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3073(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3074(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3075(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3076(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3077(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3078(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3079(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3080(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3081(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3082(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3083(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3084(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3085(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3086(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3087(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3088(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3089(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3090(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3091(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3092(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3093(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3094(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3095(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3096(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3097(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3098(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3099(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3100(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3101(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3102(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3103(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3104(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3105(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3106(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3107(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3108(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3109(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3110(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3111(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3112(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3113(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3114(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3115(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3116(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3117(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3118(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3119(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3120(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3121(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3122(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3123(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3124(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3125(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3126(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3127(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3128(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3129(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3130(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3131(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3132(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3133(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3134(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3135(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3136(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3137(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3138(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3139(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3140(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3141(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3142(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3143(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3144(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3145(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3146(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3147(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3148(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3149(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3150(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3151(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3152(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3153(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3154(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3155(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3156(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3157(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3158(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3159(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3160(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3161(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3162(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3163(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3164(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3165(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3166(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3167(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3168(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3169(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3170(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3171(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3172(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3173(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3174(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3175(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3176(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3177(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3178(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3179(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3180(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3181(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3182(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3183(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3184(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3185(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3186(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3187(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3188(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3189(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3190(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3191(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3192(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3193(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3194(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3195(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3196(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3197(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3198(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3199(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3200(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3201(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3202(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3203(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3204(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3205(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3206(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3207(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3208(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3209(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3210(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3211(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3212(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3213(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3214(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3215(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3216(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3217(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3218(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3219(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3220(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3221(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3222(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3223(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3224(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3225(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3226(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3227(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3228(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3229(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3230(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3231(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3232(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3233(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3234(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3235(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3236(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3237(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3238(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3239(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3240(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3241(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3242(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3243(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3244(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3245(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3246(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3247(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3248(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3249(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3250(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3251(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3252(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3253(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3254(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3255(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3256(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3257(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3258(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3259(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3260(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3261(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3262(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3263(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3264(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3265(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3266(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3267(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3268(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3269(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3270(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3271(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3272(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3273(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3274(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3275(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3276(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3277(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3278(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3279(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3280(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3281(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3282(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3283(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3284(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3285(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3286(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3287(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3288(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3289(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3290(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3291(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3292(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3293(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3294(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3295(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3296(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3297(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3298(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3299(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3300(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3301(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3302(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3303(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3304(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3305(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3306(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3307(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3308(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3309(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3310(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3311(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3312(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3313(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3314(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3315(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3316(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3317(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3318(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3319(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3320(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3321(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3322(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3323(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3324(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3325(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3326(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3327(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3328(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3329(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3330(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3331(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3332(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3333(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3334(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3335(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3336(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3337(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3338(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3339(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3340(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3341(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3342(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3343(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3344(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3345(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3346(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3347(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3348(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3349(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3350(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3351(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3352(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3353(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3354(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3355(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3356(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3357(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3358(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3359(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3360(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3361(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3362(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3363(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3364(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3365(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3366(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3367(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3368(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3369(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3370(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3371(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3372(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3373(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3374(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3375(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3376(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3377(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3378(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3379(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3380(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3381(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3382(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3383(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3384(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3385(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3386(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3387(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3388(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3389(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3390(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3391(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3392(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3393(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3394(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3395(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3396(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3397(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3398(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3399(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3400(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3401(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3402(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3403(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3404(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3405(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3406(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3407(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3408(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3409(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3410(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3411(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3412(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3413(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3414(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3415(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3416(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3417(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3418(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3419(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3420(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3421(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3422(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3423(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3424(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3425(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3426(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3427(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3428(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3429(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3430(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3431(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3432(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3433(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3434(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3435(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3436(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3437(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3438(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3439(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3440(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3441(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3442(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3443(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3444(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3445(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3446(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3447(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3448(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3449(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3450(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3451(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3452(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3453(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3454(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3455(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3456(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3457(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3458(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3459(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3460(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3461(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3462(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3463(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3464(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3465(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3466(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3467(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3468(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3469(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3470(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3471(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3472(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3473(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3474(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3475(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3476(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3477(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3478(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3479(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3480(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3481(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3482(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3483(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3484(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3485(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3486(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3487(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3488(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3489(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3490(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3491(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3492(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3493(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3494(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3495(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3496(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3497(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3498(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3499(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3500(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3501(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3502(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3503(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3504(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3505(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3506(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3507(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3508(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3509(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3510(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3511(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3512(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3513(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3514(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3515(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3516(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3517(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3518(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3519(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3520(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3521(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3522(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3523(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3524(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3525(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3526(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3527(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3528(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3529(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3530(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3531(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3532(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3533(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3534(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3535(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3536(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3537(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3538(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3539(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3540(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3541(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3542(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3543(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3544(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3545(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3546(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3547(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3548(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3549(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3550(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3551(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3552(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3553(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3554(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3555(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3556(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3557(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3558(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3559(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3560(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3561(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3562(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3563(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3564(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3565(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3566(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3567(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3568(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3569(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3570(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3571(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3572(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3573(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3574(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3575(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3576(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3577(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3578(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3579(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3580(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3581(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3582(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3583(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3584(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3585(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3586(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3587(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3588(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3589(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3590(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3591(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3592(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3593(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3594(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3595(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3596(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3597(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3598(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3599(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3600(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3601(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3602(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3603(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3604(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3605(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3606(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3607(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3608(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3609(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3610(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3611(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3612(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3613(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3614(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3615(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3616(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3617(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3618(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3619(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3620(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3621(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3622(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3623(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3624(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3625(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3626(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3627(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3628(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3629(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3630(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3631(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3632(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3633(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3634(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3635(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3636(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3637(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3638(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3639(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3640(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3641(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3642(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3643(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3644(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3645(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3646(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3647(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3648(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3649(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3650(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3651(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3652(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3653(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3654(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3655(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3656(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3657(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3658(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3659(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3660(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3661(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3662(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3663(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3664(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3665(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3666(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3667(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3668(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3669(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3670(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3671(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3672(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3673(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3674(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3675(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3676(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3677(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3678(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3679(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3680(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3681(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3682(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3683(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3684(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3685(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3686(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3687(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3688(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3689(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3690(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3691(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3692(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3693(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3694(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3695(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3696(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3697(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3698(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3699(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3700(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3701(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3702(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3703(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3704(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3705(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3706(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3707(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3708(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3709(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3710(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3711(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3712(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3713(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3714(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3715(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3716(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3717(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3718(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3719(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3720(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3721(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3722(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3723(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3724(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3725(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3726(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3727(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3728(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3729(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3730(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3731(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3732(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3733(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3734(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3735(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3736(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3737(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3738(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3739(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3740(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3741(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3742(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3743(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3744(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3745(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3746(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3747(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3748(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3749(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3750(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3751(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3752(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3753(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3754(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3755(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3756(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3757(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3758(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3759(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3760(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3761(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3762(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3763(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3764(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3765(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3766(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3767(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3768(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3769(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3770(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3771(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3772(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3773(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3774(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3775(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3776(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3777(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3778(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3779(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3780(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3781(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3782(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3783(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3784(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3785(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3786(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3787(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3788(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3789(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3790(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3791(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3792(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3793(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3794(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3795(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3796(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3797(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3798(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3799(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3800(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3801(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3802(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3803(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3804(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3805(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3806(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3807(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3808(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3809(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3810(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3811(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3812(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3813(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3814(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3815(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3816(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3817(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3818(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3819(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3820(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3821(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3822(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3823(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3824(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3825(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3826(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3827(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3828(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3829(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3830(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3831(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3832(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3833(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3834(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3835(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3836(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3837(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3838(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3839(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3840(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3841(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3842(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3843(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3844(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3845(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3846(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3847(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3848(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3849(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3850(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3851(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3852(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3853(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3854(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3855(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3856(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3857(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3858(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3859(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3860(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3861(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3862(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3863(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3864(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3865(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3866(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3867(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3868(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3869(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3870(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3871(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3872(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3873(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3874(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3875(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3876(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3877(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3878(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3879(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3880(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3881(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3882(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3883(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3884(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3885(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3886(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3887(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3888(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3889(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3890(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3891(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3892(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3893(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3894(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3895(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3896(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3897(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3898(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3899(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3900(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3901(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3902(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn3903(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn3904(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn3905(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn3906(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn3907(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn3908(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn3909(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn3910(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn3911(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn3912(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn3913(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn3914(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn3915(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn3916(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn3917(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn3918(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn3919(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn3920(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn3921(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn3922(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn3923(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn3924(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn3925(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn3926(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn3927(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn3928(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn3929(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn3930(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn3931(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn3932(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn3933(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn3934(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn3935(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn3936(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn3937(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn3938(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn3939(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn3940(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn3941(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn3942(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn3943(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn3944(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn3945(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn3946(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn3947(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn3948(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn3949(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn3950(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn3951(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn3952(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn3953(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn3954(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn3955(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn3956(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn3957(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn3958(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn3959(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn3960(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn3961(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn3962(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn3963(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn3964(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn3965(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn3966(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn3967(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn3968(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn3969(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn3970(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn3971(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn3972(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn3973(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn3974(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn3975(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn3976(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn3977(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn3978(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn3979(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn3980(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn3981(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn3982(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn3983(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn3984(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn3985(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn3986(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn3987(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn3988(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn3989(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn3990(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn3991(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn3992(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn3993(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn3994(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn3995(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn3996(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn3997(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn3998(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn graph_fn3999(x:i64,d:i32)->i64 { if d<=0 {return (x+23)%65521;} return (x*x+23)%65521; }
fn graph_fn4000(x:i64,d:i32)->i64 { if d<=0 {return (x+24)%65521;} return (x*x+24)%65521; }
fn graph_fn4001(x:i64,d:i32)->i64 { if d<=0 {return (x+25)%65521;} return (x*x+25)%65521; }
fn graph_fn4002(x:i64,d:i32)->i64 { if d<=0 {return (x+26)%65521;} return (x*x+26)%65521; }
fn graph_fn4003(x:i64,d:i32)->i64 { if d<=0 {return (x+27)%65521;} return (x*x+27)%65521; }
fn graph_fn4004(x:i64,d:i32)->i64 { if d<=0 {return (x+28)%65521;} return (x*x+28)%65521; }
fn graph_fn4005(x:i64,d:i32)->i64 { if d<=0 {return (x+29)%65521;} return (x*x+29)%65521; }
fn graph_fn4006(x:i64,d:i32)->i64 { if d<=0 {return (x+30)%65521;} return (x*x+30)%65521; }
fn graph_fn4007(x:i64,d:i32)->i64 { if d<=0 {return (x+31)%65521;} return (x*x+31)%65521; }
fn graph_fn4008(x:i64,d:i32)->i64 { if d<=0 {return (x+32)%65521;} return (x*x+32)%65521; }
fn graph_fn4009(x:i64,d:i32)->i64 { if d<=0 {return (x+33)%65521;} return (x*x+33)%65521; }
fn graph_fn4010(x:i64,d:i32)->i64 { if d<=0 {return (x+34)%65521;} return (x*x+34)%65521; }
fn graph_fn4011(x:i64,d:i32)->i64 { if d<=0 {return (x+35)%65521;} return (x*x+35)%65521; }
fn graph_fn4012(x:i64,d:i32)->i64 { if d<=0 {return (x+36)%65521;} return (x*x+36)%65521; }
fn graph_fn4013(x:i64,d:i32)->i64 { if d<=0 {return (x+37)%65521;} return (x*x+37)%65521; }
fn graph_fn4014(x:i64,d:i32)->i64 { if d<=0 {return (x+38)%65521;} return (x*x+38)%65521; }
fn graph_fn4015(x:i64,d:i32)->i64 { if d<=0 {return (x+39)%65521;} return (x*x+39)%65521; }
fn graph_fn4016(x:i64,d:i32)->i64 { if d<=0 {return (x+40)%65521;} return (x*x+40)%65521; }
fn graph_fn4017(x:i64,d:i32)->i64 { if d<=0 {return (x+41)%65521;} return (x*x+41)%65521; }
fn graph_fn4018(x:i64,d:i32)->i64 { if d<=0 {return (x+42)%65521;} return (x*x+42)%65521; }
fn graph_fn4019(x:i64,d:i32)->i64 { if d<=0 {return (x+43)%65521;} return (x*x+43)%65521; }
fn graph_fn4020(x:i64,d:i32)->i64 { if d<=0 {return (x+44)%65521;} return (x*x+44)%65521; }
fn graph_fn4021(x:i64,d:i32)->i64 { if d<=0 {return (x+45)%65521;} return (x*x+45)%65521; }
fn graph_fn4022(x:i64,d:i32)->i64 { if d<=0 {return (x+46)%65521;} return (x*x+46)%65521; }
fn graph_fn4023(x:i64,d:i32)->i64 { if d<=0 {return (x+47)%65521;} return (x*x+47)%65521; }
fn graph_fn4024(x:i64,d:i32)->i64 { if d<=0 {return (x+48)%65521;} return (x*x+48)%65521; }
fn graph_fn4025(x:i64,d:i32)->i64 { if d<=0 {return (x+49)%65521;} return (x*x+49)%65521; }
fn graph_fn4026(x:i64,d:i32)->i64 { if d<=0 {return (x+50)%65521;} return (x*x+50)%65521; }
fn graph_fn4027(x:i64,d:i32)->i64 { if d<=0 {return (x+51)%65521;} return (x*x+51)%65521; }
fn graph_fn4028(x:i64,d:i32)->i64 { if d<=0 {return (x+52)%65521;} return (x*x+52)%65521; }
fn graph_fn4029(x:i64,d:i32)->i64 { if d<=0 {return (x+53)%65521;} return (x*x+53)%65521; }
fn graph_fn4030(x:i64,d:i32)->i64 { if d<=0 {return (x+54)%65521;} return (x*x+54)%65521; }
fn graph_fn4031(x:i64,d:i32)->i64 { if d<=0 {return (x+55)%65521;} return (x*x+55)%65521; }
fn graph_fn4032(x:i64,d:i32)->i64 { if d<=0 {return (x+56)%65521;} return (x*x+56)%65521; }
fn graph_fn4033(x:i64,d:i32)->i64 { if d<=0 {return (x+57)%65521;} return (x*x+57)%65521; }
fn graph_fn4034(x:i64,d:i32)->i64 { if d<=0 {return (x+58)%65521;} return (x*x+58)%65521; }
fn graph_fn4035(x:i64,d:i32)->i64 { if d<=0 {return (x+59)%65521;} return (x*x+59)%65521; }
fn graph_fn4036(x:i64,d:i32)->i64 { if d<=0 {return (x+60)%65521;} return (x*x+60)%65521; }
fn graph_fn4037(x:i64,d:i32)->i64 { if d<=0 {return (x+61)%65521;} return (x*x+61)%65521; }
fn graph_fn4038(x:i64,d:i32)->i64 { if d<=0 {return (x+62)%65521;} return (x*x+62)%65521; }
fn graph_fn4039(x:i64,d:i32)->i64 { if d<=0 {return (x+63)%65521;} return (x*x+63)%65521; }
fn graph_fn4040(x:i64,d:i32)->i64 { if d<=0 {return (x+64)%65521;} return (x*x+64)%65521; }
fn graph_fn4041(x:i64,d:i32)->i64 { if d<=0 {return (x+65)%65521;} return (x*x+65)%65521; }
fn graph_fn4042(x:i64,d:i32)->i64 { if d<=0 {return (x+66)%65521;} return (x*x+66)%65521; }
fn graph_fn4043(x:i64,d:i32)->i64 { if d<=0 {return (x+67)%65521;} return (x*x+67)%65521; }
fn graph_fn4044(x:i64,d:i32)->i64 { if d<=0 {return (x+68)%65521;} return (x*x+68)%65521; }
fn graph_fn4045(x:i64,d:i32)->i64 { if d<=0 {return (x+69)%65521;} return (x*x+69)%65521; }
fn graph_fn4046(x:i64,d:i32)->i64 { if d<=0 {return (x+70)%65521;} return (x*x+70)%65521; }
fn graph_fn4047(x:i64,d:i32)->i64 { if d<=0 {return (x+71)%65521;} return (x*x+71)%65521; }
fn graph_fn4048(x:i64,d:i32)->i64 { if d<=0 {return (x+72)%65521;} return (x*x+72)%65521; }
fn graph_fn4049(x:i64,d:i32)->i64 { if d<=0 {return (x+73)%65521;} return (x*x+73)%65521; }
fn graph_fn4050(x:i64,d:i32)->i64 { if d<=0 {return (x+74)%65521;} return (x*x+74)%65521; }
fn graph_fn4051(x:i64,d:i32)->i64 { if d<=0 {return (x+75)%65521;} return (x*x+75)%65521; }
fn graph_fn4052(x:i64,d:i32)->i64 { if d<=0 {return (x+76)%65521;} return (x*x+76)%65521; }
fn graph_fn4053(x:i64,d:i32)->i64 { if d<=0 {return (x+77)%65521;} return (x*x+77)%65521; }
fn graph_fn4054(x:i64,d:i32)->i64 { if d<=0 {return (x+78)%65521;} return (x*x+78)%65521; }
fn graph_fn4055(x:i64,d:i32)->i64 { if d<=0 {return (x+79)%65521;} return (x*x+79)%65521; }
fn graph_fn4056(x:i64,d:i32)->i64 { if d<=0 {return (x+80)%65521;} return (x*x+80)%65521; }
fn graph_fn4057(x:i64,d:i32)->i64 { if d<=0 {return (x+81)%65521;} return (x*x+81)%65521; }
fn graph_fn4058(x:i64,d:i32)->i64 { if d<=0 {return (x+82)%65521;} return (x*x+82)%65521; }
fn graph_fn4059(x:i64,d:i32)->i64 { if d<=0 {return (x+83)%65521;} return (x*x+83)%65521; }
fn graph_fn4060(x:i64,d:i32)->i64 { if d<=0 {return (x+84)%65521;} return (x*x+84)%65521; }
fn graph_fn4061(x:i64,d:i32)->i64 { if d<=0 {return (x+85)%65521;} return (x*x+85)%65521; }
fn graph_fn4062(x:i64,d:i32)->i64 { if d<=0 {return (x+86)%65521;} return (x*x+86)%65521; }
fn graph_fn4063(x:i64,d:i32)->i64 { if d<=0 {return (x+87)%65521;} return (x*x+87)%65521; }
fn graph_fn4064(x:i64,d:i32)->i64 { if d<=0 {return (x+88)%65521;} return (x*x+88)%65521; }
fn graph_fn4065(x:i64,d:i32)->i64 { if d<=0 {return (x+89)%65521;} return (x*x+89)%65521; }
fn graph_fn4066(x:i64,d:i32)->i64 { if d<=0 {return (x+90)%65521;} return (x*x+90)%65521; }
fn graph_fn4067(x:i64,d:i32)->i64 { if d<=0 {return (x+91)%65521;} return (x*x+91)%65521; }
fn graph_fn4068(x:i64,d:i32)->i64 { if d<=0 {return (x+92)%65521;} return (x*x+92)%65521; }
fn graph_fn4069(x:i64,d:i32)->i64 { if d<=0 {return (x+93)%65521;} return (x*x+93)%65521; }
fn graph_fn4070(x:i64,d:i32)->i64 { if d<=0 {return (x+94)%65521;} return (x*x+94)%65521; }
fn graph_fn4071(x:i64,d:i32)->i64 { if d<=0 {return (x+95)%65521;} return (x*x+95)%65521; }
fn graph_fn4072(x:i64,d:i32)->i64 { if d<=0 {return (x+96)%65521;} return (x*x+96)%65521; }
fn graph_fn4073(x:i64,d:i32)->i64 { if d<=0 {return (x+97)%65521;} return (x*x+97)%65521; }
fn graph_fn4074(x:i64,d:i32)->i64 { if d<=0 {return (x+1)%65521;} return (x*x+1)%65521; }
fn graph_fn4075(x:i64,d:i32)->i64 { if d<=0 {return (x+2)%65521;} return (x*x+2)%65521; }
fn graph_fn4076(x:i64,d:i32)->i64 { if d<=0 {return (x+3)%65521;} return (x*x+3)%65521; }
fn graph_fn4077(x:i64,d:i32)->i64 { if d<=0 {return (x+4)%65521;} return (x*x+4)%65521; }
fn graph_fn4078(x:i64,d:i32)->i64 { if d<=0 {return (x+5)%65521;} return (x*x+5)%65521; }
fn graph_fn4079(x:i64,d:i32)->i64 { if d<=0 {return (x+6)%65521;} return (x*x+6)%65521; }
fn graph_fn4080(x:i64,d:i32)->i64 { if d<=0 {return (x+7)%65521;} return (x*x+7)%65521; }
fn graph_fn4081(x:i64,d:i32)->i64 { if d<=0 {return (x+8)%65521;} return (x*x+8)%65521; }
fn graph_fn4082(x:i64,d:i32)->i64 { if d<=0 {return (x+9)%65521;} return (x*x+9)%65521; }
fn graph_fn4083(x:i64,d:i32)->i64 { if d<=0 {return (x+10)%65521;} return (x*x+10)%65521; }
fn graph_fn4084(x:i64,d:i32)->i64 { if d<=0 {return (x+11)%65521;} return (x*x+11)%65521; }
fn graph_fn4085(x:i64,d:i32)->i64 { if d<=0 {return (x+12)%65521;} return (x*x+12)%65521; }
fn graph_fn4086(x:i64,d:i32)->i64 { if d<=0 {return (x+13)%65521;} return (x*x+13)%65521; }
fn graph_fn4087(x:i64,d:i32)->i64 { if d<=0 {return (x+14)%65521;} return (x*x+14)%65521; }
fn graph_fn4088(x:i64,d:i32)->i64 { if d<=0 {return (x+15)%65521;} return (x*x+15)%65521; }
fn graph_fn4089(x:i64,d:i32)->i64 { if d<=0 {return (x+16)%65521;} return (x*x+16)%65521; }
fn graph_fn4090(x:i64,d:i32)->i64 { if d<=0 {return (x+17)%65521;} return (x*x+17)%65521; }
fn graph_fn4091(x:i64,d:i32)->i64 { if d<=0 {return (x+18)%65521;} return (x*x+18)%65521; }
fn graph_fn4092(x:i64,d:i32)->i64 { if d<=0 {return (x+19)%65521;} return (x*x+19)%65521; }
fn graph_fn4093(x:i64,d:i32)->i64 { if d<=0 {return (x+20)%65521;} return (x*x+20)%65521; }
fn graph_fn4094(x:i64,d:i32)->i64 { if d<=0 {return (x+21)%65521;} return (x*x+21)%65521; }
fn graph_fn4095(x:i64,d:i32)->i64 { if d<=0 {return (x+22)%65521;} return (x*x+22)%65521; }
fn run(x:i64,d:i32)->i64 { let mut y=x; y=graph_fn0(y,d); y=graph_fn1(y,d); y=graph_fn2(y,d); y=graph_fn3(y,d); y=graph_fn4(y,d); y=graph_fn5(y,d); y=graph_fn6(y,d); y=graph_fn7(y,d); y=graph_fn8(y,d); y=graph_fn9(y,d); y=graph_fn10(y,d); y=graph_fn11(y,d); y=graph_fn12(y,d); y=graph_fn13(y,d); y=graph_fn14(y,d); y=graph_fn15(y,d); y=graph_fn16(y,d); y=graph_fn17(y,d); y=graph_fn18(y,d); y=graph_fn19(y,d); y=graph_fn20(y,d); y=graph_fn21(y,d); y=graph_fn22(y,d); y=graph_fn23(y,d); y=graph_fn24(y,d); y=graph_fn25(y,d); y=graph_fn26(y,d); y=graph_fn27(y,d); y=graph_fn28(y,d); y=graph_fn29(y,d); y=graph_fn30(y,d); y=graph_fn31(y,d); y=graph_fn32(y,d); y=graph_fn33(y,d); y=graph_fn34(y,d); y=graph_fn35(y,d); y=graph_fn36(y,d); y=graph_fn37(y,d); y=graph_fn38(y,d); y=graph_fn39(y,d); y=graph_fn40(y,d); y=graph_fn41(y,d); y=graph_fn42(y,d); y=graph_fn43(y,d); y=graph_fn44(y,d); y=graph_fn45(y,d); y=graph_fn46(y,d); y=graph_fn47(y,d); y=graph_fn48(y,d); y=graph_fn49(y,d); y=graph_fn50(y,d); y=graph_fn51(y,d); y=graph_fn52(y,d); y=graph_fn53(y,d); y=graph_fn54(y,d); y=graph_fn55(y,d); y=graph_fn56(y,d); y=graph_fn57(y,d); y=graph_fn58(y,d); y=graph_fn59(y,d); y=graph_fn60(y,d); y=graph_fn61(y,d); y=graph_fn62(y,d); y=graph_fn63(y,d); y=graph_fn64(y,d); y=graph_fn65(y,d); y=graph_fn66(y,d); y=graph_fn67(y,d); y=graph_fn68(y,d); y=graph_fn69(y,d); y=graph_fn70(y,d); y=graph_fn71(y,d); y=graph_fn72(y,d); y=graph_fn73(y,d); y=graph_fn74(y,d); y=graph_fn75(y,d); y=graph_fn76(y,d); y=graph_fn77(y,d); y=graph_fn78(y,d); y=graph_fn79(y,d); y=graph_fn80(y,d); y=graph_fn81(y,d); y=graph_fn82(y,d); y=graph_fn83(y,d); y=graph_fn84(y,d); y=graph_fn85(y,d); y=graph_fn86(y,d); y=graph_fn87(y,d); y=graph_fn88(y,d); y=graph_fn89(y,d); y=graph_fn90(y,d); y=graph_fn91(y,d); y=graph_fn92(y,d); y=graph_fn93(y,d); y=graph_fn94(y,d); y=graph_fn95(y,d); y=graph_fn96(y,d); y=graph_fn97(y,d); y=graph_fn98(y,d); y=graph_fn99(y,d); y=graph_fn100(y,d); y=graph_fn101(y,d); y=graph_fn102(y,d); y=graph_fn103(y,d); y=graph_fn104(y,d); y=graph_fn105(y,d); y=graph_fn106(y,d); y=graph_fn107(y,d); y=graph_fn108(y,d); y=graph_fn109(y,d); y=graph_fn110(y,d); y=graph_fn111(y,d); y=graph_fn112(y,d); y=graph_fn113(y,d); y=graph_fn114(y,d); y=graph_fn115(y,d); y=graph_fn116(y,d); y=graph_fn117(y,d); y=graph_fn118(y,d); y=graph_fn119(y,d); y=graph_fn120(y,d); y=graph_fn121(y,d); y=graph_fn122(y,d); y=graph_fn123(y,d); y=graph_fn124(y,d); y=graph_fn125(y,d); y=graph_fn126(y,d); y=graph_fn127(y,d); y=graph_fn128(y,d); y=graph_fn129(y,d); y=graph_fn130(y,d); y=graph_fn131(y,d); y=graph_fn132(y,d); y=graph_fn133(y,d); y=graph_fn134(y,d); y=graph_fn135(y,d); y=graph_fn136(y,d); y=graph_fn137(y,d); y=graph_fn138(y,d); y=graph_fn139(y,d); y=graph_fn140(y,d); y=graph_fn141(y,d); y=graph_fn142(y,d); y=graph_fn143(y,d); y=graph_fn144(y,d); y=graph_fn145(y,d); y=graph_fn146(y,d); y=graph_fn147(y,d); y=graph_fn148(y,d); y=graph_fn149(y,d); y=graph_fn150(y,d); y=graph_fn151(y,d); y=graph_fn152(y,d); y=graph_fn153(y,d); y=graph_fn154(y,d); y=graph_fn155(y,d); y=graph_fn156(y,d); y=graph_fn157(y,d); y=graph_fn158(y,d); y=graph_fn159(y,d); y=graph_fn160(y,d); y=graph_fn161(y,d); y=graph_fn162(y,d); y=graph_fn163(y,d); y=graph_fn164(y,d); y=graph_fn165(y,d); y=graph_fn166(y,d); y=graph_fn167(y,d); y=graph_fn168(y,d); y=graph_fn169(y,d); y=graph_fn170(y,d); y=graph_fn171(y,d); y=graph_fn172(y,d); y=graph_fn173(y,d); y=graph_fn174(y,d); y=graph_fn175(y,d); y=graph_fn176(y,d); y=graph_fn177(y,d); y=graph_fn178(y,d); y=graph_fn179(y,d); y=graph_fn180(y,d); y=graph_fn181(y,d); y=graph_fn182(y,d); y=graph_fn183(y,d); y=graph_fn184(y,d); y=graph_fn185(y,d); y=graph_fn186(y,d); y=graph_fn187(y,d); y=graph_fn188(y,d); y=graph_fn189(y,d); y=graph_fn190(y,d); y=graph_fn191(y,d); y=graph_fn192(y,d); y=graph_fn193(y,d); y=graph_fn194(y,d); y=graph_fn195(y,d); y=graph_fn196(y,d); y=graph_fn197(y,d); y=graph_fn198(y,d); y=graph_fn199(y,d); y=graph_fn200(y,d); y=graph_fn201(y,d); y=graph_fn202(y,d); y=graph_fn203(y,d); y=graph_fn204(y,d); y=graph_fn205(y,d); y=graph_fn206(y,d); y=graph_fn207(y,d); y=graph_fn208(y,d); y=graph_fn209(y,d); y=graph_fn210(y,d); y=graph_fn211(y,d); y=graph_fn212(y,d); y=graph_fn213(y,d); y=graph_fn214(y,d); y=graph_fn215(y,d); y=graph_fn216(y,d); y=graph_fn217(y,d); y=graph_fn218(y,d); y=graph_fn219(y,d); y=graph_fn220(y,d); y=graph_fn221(y,d); y=graph_fn222(y,d); y=graph_fn223(y,d); y=graph_fn224(y,d); y=graph_fn225(y,d); y=graph_fn226(y,d); y=graph_fn227(y,d); y=graph_fn228(y,d); y=graph_fn229(y,d); y=graph_fn230(y,d); y=graph_fn231(y,d); y=graph_fn232(y,d); y=graph_fn233(y,d); y=graph_fn234(y,d); y=graph_fn235(y,d); y=graph_fn236(y,d); y=graph_fn237(y,d); y=graph_fn238(y,d); y=graph_fn239(y,d); y=graph_fn240(y,d); y=graph_fn241(y,d); y=graph_fn242(y,d); y=graph_fn243(y,d); y=graph_fn244(y,d); y=graph_fn245(y,d); y=graph_fn246(y,d); y=graph_fn247(y,d); y=graph_fn248(y,d); y=graph_fn249(y,d); y=graph_fn250(y,d); y=graph_fn251(y,d); y=graph_fn252(y,d); y=graph_fn253(y,d); y=graph_fn254(y,d); y=graph_fn255(y,d); y=graph_fn256(y,d); y=graph_fn257(y,d); y=graph_fn258(y,d); y=graph_fn259(y,d); y=graph_fn260(y,d); y=graph_fn261(y,d); y=graph_fn262(y,d); y=graph_fn263(y,d); y=graph_fn264(y,d); y=graph_fn265(y,d); y=graph_fn266(y,d); y=graph_fn267(y,d); y=graph_fn268(y,d); y=graph_fn269(y,d); y=graph_fn270(y,d); y=graph_fn271(y,d); y=graph_fn272(y,d); y=graph_fn273(y,d); y=graph_fn274(y,d); y=graph_fn275(y,d); y=graph_fn276(y,d); y=graph_fn277(y,d); y=graph_fn278(y,d); y=graph_fn279(y,d); y=graph_fn280(y,d); y=graph_fn281(y,d); y=graph_fn282(y,d); y=graph_fn283(y,d); y=graph_fn284(y,d); y=graph_fn285(y,d); y=graph_fn286(y,d); y=graph_fn287(y,d); y=graph_fn288(y,d); y=graph_fn289(y,d); y=graph_fn290(y,d); y=graph_fn291(y,d); y=graph_fn292(y,d); y=graph_fn293(y,d); y=graph_fn294(y,d); y=graph_fn295(y,d); y=graph_fn296(y,d); y=graph_fn297(y,d); y=graph_fn298(y,d); y=graph_fn299(y,d); y=graph_fn300(y,d); y=graph_fn301(y,d); y=graph_fn302(y,d); y=graph_fn303(y,d); y=graph_fn304(y,d); y=graph_fn305(y,d); y=graph_fn306(y,d); y=graph_fn307(y,d); y=graph_fn308(y,d); y=graph_fn309(y,d); y=graph_fn310(y,d); y=graph_fn311(y,d); y=graph_fn312(y,d); y=graph_fn313(y,d); y=graph_fn314(y,d); y=graph_fn315(y,d); y=graph_fn316(y,d); y=graph_fn317(y,d); y=graph_fn318(y,d); y=graph_fn319(y,d); y=graph_fn320(y,d); y=graph_fn321(y,d); y=graph_fn322(y,d); y=graph_fn323(y,d); y=graph_fn324(y,d); y=graph_fn325(y,d); y=graph_fn326(y,d); y=graph_fn327(y,d); y=graph_fn328(y,d); y=graph_fn329(y,d); y=graph_fn330(y,d); y=graph_fn331(y,d); y=graph_fn332(y,d); y=graph_fn333(y,d); y=graph_fn334(y,d); y=graph_fn335(y,d); y=graph_fn336(y,d); y=graph_fn337(y,d); y=graph_fn338(y,d); y=graph_fn339(y,d); y=graph_fn340(y,d); y=graph_fn341(y,d); y=graph_fn342(y,d); y=graph_fn343(y,d); y=graph_fn344(y,d); y=graph_fn345(y,d); y=graph_fn346(y,d); y=graph_fn347(y,d); y=graph_fn348(y,d); y=graph_fn349(y,d); y=graph_fn350(y,d); y=graph_fn351(y,d); y=graph_fn352(y,d); y=graph_fn353(y,d); y=graph_fn354(y,d); y=graph_fn355(y,d); y=graph_fn356(y,d); y=graph_fn357(y,d); y=graph_fn358(y,d); y=graph_fn359(y,d); y=graph_fn360(y,d); y=graph_fn361(y,d); y=graph_fn362(y,d); y=graph_fn363(y,d); y=graph_fn364(y,d); y=graph_fn365(y,d); y=graph_fn366(y,d); y=graph_fn367(y,d); y=graph_fn368(y,d); y=graph_fn369(y,d); y=graph_fn370(y,d); y=graph_fn371(y,d); y=graph_fn372(y,d); y=graph_fn373(y,d); y=graph_fn374(y,d); y=graph_fn375(y,d); y=graph_fn376(y,d); y=graph_fn377(y,d); y=graph_fn378(y,d); y=graph_fn379(y,d); y=graph_fn380(y,d); y=graph_fn381(y,d); y=graph_fn382(y,d); y=graph_fn383(y,d); y=graph_fn384(y,d); y=graph_fn385(y,d); y=graph_fn386(y,d); y=graph_fn387(y,d); y=graph_fn388(y,d); y=graph_fn389(y,d); y=graph_fn390(y,d); y=graph_fn391(y,d); y=graph_fn392(y,d); y=graph_fn393(y,d); y=graph_fn394(y,d); y=graph_fn395(y,d); y=graph_fn396(y,d); y=graph_fn397(y,d); y=graph_fn398(y,d); y=graph_fn399(y,d); y=graph_fn400(y,d); y=graph_fn401(y,d); y=graph_fn402(y,d); y=graph_fn403(y,d); y=graph_fn404(y,d); y=graph_fn405(y,d); y=graph_fn406(y,d); y=graph_fn407(y,d); y=graph_fn408(y,d); y=graph_fn409(y,d); y=graph_fn410(y,d); y=graph_fn411(y,d); y=graph_fn412(y,d); y=graph_fn413(y,d); y=graph_fn414(y,d); y=graph_fn415(y,d); y=graph_fn416(y,d); y=graph_fn417(y,d); y=graph_fn418(y,d); y=graph_fn419(y,d); y=graph_fn420(y,d); y=graph_fn421(y,d); y=graph_fn422(y,d); y=graph_fn423(y,d); y=graph_fn424(y,d); y=graph_fn425(y,d); y=graph_fn426(y,d); y=graph_fn427(y,d); y=graph_fn428(y,d); y=graph_fn429(y,d); y=graph_fn430(y,d); y=graph_fn431(y,d); y=graph_fn432(y,d); y=graph_fn433(y,d); y=graph_fn434(y,d); y=graph_fn435(y,d); y=graph_fn436(y,d); y=graph_fn437(y,d); y=graph_fn438(y,d); y=graph_fn439(y,d); y=graph_fn440(y,d); y=graph_fn441(y,d); y=graph_fn442(y,d); y=graph_fn443(y,d); y=graph_fn444(y,d); y=graph_fn445(y,d); y=graph_fn446(y,d); y=graph_fn447(y,d); y=graph_fn448(y,d); y=graph_fn449(y,d); y=graph_fn450(y,d); y=graph_fn451(y,d); y=graph_fn452(y,d); y=graph_fn453(y,d); y=graph_fn454(y,d); y=graph_fn455(y,d); y=graph_fn456(y,d); y=graph_fn457(y,d); y=graph_fn458(y,d); y=graph_fn459(y,d); y=graph_fn460(y,d); y=graph_fn461(y,d); y=graph_fn462(y,d); y=graph_fn463(y,d); y=graph_fn464(y,d); y=graph_fn465(y,d); y=graph_fn466(y,d); y=graph_fn467(y,d); y=graph_fn468(y,d); y=graph_fn469(y,d); y=graph_fn470(y,d); y=graph_fn471(y,d); y=graph_fn472(y,d); y=graph_fn473(y,d); y=graph_fn474(y,d); y=graph_fn475(y,d); y=graph_fn476(y,d); y=graph_fn477(y,d); y=graph_fn478(y,d); y=graph_fn479(y,d); y=graph_fn480(y,d); y=graph_fn481(y,d); y=graph_fn482(y,d); y=graph_fn483(y,d); y=graph_fn484(y,d); y=graph_fn485(y,d); y=graph_fn486(y,d); y=graph_fn487(y,d); y=graph_fn488(y,d); y=graph_fn489(y,d); y=graph_fn490(y,d); y=graph_fn491(y,d); y=graph_fn492(y,d); y=graph_fn493(y,d); y=graph_fn494(y,d); y=graph_fn495(y,d); y=graph_fn496(y,d); y=graph_fn497(y,d); y=graph_fn498(y,d); y=graph_fn499(y,d); y=graph_fn500(y,d); y=graph_fn501(y,d); y=graph_fn502(y,d); y=graph_fn503(y,d); y=graph_fn504(y,d); y=graph_fn505(y,d); y=graph_fn506(y,d); y=graph_fn507(y,d); y=graph_fn508(y,d); y=graph_fn509(y,d); y=graph_fn510(y,d); y=graph_fn511(y,d); y=graph_fn512(y,d); y=graph_fn513(y,d); y=graph_fn514(y,d); y=graph_fn515(y,d); y=graph_fn516(y,d); y=graph_fn517(y,d); y=graph_fn518(y,d); y=graph_fn519(y,d); y=graph_fn520(y,d); y=graph_fn521(y,d); y=graph_fn522(y,d); y=graph_fn523(y,d); y=graph_fn524(y,d); y=graph_fn525(y,d); y=graph_fn526(y,d); y=graph_fn527(y,d); y=graph_fn528(y,d); y=graph_fn529(y,d); y=graph_fn530(y,d); y=graph_fn531(y,d); y=graph_fn532(y,d); y=graph_fn533(y,d); y=graph_fn534(y,d); y=graph_fn535(y,d); y=graph_fn536(y,d); y=graph_fn537(y,d); y=graph_fn538(y,d); y=graph_fn539(y,d); y=graph_fn540(y,d); y=graph_fn541(y,d); y=graph_fn542(y,d); y=graph_fn543(y,d); y=graph_fn544(y,d); y=graph_fn545(y,d); y=graph_fn546(y,d); y=graph_fn547(y,d); y=graph_fn548(y,d); y=graph_fn549(y,d); y=graph_fn550(y,d); y=graph_fn551(y,d); y=graph_fn552(y,d); y=graph_fn553(y,d); y=graph_fn554(y,d); y=graph_fn555(y,d); y=graph_fn556(y,d); y=graph_fn557(y,d); y=graph_fn558(y,d); y=graph_fn559(y,d); y=graph_fn560(y,d); y=graph_fn561(y,d); y=graph_fn562(y,d); y=graph_fn563(y,d); y=graph_fn564(y,d); y=graph_fn565(y,d); y=graph_fn566(y,d); y=graph_fn567(y,d); y=graph_fn568(y,d); y=graph_fn569(y,d); y=graph_fn570(y,d); y=graph_fn571(y,d); y=graph_fn572(y,d); y=graph_fn573(y,d); y=graph_fn574(y,d); y=graph_fn575(y,d); y=graph_fn576(y,d); y=graph_fn577(y,d); y=graph_fn578(y,d); y=graph_fn579(y,d); y=graph_fn580(y,d); y=graph_fn581(y,d); y=graph_fn582(y,d); y=graph_fn583(y,d); y=graph_fn584(y,d); y=graph_fn585(y,d); y=graph_fn586(y,d); y=graph_fn587(y,d); y=graph_fn588(y,d); y=graph_fn589(y,d); y=graph_fn590(y,d); y=graph_fn591(y,d); y=graph_fn592(y,d); y=graph_fn593(y,d); y=graph_fn594(y,d); y=graph_fn595(y,d); y=graph_fn596(y,d); y=graph_fn597(y,d); y=graph_fn598(y,d); y=graph_fn599(y,d); y=graph_fn600(y,d); y=graph_fn601(y,d); y=graph_fn602(y,d); y=graph_fn603(y,d); y=graph_fn604(y,d); y=graph_fn605(y,d); y=graph_fn606(y,d); y=graph_fn607(y,d); y=graph_fn608(y,d); y=graph_fn609(y,d); y=graph_fn610(y,d); y=graph_fn611(y,d); y=graph_fn612(y,d); y=graph_fn613(y,d); y=graph_fn614(y,d); y=graph_fn615(y,d); y=graph_fn616(y,d); y=graph_fn617(y,d); y=graph_fn618(y,d); y=graph_fn619(y,d); y=graph_fn620(y,d); y=graph_fn621(y,d); y=graph_fn622(y,d); y=graph_fn623(y,d); y=graph_fn624(y,d); y=graph_fn625(y,d); y=graph_fn626(y,d); y=graph_fn627(y,d); y=graph_fn628(y,d); y=graph_fn629(y,d); y=graph_fn630(y,d); y=graph_fn631(y,d); y=graph_fn632(y,d); y=graph_fn633(y,d); y=graph_fn634(y,d); y=graph_fn635(y,d); y=graph_fn636(y,d); y=graph_fn637(y,d); y=graph_fn638(y,d); y=graph_fn639(y,d); y=graph_fn640(y,d); y=graph_fn641(y,d); y=graph_fn642(y,d); y=graph_fn643(y,d); y=graph_fn644(y,d); y=graph_fn645(y,d); y=graph_fn646(y,d); y=graph_fn647(y,d); y=graph_fn648(y,d); y=graph_fn649(y,d); y=graph_fn650(y,d); y=graph_fn651(y,d); y=graph_fn652(y,d); y=graph_fn653(y,d); y=graph_fn654(y,d); y=graph_fn655(y,d); y=graph_fn656(y,d); y=graph_fn657(y,d); y=graph_fn658(y,d); y=graph_fn659(y,d); y=graph_fn660(y,d); y=graph_fn661(y,d); y=graph_fn662(y,d); y=graph_fn663(y,d); y=graph_fn664(y,d); y=graph_fn665(y,d); y=graph_fn666(y,d); y=graph_fn667(y,d); y=graph_fn668(y,d); y=graph_fn669(y,d); y=graph_fn670(y,d); y=graph_fn671(y,d); y=graph_fn672(y,d); y=graph_fn673(y,d); y=graph_fn674(y,d); y=graph_fn675(y,d); y=graph_fn676(y,d); y=graph_fn677(y,d); y=graph_fn678(y,d); y=graph_fn679(y,d); y=graph_fn680(y,d); y=graph_fn681(y,d); y=graph_fn682(y,d); y=graph_fn683(y,d); y=graph_fn684(y,d); y=graph_fn685(y,d); y=graph_fn686(y,d); y=graph_fn687(y,d); y=graph_fn688(y,d); y=graph_fn689(y,d); y=graph_fn690(y,d); y=graph_fn691(y,d); y=graph_fn692(y,d); y=graph_fn693(y,d); y=graph_fn694(y,d); y=graph_fn695(y,d); y=graph_fn696(y,d); y=graph_fn697(y,d); y=graph_fn698(y,d); y=graph_fn699(y,d); y=graph_fn700(y,d); y=graph_fn701(y,d); y=graph_fn702(y,d); y=graph_fn703(y,d); y=graph_fn704(y,d); y=graph_fn705(y,d); y=graph_fn706(y,d); y=graph_fn707(y,d); y=graph_fn708(y,d); y=graph_fn709(y,d); y=graph_fn710(y,d); y=graph_fn711(y,d); y=graph_fn712(y,d); y=graph_fn713(y,d); y=graph_fn714(y,d); y=graph_fn715(y,d); y=graph_fn716(y,d); y=graph_fn717(y,d); y=graph_fn718(y,d); y=graph_fn719(y,d); y=graph_fn720(y,d); y=graph_fn721(y,d); y=graph_fn722(y,d); y=graph_fn723(y,d); y=graph_fn724(y,d); y=graph_fn725(y,d); y=graph_fn726(y,d); y=graph_fn727(y,d); y=graph_fn728(y,d); y=graph_fn729(y,d); y=graph_fn730(y,d); y=graph_fn731(y,d); y=graph_fn732(y,d); y=graph_fn733(y,d); y=graph_fn734(y,d); y=graph_fn735(y,d); y=graph_fn736(y,d); y=graph_fn737(y,d); y=graph_fn738(y,d); y=graph_fn739(y,d); y=graph_fn740(y,d); y=graph_fn741(y,d); y=graph_fn742(y,d); y=graph_fn743(y,d); y=graph_fn744(y,d); y=graph_fn745(y,d); y=graph_fn746(y,d); y=graph_fn747(y,d); y=graph_fn748(y,d); y=graph_fn749(y,d); y=graph_fn750(y,d); y=graph_fn751(y,d); y=graph_fn752(y,d); y=graph_fn753(y,d); y=graph_fn754(y,d); y=graph_fn755(y,d); y=graph_fn756(y,d); y=graph_fn757(y,d); y=graph_fn758(y,d); y=graph_fn759(y,d); y=graph_fn760(y,d); y=graph_fn761(y,d); y=graph_fn762(y,d); y=graph_fn763(y,d); y=graph_fn764(y,d); y=graph_fn765(y,d); y=graph_fn766(y,d); y=graph_fn767(y,d); y=graph_fn768(y,d); y=graph_fn769(y,d); y=graph_fn770(y,d); y=graph_fn771(y,d); y=graph_fn772(y,d); y=graph_fn773(y,d); y=graph_fn774(y,d); y=graph_fn775(y,d); y=graph_fn776(y,d); y=graph_fn777(y,d); y=graph_fn778(y,d); y=graph_fn779(y,d); y=graph_fn780(y,d); y=graph_fn781(y,d); y=graph_fn782(y,d); y=graph_fn783(y,d); y=graph_fn784(y,d); y=graph_fn785(y,d); y=graph_fn786(y,d); y=graph_fn787(y,d); y=graph_fn788(y,d); y=graph_fn789(y,d); y=graph_fn790(y,d); y=graph_fn791(y,d); y=graph_fn792(y,d); y=graph_fn793(y,d); y=graph_fn794(y,d); y=graph_fn795(y,d); y=graph_fn796(y,d); y=graph_fn797(y,d); y=graph_fn798(y,d); y=graph_fn799(y,d); y=graph_fn800(y,d); y=graph_fn801(y,d); y=graph_fn802(y,d); y=graph_fn803(y,d); y=graph_fn804(y,d); y=graph_fn805(y,d); y=graph_fn806(y,d); y=graph_fn807(y,d); y=graph_fn808(y,d); y=graph_fn809(y,d); y=graph_fn810(y,d); y=graph_fn811(y,d); y=graph_fn812(y,d); y=graph_fn813(y,d); y=graph_fn814(y,d); y=graph_fn815(y,d); y=graph_fn816(y,d); y=graph_fn817(y,d); y=graph_fn818(y,d); y=graph_fn819(y,d); y=graph_fn820(y,d); y=graph_fn821(y,d); y=graph_fn822(y,d); y=graph_fn823(y,d); y=graph_fn824(y,d); y=graph_fn825(y,d); y=graph_fn826(y,d); y=graph_fn827(y,d); y=graph_fn828(y,d); y=graph_fn829(y,d); y=graph_fn830(y,d); y=graph_fn831(y,d); y=graph_fn832(y,d); y=graph_fn833(y,d); y=graph_fn834(y,d); y=graph_fn835(y,d); y=graph_fn836(y,d); y=graph_fn837(y,d); y=graph_fn838(y,d); y=graph_fn839(y,d); y=graph_fn840(y,d); y=graph_fn841(y,d); y=graph_fn842(y,d); y=graph_fn843(y,d); y=graph_fn844(y,d); y=graph_fn845(y,d); y=graph_fn846(y,d); y=graph_fn847(y,d); y=graph_fn848(y,d); y=graph_fn849(y,d); y=graph_fn850(y,d); y=graph_fn851(y,d); y=graph_fn852(y,d); y=graph_fn853(y,d); y=graph_fn854(y,d); y=graph_fn855(y,d); y=graph_fn856(y,d); y=graph_fn857(y,d); y=graph_fn858(y,d); y=graph_fn859(y,d); y=graph_fn860(y,d); y=graph_fn861(y,d); y=graph_fn862(y,d); y=graph_fn863(y,d); y=graph_fn864(y,d); y=graph_fn865(y,d); y=graph_fn866(y,d); y=graph_fn867(y,d); y=graph_fn868(y,d); y=graph_fn869(y,d); y=graph_fn870(y,d); y=graph_fn871(y,d); y=graph_fn872(y,d); y=graph_fn873(y,d); y=graph_fn874(y,d); y=graph_fn875(y,d); y=graph_fn876(y,d); y=graph_fn877(y,d); y=graph_fn878(y,d); y=graph_fn879(y,d); y=graph_fn880(y,d); y=graph_fn881(y,d); y=graph_fn882(y,d); y=graph_fn883(y,d); y=graph_fn884(y,d); y=graph_fn885(y,d); y=graph_fn886(y,d); y=graph_fn887(y,d); y=graph_fn888(y,d); y=graph_fn889(y,d); y=graph_fn890(y,d); y=graph_fn891(y,d); y=graph_fn892(y,d); y=graph_fn893(y,d); y=graph_fn894(y,d); y=graph_fn895(y,d); y=graph_fn896(y,d); y=graph_fn897(y,d); y=graph_fn898(y,d); y=graph_fn899(y,d); y=graph_fn900(y,d); y=graph_fn901(y,d); y=graph_fn902(y,d); y=graph_fn903(y,d); y=graph_fn904(y,d); y=graph_fn905(y,d); y=graph_fn906(y,d); y=graph_fn907(y,d); y=graph_fn908(y,d); y=graph_fn909(y,d); y=graph_fn910(y,d); y=graph_fn911(y,d); y=graph_fn912(y,d); y=graph_fn913(y,d); y=graph_fn914(y,d); y=graph_fn915(y,d); y=graph_fn916(y,d); y=graph_fn917(y,d); y=graph_fn918(y,d); y=graph_fn919(y,d); y=graph_fn920(y,d); y=graph_fn921(y,d); y=graph_fn922(y,d); y=graph_fn923(y,d); y=graph_fn924(y,d); y=graph_fn925(y,d); y=graph_fn926(y,d); y=graph_fn927(y,d); y=graph_fn928(y,d); y=graph_fn929(y,d); y=graph_fn930(y,d); y=graph_fn931(y,d); y=graph_fn932(y,d); y=graph_fn933(y,d); y=graph_fn934(y,d); y=graph_fn935(y,d); y=graph_fn936(y,d); y=graph_fn937(y,d); y=graph_fn938(y,d); y=graph_fn939(y,d); y=graph_fn940(y,d); y=graph_fn941(y,d); y=graph_fn942(y,d); y=graph_fn943(y,d); y=graph_fn944(y,d); y=graph_fn945(y,d); y=graph_fn946(y,d); y=graph_fn947(y,d); y=graph_fn948(y,d); y=graph_fn949(y,d); y=graph_fn950(y,d); y=graph_fn951(y,d); y=graph_fn952(y,d); y=graph_fn953(y,d); y=graph_fn954(y,d); y=graph_fn955(y,d); y=graph_fn956(y,d); y=graph_fn957(y,d); y=graph_fn958(y,d); y=graph_fn959(y,d); y=graph_fn960(y,d); y=graph_fn961(y,d); y=graph_fn962(y,d); y=graph_fn963(y,d); y=graph_fn964(y,d); y=graph_fn965(y,d); y=graph_fn966(y,d); y=graph_fn967(y,d); y=graph_fn968(y,d); y=graph_fn969(y,d); y=graph_fn970(y,d); y=graph_fn971(y,d); y=graph_fn972(y,d); y=graph_fn973(y,d); y=graph_fn974(y,d); y=graph_fn975(y,d); y=graph_fn976(y,d); y=graph_fn977(y,d); y=graph_fn978(y,d); y=graph_fn979(y,d); y=graph_fn980(y,d); y=graph_fn981(y,d); y=graph_fn982(y,d); y=graph_fn983(y,d); y=graph_fn984(y,d); y=graph_fn985(y,d); y=graph_fn986(y,d); y=graph_fn987(y,d); y=graph_fn988(y,d); y=graph_fn989(y,d); y=graph_fn990(y,d); y=graph_fn991(y,d); y=graph_fn992(y,d); y=graph_fn993(y,d); y=graph_fn994(y,d); y=graph_fn995(y,d); y=graph_fn996(y,d); y=graph_fn997(y,d); y=graph_fn998(y,d); y=graph_fn999(y,d); y=graph_fn1000(y,d); y=graph_fn1001(y,d); y=graph_fn1002(y,d); y=graph_fn1003(y,d); y=graph_fn1004(y,d); y=graph_fn1005(y,d); y=graph_fn1006(y,d); y=graph_fn1007(y,d); y=graph_fn1008(y,d); y=graph_fn1009(y,d); y=graph_fn1010(y,d); y=graph_fn1011(y,d); y=graph_fn1012(y,d); y=graph_fn1013(y,d); y=graph_fn1014(y,d); y=graph_fn1015(y,d); y=graph_fn1016(y,d); y=graph_fn1017(y,d); y=graph_fn1018(y,d); y=graph_fn1019(y,d); y=graph_fn1020(y,d); y=graph_fn1021(y,d); y=graph_fn1022(y,d); y=graph_fn1023(y,d); y=graph_fn1024(y,d); y=graph_fn1025(y,d); y=graph_fn1026(y,d); y=graph_fn1027(y,d); y=graph_fn1028(y,d); y=graph_fn1029(y,d); y=graph_fn1030(y,d); y=graph_fn1031(y,d); y=graph_fn1032(y,d); y=graph_fn1033(y,d); y=graph_fn1034(y,d); y=graph_fn1035(y,d); y=graph_fn1036(y,d); y=graph_fn1037(y,d); y=graph_fn1038(y,d); y=graph_fn1039(y,d); y=graph_fn1040(y,d); y=graph_fn1041(y,d); y=graph_fn1042(y,d); y=graph_fn1043(y,d); y=graph_fn1044(y,d); y=graph_fn1045(y,d); y=graph_fn1046(y,d); y=graph_fn1047(y,d); y=graph_fn1048(y,d); y=graph_fn1049(y,d); y=graph_fn1050(y,d); y=graph_fn1051(y,d); y=graph_fn1052(y,d); y=graph_fn1053(y,d); y=graph_fn1054(y,d); y=graph_fn1055(y,d); y=graph_fn1056(y,d); y=graph_fn1057(y,d); y=graph_fn1058(y,d); y=graph_fn1059(y,d); y=graph_fn1060(y,d); y=graph_fn1061(y,d); y=graph_fn1062(y,d); y=graph_fn1063(y,d); y=graph_fn1064(y,d); y=graph_fn1065(y,d); y=graph_fn1066(y,d); y=graph_fn1067(y,d); y=graph_fn1068(y,d); y=graph_fn1069(y,d); y=graph_fn1070(y,d); y=graph_fn1071(y,d); y=graph_fn1072(y,d); y=graph_fn1073(y,d); y=graph_fn1074(y,d); y=graph_fn1075(y,d); y=graph_fn1076(y,d); y=graph_fn1077(y,d); y=graph_fn1078(y,d); y=graph_fn1079(y,d); y=graph_fn1080(y,d); y=graph_fn1081(y,d); y=graph_fn1082(y,d); y=graph_fn1083(y,d); y=graph_fn1084(y,d); y=graph_fn1085(y,d); y=graph_fn1086(y,d); y=graph_fn1087(y,d); y=graph_fn1088(y,d); y=graph_fn1089(y,d); y=graph_fn1090(y,d); y=graph_fn1091(y,d); y=graph_fn1092(y,d); y=graph_fn1093(y,d); y=graph_fn1094(y,d); y=graph_fn1095(y,d); y=graph_fn1096(y,d); y=graph_fn1097(y,d); y=graph_fn1098(y,d); y=graph_fn1099(y,d); y=graph_fn1100(y,d); y=graph_fn1101(y,d); y=graph_fn1102(y,d); y=graph_fn1103(y,d); y=graph_fn1104(y,d); y=graph_fn1105(y,d); y=graph_fn1106(y,d); y=graph_fn1107(y,d); y=graph_fn1108(y,d); y=graph_fn1109(y,d); y=graph_fn1110(y,d); y=graph_fn1111(y,d); y=graph_fn1112(y,d); y=graph_fn1113(y,d); y=graph_fn1114(y,d); y=graph_fn1115(y,d); y=graph_fn1116(y,d); y=graph_fn1117(y,d); y=graph_fn1118(y,d); y=graph_fn1119(y,d); y=graph_fn1120(y,d); y=graph_fn1121(y,d); y=graph_fn1122(y,d); y=graph_fn1123(y,d); y=graph_fn1124(y,d); y=graph_fn1125(y,d); y=graph_fn1126(y,d); y=graph_fn1127(y,d); y=graph_fn1128(y,d); y=graph_fn1129(y,d); y=graph_fn1130(y,d); y=graph_fn1131(y,d); y=graph_fn1132(y,d); y=graph_fn1133(y,d); y=graph_fn1134(y,d); y=graph_fn1135(y,d); y=graph_fn1136(y,d); y=graph_fn1137(y,d); y=graph_fn1138(y,d); y=graph_fn1139(y,d); y=graph_fn1140(y,d); y=graph_fn1141(y,d); y=graph_fn1142(y,d); y=graph_fn1143(y,d); y=graph_fn1144(y,d); y=graph_fn1145(y,d); y=graph_fn1146(y,d); y=graph_fn1147(y,d); y=graph_fn1148(y,d); y=graph_fn1149(y,d); y=graph_fn1150(y,d); y=graph_fn1151(y,d); y=graph_fn1152(y,d); y=graph_fn1153(y,d); y=graph_fn1154(y,d); y=graph_fn1155(y,d); y=graph_fn1156(y,d); y=graph_fn1157(y,d); y=graph_fn1158(y,d); y=graph_fn1159(y,d); y=graph_fn1160(y,d); y=graph_fn1161(y,d); y=graph_fn1162(y,d); y=graph_fn1163(y,d); y=graph_fn1164(y,d); y=graph_fn1165(y,d); y=graph_fn1166(y,d); y=graph_fn1167(y,d); y=graph_fn1168(y,d); y=graph_fn1169(y,d); y=graph_fn1170(y,d); y=graph_fn1171(y,d); y=graph_fn1172(y,d); y=graph_fn1173(y,d); y=graph_fn1174(y,d); y=graph_fn1175(y,d); y=graph_fn1176(y,d); y=graph_fn1177(y,d); y=graph_fn1178(y,d); y=graph_fn1179(y,d); y=graph_fn1180(y,d); y=graph_fn1181(y,d); y=graph_fn1182(y,d); y=graph_fn1183(y,d); y=graph_fn1184(y,d); y=graph_fn1185(y,d); y=graph_fn1186(y,d); y=graph_fn1187(y,d); y=graph_fn1188(y,d); y=graph_fn1189(y,d); y=graph_fn1190(y,d); y=graph_fn1191(y,d); y=graph_fn1192(y,d); y=graph_fn1193(y,d); y=graph_fn1194(y,d); y=graph_fn1195(y,d); y=graph_fn1196(y,d); y=graph_fn1197(y,d); y=graph_fn1198(y,d); y=graph_fn1199(y,d); y=graph_fn1200(y,d); y=graph_fn1201(y,d); y=graph_fn1202(y,d); y=graph_fn1203(y,d); y=graph_fn1204(y,d); y=graph_fn1205(y,d); y=graph_fn1206(y,d); y=graph_fn1207(y,d); y=graph_fn1208(y,d); y=graph_fn1209(y,d); y=graph_fn1210(y,d); y=graph_fn1211(y,d); y=graph_fn1212(y,d); y=graph_fn1213(y,d); y=graph_fn1214(y,d); y=graph_fn1215(y,d); y=graph_fn1216(y,d); y=graph_fn1217(y,d); y=graph_fn1218(y,d); y=graph_fn1219(y,d); y=graph_fn1220(y,d); y=graph_fn1221(y,d); y=graph_fn1222(y,d); y=graph_fn1223(y,d); y=graph_fn1224(y,d); y=graph_fn1225(y,d); y=graph_fn1226(y,d); y=graph_fn1227(y,d); y=graph_fn1228(y,d); y=graph_fn1229(y,d); y=graph_fn1230(y,d); y=graph_fn1231(y,d); y=graph_fn1232(y,d); y=graph_fn1233(y,d); y=graph_fn1234(y,d); y=graph_fn1235(y,d); y=graph_fn1236(y,d); y=graph_fn1237(y,d); y=graph_fn1238(y,d); y=graph_fn1239(y,d); y=graph_fn1240(y,d); y=graph_fn1241(y,d); y=graph_fn1242(y,d); y=graph_fn1243(y,d); y=graph_fn1244(y,d); y=graph_fn1245(y,d); y=graph_fn1246(y,d); y=graph_fn1247(y,d); y=graph_fn1248(y,d); y=graph_fn1249(y,d); y=graph_fn1250(y,d); y=graph_fn1251(y,d); y=graph_fn1252(y,d); y=graph_fn1253(y,d); y=graph_fn1254(y,d); y=graph_fn1255(y,d); y=graph_fn1256(y,d); y=graph_fn1257(y,d); y=graph_fn1258(y,d); y=graph_fn1259(y,d); y=graph_fn1260(y,d); y=graph_fn1261(y,d); y=graph_fn1262(y,d); y=graph_fn1263(y,d); y=graph_fn1264(y,d); y=graph_fn1265(y,d); y=graph_fn1266(y,d); y=graph_fn1267(y,d); y=graph_fn1268(y,d); y=graph_fn1269(y,d); y=graph_fn1270(y,d); y=graph_fn1271(y,d); y=graph_fn1272(y,d); y=graph_fn1273(y,d); y=graph_fn1274(y,d); y=graph_fn1275(y,d); y=graph_fn1276(y,d); y=graph_fn1277(y,d); y=graph_fn1278(y,d); y=graph_fn1279(y,d); y=graph_fn1280(y,d); y=graph_fn1281(y,d); y=graph_fn1282(y,d); y=graph_fn1283(y,d); y=graph_fn1284(y,d); y=graph_fn1285(y,d); y=graph_fn1286(y,d); y=graph_fn1287(y,d); y=graph_fn1288(y,d); y=graph_fn1289(y,d); y=graph_fn1290(y,d); y=graph_fn1291(y,d); y=graph_fn1292(y,d); y=graph_fn1293(y,d); y=graph_fn1294(y,d); y=graph_fn1295(y,d); y=graph_fn1296(y,d); y=graph_fn1297(y,d); y=graph_fn1298(y,d); y=graph_fn1299(y,d); y=graph_fn1300(y,d); y=graph_fn1301(y,d); y=graph_fn1302(y,d); y=graph_fn1303(y,d); y=graph_fn1304(y,d); y=graph_fn1305(y,d); y=graph_fn1306(y,d); y=graph_fn1307(y,d); y=graph_fn1308(y,d); y=graph_fn1309(y,d); y=graph_fn1310(y,d); y=graph_fn1311(y,d); y=graph_fn1312(y,d); y=graph_fn1313(y,d); y=graph_fn1314(y,d); y=graph_fn1315(y,d); y=graph_fn1316(y,d); y=graph_fn1317(y,d); y=graph_fn1318(y,d); y=graph_fn1319(y,d); y=graph_fn1320(y,d); y=graph_fn1321(y,d); y=graph_fn1322(y,d); y=graph_fn1323(y,d); y=graph_fn1324(y,d); y=graph_fn1325(y,d); y=graph_fn1326(y,d); y=graph_fn1327(y,d); y=graph_fn1328(y,d); y=graph_fn1329(y,d); y=graph_fn1330(y,d); y=graph_fn1331(y,d); y=graph_fn1332(y,d); y=graph_fn1333(y,d); y=graph_fn1334(y,d); y=graph_fn1335(y,d); y=graph_fn1336(y,d); y=graph_fn1337(y,d); y=graph_fn1338(y,d); y=graph_fn1339(y,d); y=graph_fn1340(y,d); y=graph_fn1341(y,d); y=graph_fn1342(y,d); y=graph_fn1343(y,d); y=graph_fn1344(y,d); y=graph_fn1345(y,d); y=graph_fn1346(y,d); y=graph_fn1347(y,d); y=graph_fn1348(y,d); y=graph_fn1349(y,d); y=graph_fn1350(y,d); y=graph_fn1351(y,d); y=graph_fn1352(y,d); y=graph_fn1353(y,d); y=graph_fn1354(y,d); y=graph_fn1355(y,d); y=graph_fn1356(y,d); y=graph_fn1357(y,d); y=graph_fn1358(y,d); y=graph_fn1359(y,d); y=graph_fn1360(y,d); y=graph_fn1361(y,d); y=graph_fn1362(y,d); y=graph_fn1363(y,d); y=graph_fn1364(y,d); y=graph_fn1365(y,d); y=graph_fn1366(y,d); y=graph_fn1367(y,d); y=graph_fn1368(y,d); y=graph_fn1369(y,d); y=graph_fn1370(y,d); y=graph_fn1371(y,d); y=graph_fn1372(y,d); y=graph_fn1373(y,d); y=graph_fn1374(y,d); y=graph_fn1375(y,d); y=graph_fn1376(y,d); y=graph_fn1377(y,d); y=graph_fn1378(y,d); y=graph_fn1379(y,d); y=graph_fn1380(y,d); y=graph_fn1381(y,d); y=graph_fn1382(y,d); y=graph_fn1383(y,d); y=graph_fn1384(y,d); y=graph_fn1385(y,d); y=graph_fn1386(y,d); y=graph_fn1387(y,d); y=graph_fn1388(y,d); y=graph_fn1389(y,d); y=graph_fn1390(y,d); y=graph_fn1391(y,d); y=graph_fn1392(y,d); y=graph_fn1393(y,d); y=graph_fn1394(y,d); y=graph_fn1395(y,d); y=graph_fn1396(y,d); y=graph_fn1397(y,d); y=graph_fn1398(y,d); y=graph_fn1399(y,d); y=graph_fn1400(y,d); y=graph_fn1401(y,d); y=graph_fn1402(y,d); y=graph_fn1403(y,d); y=graph_fn1404(y,d); y=graph_fn1405(y,d); y=graph_fn1406(y,d); y=graph_fn1407(y,d); y=graph_fn1408(y,d); y=graph_fn1409(y,d); y=graph_fn1410(y,d); y=graph_fn1411(y,d); y=graph_fn1412(y,d); y=graph_fn1413(y,d); y=graph_fn1414(y,d); y=graph_fn1415(y,d); y=graph_fn1416(y,d); y=graph_fn1417(y,d); y=graph_fn1418(y,d); y=graph_fn1419(y,d); y=graph_fn1420(y,d); y=graph_fn1421(y,d); y=graph_fn1422(y,d); y=graph_fn1423(y,d); y=graph_fn1424(y,d); y=graph_fn1425(y,d); y=graph_fn1426(y,d); y=graph_fn1427(y,d); y=graph_fn1428(y,d); y=graph_fn1429(y,d); y=graph_fn1430(y,d); y=graph_fn1431(y,d); y=graph_fn1432(y,d); y=graph_fn1433(y,d); y=graph_fn1434(y,d); y=graph_fn1435(y,d); y=graph_fn1436(y,d); y=graph_fn1437(y,d); y=graph_fn1438(y,d); y=graph_fn1439(y,d); y=graph_fn1440(y,d); y=graph_fn1441(y,d); y=graph_fn1442(y,d); y=graph_fn1443(y,d); y=graph_fn1444(y,d); y=graph_fn1445(y,d); y=graph_fn1446(y,d); y=graph_fn1447(y,d); y=graph_fn1448(y,d); y=graph_fn1449(y,d); y=graph_fn1450(y,d); y=graph_fn1451(y,d); y=graph_fn1452(y,d); y=graph_fn1453(y,d); y=graph_fn1454(y,d); y=graph_fn1455(y,d); y=graph_fn1456(y,d); y=graph_fn1457(y,d); y=graph_fn1458(y,d); y=graph_fn1459(y,d); y=graph_fn1460(y,d); y=graph_fn1461(y,d); y=graph_fn1462(y,d); y=graph_fn1463(y,d); y=graph_fn1464(y,d); y=graph_fn1465(y,d); y=graph_fn1466(y,d); y=graph_fn1467(y,d); y=graph_fn1468(y,d); y=graph_fn1469(y,d); y=graph_fn1470(y,d); y=graph_fn1471(y,d); y=graph_fn1472(y,d); y=graph_fn1473(y,d); y=graph_fn1474(y,d); y=graph_fn1475(y,d); y=graph_fn1476(y,d); y=graph_fn1477(y,d); y=graph_fn1478(y,d); y=graph_fn1479(y,d); y=graph_fn1480(y,d); y=graph_fn1481(y,d); y=graph_fn1482(y,d); y=graph_fn1483(y,d); y=graph_fn1484(y,d); y=graph_fn1485(y,d); y=graph_fn1486(y,d); y=graph_fn1487(y,d); y=graph_fn1488(y,d); y=graph_fn1489(y,d); y=graph_fn1490(y,d); y=graph_fn1491(y,d); y=graph_fn1492(y,d); y=graph_fn1493(y,d); y=graph_fn1494(y,d); y=graph_fn1495(y,d); y=graph_fn1496(y,d); y=graph_fn1497(y,d); y=graph_fn1498(y,d); y=graph_fn1499(y,d); y=graph_fn1500(y,d); y=graph_fn1501(y,d); y=graph_fn1502(y,d); y=graph_fn1503(y,d); y=graph_fn1504(y,d); y=graph_fn1505(y,d); y=graph_fn1506(y,d); y=graph_fn1507(y,d); y=graph_fn1508(y,d); y=graph_fn1509(y,d); y=graph_fn1510(y,d); y=graph_fn1511(y,d); y=graph_fn1512(y,d); y=graph_fn1513(y,d); y=graph_fn1514(y,d); y=graph_fn1515(y,d); y=graph_fn1516(y,d); y=graph_fn1517(y,d); y=graph_fn1518(y,d); y=graph_fn1519(y,d); y=graph_fn1520(y,d); y=graph_fn1521(y,d); y=graph_fn1522(y,d); y=graph_fn1523(y,d); y=graph_fn1524(y,d); y=graph_fn1525(y,d); y=graph_fn1526(y,d); y=graph_fn1527(y,d); y=graph_fn1528(y,d); y=graph_fn1529(y,d); y=graph_fn1530(y,d); y=graph_fn1531(y,d); y=graph_fn1532(y,d); y=graph_fn1533(y,d); y=graph_fn1534(y,d); y=graph_fn1535(y,d); y=graph_fn1536(y,d); y=graph_fn1537(y,d); y=graph_fn1538(y,d); y=graph_fn1539(y,d); y=graph_fn1540(y,d); y=graph_fn1541(y,d); y=graph_fn1542(y,d); y=graph_fn1543(y,d); y=graph_fn1544(y,d); y=graph_fn1545(y,d); y=graph_fn1546(y,d); y=graph_fn1547(y,d); y=graph_fn1548(y,d); y=graph_fn1549(y,d); y=graph_fn1550(y,d); y=graph_fn1551(y,d); y=graph_fn1552(y,d); y=graph_fn1553(y,d); y=graph_fn1554(y,d); y=graph_fn1555(y,d); y=graph_fn1556(y,d); y=graph_fn1557(y,d); y=graph_fn1558(y,d); y=graph_fn1559(y,d); y=graph_fn1560(y,d); y=graph_fn1561(y,d); y=graph_fn1562(y,d); y=graph_fn1563(y,d); y=graph_fn1564(y,d); y=graph_fn1565(y,d); y=graph_fn1566(y,d); y=graph_fn1567(y,d); y=graph_fn1568(y,d); y=graph_fn1569(y,d); y=graph_fn1570(y,d); y=graph_fn1571(y,d); y=graph_fn1572(y,d); y=graph_fn1573(y,d); y=graph_fn1574(y,d); y=graph_fn1575(y,d); y=graph_fn1576(y,d); y=graph_fn1577(y,d); y=graph_fn1578(y,d); y=graph_fn1579(y,d); y=graph_fn1580(y,d); y=graph_fn1581(y,d); y=graph_fn1582(y,d); y=graph_fn1583(y,d); y=graph_fn1584(y,d); y=graph_fn1585(y,d); y=graph_fn1586(y,d); y=graph_fn1587(y,d); y=graph_fn1588(y,d); y=graph_fn1589(y,d); y=graph_fn1590(y,d); y=graph_fn1591(y,d); y=graph_fn1592(y,d); y=graph_fn1593(y,d); y=graph_fn1594(y,d); y=graph_fn1595(y,d); y=graph_fn1596(y,d); y=graph_fn1597(y,d); y=graph_fn1598(y,d); y=graph_fn1599(y,d); y=graph_fn1600(y,d); y=graph_fn1601(y,d); y=graph_fn1602(y,d); y=graph_fn1603(y,d); y=graph_fn1604(y,d); y=graph_fn1605(y,d); y=graph_fn1606(y,d); y=graph_fn1607(y,d); y=graph_fn1608(y,d); y=graph_fn1609(y,d); y=graph_fn1610(y,d); y=graph_fn1611(y,d); y=graph_fn1612(y,d); y=graph_fn1613(y,d); y=graph_fn1614(y,d); y=graph_fn1615(y,d); y=graph_fn1616(y,d); y=graph_fn1617(y,d); y=graph_fn1618(y,d); y=graph_fn1619(y,d); y=graph_fn1620(y,d); y=graph_fn1621(y,d); y=graph_fn1622(y,d); y=graph_fn1623(y,d); y=graph_fn1624(y,d); y=graph_fn1625(y,d); y=graph_fn1626(y,d); y=graph_fn1627(y,d); y=graph_fn1628(y,d); y=graph_fn1629(y,d); y=graph_fn1630(y,d); y=graph_fn1631(y,d); y=graph_fn1632(y,d); y=graph_fn1633(y,d); y=graph_fn1634(y,d); y=graph_fn1635(y,d); y=graph_fn1636(y,d); y=graph_fn1637(y,d); y=graph_fn1638(y,d); y=graph_fn1639(y,d); y=graph_fn1640(y,d); y=graph_fn1641(y,d); y=graph_fn1642(y,d); y=graph_fn1643(y,d); y=graph_fn1644(y,d); y=graph_fn1645(y,d); y=graph_fn1646(y,d); y=graph_fn1647(y,d); y=graph_fn1648(y,d); y=graph_fn1649(y,d); y=graph_fn1650(y,d); y=graph_fn1651(y,d); y=graph_fn1652(y,d); y=graph_fn1653(y,d); y=graph_fn1654(y,d); y=graph_fn1655(y,d); y=graph_fn1656(y,d); y=graph_fn1657(y,d); y=graph_fn1658(y,d); y=graph_fn1659(y,d); y=graph_fn1660(y,d); y=graph_fn1661(y,d); y=graph_fn1662(y,d); y=graph_fn1663(y,d); y=graph_fn1664(y,d); y=graph_fn1665(y,d); y=graph_fn1666(y,d); y=graph_fn1667(y,d); y=graph_fn1668(y,d); y=graph_fn1669(y,d); y=graph_fn1670(y,d); y=graph_fn1671(y,d); y=graph_fn1672(y,d); y=graph_fn1673(y,d); y=graph_fn1674(y,d); y=graph_fn1675(y,d); y=graph_fn1676(y,d); y=graph_fn1677(y,d); y=graph_fn1678(y,d); y=graph_fn1679(y,d); y=graph_fn1680(y,d); y=graph_fn1681(y,d); y=graph_fn1682(y,d); y=graph_fn1683(y,d); y=graph_fn1684(y,d); y=graph_fn1685(y,d); y=graph_fn1686(y,d); y=graph_fn1687(y,d); y=graph_fn1688(y,d); y=graph_fn1689(y,d); y=graph_fn1690(y,d); y=graph_fn1691(y,d); y=graph_fn1692(y,d); y=graph_fn1693(y,d); y=graph_fn1694(y,d); y=graph_fn1695(y,d); y=graph_fn1696(y,d); y=graph_fn1697(y,d); y=graph_fn1698(y,d); y=graph_fn1699(y,d); y=graph_fn1700(y,d); y=graph_fn1701(y,d); y=graph_fn1702(y,d); y=graph_fn1703(y,d); y=graph_fn1704(y,d); y=graph_fn1705(y,d); y=graph_fn1706(y,d); y=graph_fn1707(y,d); y=graph_fn1708(y,d); y=graph_fn1709(y,d); y=graph_fn1710(y,d); y=graph_fn1711(y,d); y=graph_fn1712(y,d); y=graph_fn1713(y,d); y=graph_fn1714(y,d); y=graph_fn1715(y,d); y=graph_fn1716(y,d); y=graph_fn1717(y,d); y=graph_fn1718(y,d); y=graph_fn1719(y,d); y=graph_fn1720(y,d); y=graph_fn1721(y,d); y=graph_fn1722(y,d); y=graph_fn1723(y,d); y=graph_fn1724(y,d); y=graph_fn1725(y,d); y=graph_fn1726(y,d); y=graph_fn1727(y,d); y=graph_fn1728(y,d); y=graph_fn1729(y,d); y=graph_fn1730(y,d); y=graph_fn1731(y,d); y=graph_fn1732(y,d); y=graph_fn1733(y,d); y=graph_fn1734(y,d); y=graph_fn1735(y,d); y=graph_fn1736(y,d); y=graph_fn1737(y,d); y=graph_fn1738(y,d); y=graph_fn1739(y,d); y=graph_fn1740(y,d); y=graph_fn1741(y,d); y=graph_fn1742(y,d); y=graph_fn1743(y,d); y=graph_fn1744(y,d); y=graph_fn1745(y,d); y=graph_fn1746(y,d); y=graph_fn1747(y,d); y=graph_fn1748(y,d); y=graph_fn1749(y,d); y=graph_fn1750(y,d); y=graph_fn1751(y,d); y=graph_fn1752(y,d); y=graph_fn1753(y,d); y=graph_fn1754(y,d); y=graph_fn1755(y,d); y=graph_fn1756(y,d); y=graph_fn1757(y,d); y=graph_fn1758(y,d); y=graph_fn1759(y,d); y=graph_fn1760(y,d); y=graph_fn1761(y,d); y=graph_fn1762(y,d); y=graph_fn1763(y,d); y=graph_fn1764(y,d); y=graph_fn1765(y,d); y=graph_fn1766(y,d); y=graph_fn1767(y,d); y=graph_fn1768(y,d); y=graph_fn1769(y,d); y=graph_fn1770(y,d); y=graph_fn1771(y,d); y=graph_fn1772(y,d); y=graph_fn1773(y,d); y=graph_fn1774(y,d); y=graph_fn1775(y,d); y=graph_fn1776(y,d); y=graph_fn1777(y,d); y=graph_fn1778(y,d); y=graph_fn1779(y,d); y=graph_fn1780(y,d); y=graph_fn1781(y,d); y=graph_fn1782(y,d); y=graph_fn1783(y,d); y=graph_fn1784(y,d); y=graph_fn1785(y,d); y=graph_fn1786(y,d); y=graph_fn1787(y,d); y=graph_fn1788(y,d); y=graph_fn1789(y,d); y=graph_fn1790(y,d); y=graph_fn1791(y,d); y=graph_fn1792(y,d); y=graph_fn1793(y,d); y=graph_fn1794(y,d); y=graph_fn1795(y,d); y=graph_fn1796(y,d); y=graph_fn1797(y,d); y=graph_fn1798(y,d); y=graph_fn1799(y,d); y=graph_fn1800(y,d); y=graph_fn1801(y,d); y=graph_fn1802(y,d); y=graph_fn1803(y,d); y=graph_fn1804(y,d); y=graph_fn1805(y,d); y=graph_fn1806(y,d); y=graph_fn1807(y,d); y=graph_fn1808(y,d); y=graph_fn1809(y,d); y=graph_fn1810(y,d); y=graph_fn1811(y,d); y=graph_fn1812(y,d); y=graph_fn1813(y,d); y=graph_fn1814(y,d); y=graph_fn1815(y,d); y=graph_fn1816(y,d); y=graph_fn1817(y,d); y=graph_fn1818(y,d); y=graph_fn1819(y,d); y=graph_fn1820(y,d); y=graph_fn1821(y,d); y=graph_fn1822(y,d); y=graph_fn1823(y,d); y=graph_fn1824(y,d); y=graph_fn1825(y,d); y=graph_fn1826(y,d); y=graph_fn1827(y,d); y=graph_fn1828(y,d); y=graph_fn1829(y,d); y=graph_fn1830(y,d); y=graph_fn1831(y,d); y=graph_fn1832(y,d); y=graph_fn1833(y,d); y=graph_fn1834(y,d); y=graph_fn1835(y,d); y=graph_fn1836(y,d); y=graph_fn1837(y,d); y=graph_fn1838(y,d); y=graph_fn1839(y,d); y=graph_fn1840(y,d); y=graph_fn1841(y,d); y=graph_fn1842(y,d); y=graph_fn1843(y,d); y=graph_fn1844(y,d); y=graph_fn1845(y,d); y=graph_fn1846(y,d); y=graph_fn1847(y,d); y=graph_fn1848(y,d); y=graph_fn1849(y,d); y=graph_fn1850(y,d); y=graph_fn1851(y,d); y=graph_fn1852(y,d); y=graph_fn1853(y,d); y=graph_fn1854(y,d); y=graph_fn1855(y,d); y=graph_fn1856(y,d); y=graph_fn1857(y,d); y=graph_fn1858(y,d); y=graph_fn1859(y,d); y=graph_fn1860(y,d); y=graph_fn1861(y,d); y=graph_fn1862(y,d); y=graph_fn1863(y,d); y=graph_fn1864(y,d); y=graph_fn1865(y,d); y=graph_fn1866(y,d); y=graph_fn1867(y,d); y=graph_fn1868(y,d); y=graph_fn1869(y,d); y=graph_fn1870(y,d); y=graph_fn1871(y,d); y=graph_fn1872(y,d); y=graph_fn1873(y,d); y=graph_fn1874(y,d); y=graph_fn1875(y,d); y=graph_fn1876(y,d); y=graph_fn1877(y,d); y=graph_fn1878(y,d); y=graph_fn1879(y,d); y=graph_fn1880(y,d); y=graph_fn1881(y,d); y=graph_fn1882(y,d); y=graph_fn1883(y,d); y=graph_fn1884(y,d); y=graph_fn1885(y,d); y=graph_fn1886(y,d); y=graph_fn1887(y,d); y=graph_fn1888(y,d); y=graph_fn1889(y,d); y=graph_fn1890(y,d); y=graph_fn1891(y,d); y=graph_fn1892(y,d); y=graph_fn1893(y,d); y=graph_fn1894(y,d); y=graph_fn1895(y,d); y=graph_fn1896(y,d); y=graph_fn1897(y,d); y=graph_fn1898(y,d); y=graph_fn1899(y,d); y=graph_fn1900(y,d); y=graph_fn1901(y,d); y=graph_fn1902(y,d); y=graph_fn1903(y,d); y=graph_fn1904(y,d); y=graph_fn1905(y,d); y=graph_fn1906(y,d); y=graph_fn1907(y,d); y=graph_fn1908(y,d); y=graph_fn1909(y,d); y=graph_fn1910(y,d); y=graph_fn1911(y,d); y=graph_fn1912(y,d); y=graph_fn1913(y,d); y=graph_fn1914(y,d); y=graph_fn1915(y,d); y=graph_fn1916(y,d); y=graph_fn1917(y,d); y=graph_fn1918(y,d); y=graph_fn1919(y,d); y=graph_fn1920(y,d); y=graph_fn1921(y,d); y=graph_fn1922(y,d); y=graph_fn1923(y,d); y=graph_fn1924(y,d); y=graph_fn1925(y,d); y=graph_fn1926(y,d); y=graph_fn1927(y,d); y=graph_fn1928(y,d); y=graph_fn1929(y,d); y=graph_fn1930(y,d); y=graph_fn1931(y,d); y=graph_fn1932(y,d); y=graph_fn1933(y,d); y=graph_fn1934(y,d); y=graph_fn1935(y,d); y=graph_fn1936(y,d); y=graph_fn1937(y,d); y=graph_fn1938(y,d); y=graph_fn1939(y,d); y=graph_fn1940(y,d); y=graph_fn1941(y,d); y=graph_fn1942(y,d); y=graph_fn1943(y,d); y=graph_fn1944(y,d); y=graph_fn1945(y,d); y=graph_fn1946(y,d); y=graph_fn1947(y,d); y=graph_fn1948(y,d); y=graph_fn1949(y,d); y=graph_fn1950(y,d); y=graph_fn1951(y,d); y=graph_fn1952(y,d); y=graph_fn1953(y,d); y=graph_fn1954(y,d); y=graph_fn1955(y,d); y=graph_fn1956(y,d); y=graph_fn1957(y,d); y=graph_fn1958(y,d); y=graph_fn1959(y,d); y=graph_fn1960(y,d); y=graph_fn1961(y,d); y=graph_fn1962(y,d); y=graph_fn1963(y,d); y=graph_fn1964(y,d); y=graph_fn1965(y,d); y=graph_fn1966(y,d); y=graph_fn1967(y,d); y=graph_fn1968(y,d); y=graph_fn1969(y,d); y=graph_fn1970(y,d); y=graph_fn1971(y,d); y=graph_fn1972(y,d); y=graph_fn1973(y,d); y=graph_fn1974(y,d); y=graph_fn1975(y,d); y=graph_fn1976(y,d); y=graph_fn1977(y,d); y=graph_fn1978(y,d); y=graph_fn1979(y,d); y=graph_fn1980(y,d); y=graph_fn1981(y,d); y=graph_fn1982(y,d); y=graph_fn1983(y,d); y=graph_fn1984(y,d); y=graph_fn1985(y,d); y=graph_fn1986(y,d); y=graph_fn1987(y,d); y=graph_fn1988(y,d); y=graph_fn1989(y,d); y=graph_fn1990(y,d); y=graph_fn1991(y,d); y=graph_fn1992(y,d); y=graph_fn1993(y,d); y=graph_fn1994(y,d); y=graph_fn1995(y,d); y=graph_fn1996(y,d); y=graph_fn1997(y,d); y=graph_fn1998(y,d); y=graph_fn1999(y,d); y=graph_fn2000(y,d); y=graph_fn2001(y,d); y=graph_fn2002(y,d); y=graph_fn2003(y,d); y=graph_fn2004(y,d); y=graph_fn2005(y,d); y=graph_fn2006(y,d); y=graph_fn2007(y,d); y=graph_fn2008(y,d); y=graph_fn2009(y,d); y=graph_fn2010(y,d); y=graph_fn2011(y,d); y=graph_fn2012(y,d); y=graph_fn2013(y,d); y=graph_fn2014(y,d); y=graph_fn2015(y,d); y=graph_fn2016(y,d); y=graph_fn2017(y,d); y=graph_fn2018(y,d); y=graph_fn2019(y,d); y=graph_fn2020(y,d); y=graph_fn2021(y,d); y=graph_fn2022(y,d); y=graph_fn2023(y,d); y=graph_fn2024(y,d); y=graph_fn2025(y,d); y=graph_fn2026(y,d); y=graph_fn2027(y,d); y=graph_fn2028(y,d); y=graph_fn2029(y,d); y=graph_fn2030(y,d); y=graph_fn2031(y,d); y=graph_fn2032(y,d); y=graph_fn2033(y,d); y=graph_fn2034(y,d); y=graph_fn2035(y,d); y=graph_fn2036(y,d); y=graph_fn2037(y,d); y=graph_fn2038(y,d); y=graph_fn2039(y,d); y=graph_fn2040(y,d); y=graph_fn2041(y,d); y=graph_fn2042(y,d); y=graph_fn2043(y,d); y=graph_fn2044(y,d); y=graph_fn2045(y,d); y=graph_fn2046(y,d); y=graph_fn2047(y,d); y=graph_fn2048(y,d); y=graph_fn2049(y,d); y=graph_fn2050(y,d); y=graph_fn2051(y,d); y=graph_fn2052(y,d); y=graph_fn2053(y,d); y=graph_fn2054(y,d); y=graph_fn2055(y,d); y=graph_fn2056(y,d); y=graph_fn2057(y,d); y=graph_fn2058(y,d); y=graph_fn2059(y,d); y=graph_fn2060(y,d); y=graph_fn2061(y,d); y=graph_fn2062(y,d); y=graph_fn2063(y,d); y=graph_fn2064(y,d); y=graph_fn2065(y,d); y=graph_fn2066(y,d); y=graph_fn2067(y,d); y=graph_fn2068(y,d); y=graph_fn2069(y,d); y=graph_fn2070(y,d); y=graph_fn2071(y,d); y=graph_fn2072(y,d); y=graph_fn2073(y,d); y=graph_fn2074(y,d); y=graph_fn2075(y,d); y=graph_fn2076(y,d); y=graph_fn2077(y,d); y=graph_fn2078(y,d); y=graph_fn2079(y,d); y=graph_fn2080(y,d); y=graph_fn2081(y,d); y=graph_fn2082(y,d); y=graph_fn2083(y,d); y=graph_fn2084(y,d); y=graph_fn2085(y,d); y=graph_fn2086(y,d); y=graph_fn2087(y,d); y=graph_fn2088(y,d); y=graph_fn2089(y,d); y=graph_fn2090(y,d); y=graph_fn2091(y,d); y=graph_fn2092(y,d); y=graph_fn2093(y,d); y=graph_fn2094(y,d); y=graph_fn2095(y,d); y=graph_fn2096(y,d); y=graph_fn2097(y,d); y=graph_fn2098(y,d); y=graph_fn2099(y,d); y=graph_fn2100(y,d); y=graph_fn2101(y,d); y=graph_fn2102(y,d); y=graph_fn2103(y,d); y=graph_fn2104(y,d); y=graph_fn2105(y,d); y=graph_fn2106(y,d); y=graph_fn2107(y,d); y=graph_fn2108(y,d); y=graph_fn2109(y,d); y=graph_fn2110(y,d); y=graph_fn2111(y,d); y=graph_fn2112(y,d); y=graph_fn2113(y,d); y=graph_fn2114(y,d); y=graph_fn2115(y,d); y=graph_fn2116(y,d); y=graph_fn2117(y,d); y=graph_fn2118(y,d); y=graph_fn2119(y,d); y=graph_fn2120(y,d); y=graph_fn2121(y,d); y=graph_fn2122(y,d); y=graph_fn2123(y,d); y=graph_fn2124(y,d); y=graph_fn2125(y,d); y=graph_fn2126(y,d); y=graph_fn2127(y,d); y=graph_fn2128(y,d); y=graph_fn2129(y,d); y=graph_fn2130(y,d); y=graph_fn2131(y,d); y=graph_fn2132(y,d); y=graph_fn2133(y,d); y=graph_fn2134(y,d); y=graph_fn2135(y,d); y=graph_fn2136(y,d); y=graph_fn2137(y,d); y=graph_fn2138(y,d); y=graph_fn2139(y,d); y=graph_fn2140(y,d); y=graph_fn2141(y,d); y=graph_fn2142(y,d); y=graph_fn2143(y,d); y=graph_fn2144(y,d); y=graph_fn2145(y,d); y=graph_fn2146(y,d); y=graph_fn2147(y,d); y=graph_fn2148(y,d); y=graph_fn2149(y,d); y=graph_fn2150(y,d); y=graph_fn2151(y,d); y=graph_fn2152(y,d); y=graph_fn2153(y,d); y=graph_fn2154(y,d); y=graph_fn2155(y,d); y=graph_fn2156(y,d); y=graph_fn2157(y,d); y=graph_fn2158(y,d); y=graph_fn2159(y,d); y=graph_fn2160(y,d); y=graph_fn2161(y,d); y=graph_fn2162(y,d); y=graph_fn2163(y,d); y=graph_fn2164(y,d); y=graph_fn2165(y,d); y=graph_fn2166(y,d); y=graph_fn2167(y,d); y=graph_fn2168(y,d); y=graph_fn2169(y,d); y=graph_fn2170(y,d); y=graph_fn2171(y,d); y=graph_fn2172(y,d); y=graph_fn2173(y,d); y=graph_fn2174(y,d); y=graph_fn2175(y,d); y=graph_fn2176(y,d); y=graph_fn2177(y,d); y=graph_fn2178(y,d); y=graph_fn2179(y,d); y=graph_fn2180(y,d); y=graph_fn2181(y,d); y=graph_fn2182(y,d); y=graph_fn2183(y,d); y=graph_fn2184(y,d); y=graph_fn2185(y,d); y=graph_fn2186(y,d); y=graph_fn2187(y,d); y=graph_fn2188(y,d); y=graph_fn2189(y,d); y=graph_fn2190(y,d); y=graph_fn2191(y,d); y=graph_fn2192(y,d); y=graph_fn2193(y,d); y=graph_fn2194(y,d); y=graph_fn2195(y,d); y=graph_fn2196(y,d); y=graph_fn2197(y,d); y=graph_fn2198(y,d); y=graph_fn2199(y,d); y=graph_fn2200(y,d); y=graph_fn2201(y,d); y=graph_fn2202(y,d); y=graph_fn2203(y,d); y=graph_fn2204(y,d); y=graph_fn2205(y,d); y=graph_fn2206(y,d); y=graph_fn2207(y,d); y=graph_fn2208(y,d); y=graph_fn2209(y,d); y=graph_fn2210(y,d); y=graph_fn2211(y,d); y=graph_fn2212(y,d); y=graph_fn2213(y,d); y=graph_fn2214(y,d); y=graph_fn2215(y,d); y=graph_fn2216(y,d); y=graph_fn2217(y,d); y=graph_fn2218(y,d); y=graph_fn2219(y,d); y=graph_fn2220(y,d); y=graph_fn2221(y,d); y=graph_fn2222(y,d); y=graph_fn2223(y,d); y=graph_fn2224(y,d); y=graph_fn2225(y,d); y=graph_fn2226(y,d); y=graph_fn2227(y,d); y=graph_fn2228(y,d); y=graph_fn2229(y,d); y=graph_fn2230(y,d); y=graph_fn2231(y,d); y=graph_fn2232(y,d); y=graph_fn2233(y,d); y=graph_fn2234(y,d); y=graph_fn2235(y,d); y=graph_fn2236(y,d); y=graph_fn2237(y,d); y=graph_fn2238(y,d); y=graph_fn2239(y,d); y=graph_fn2240(y,d); y=graph_fn2241(y,d); y=graph_fn2242(y,d); y=graph_fn2243(y,d); y=graph_fn2244(y,d); y=graph_fn2245(y,d); y=graph_fn2246(y,d); y=graph_fn2247(y,d); y=graph_fn2248(y,d); y=graph_fn2249(y,d); y=graph_fn2250(y,d); y=graph_fn2251(y,d); y=graph_fn2252(y,d); y=graph_fn2253(y,d); y=graph_fn2254(y,d); y=graph_fn2255(y,d); y=graph_fn2256(y,d); y=graph_fn2257(y,d); y=graph_fn2258(y,d); y=graph_fn2259(y,d); y=graph_fn2260(y,d); y=graph_fn2261(y,d); y=graph_fn2262(y,d); y=graph_fn2263(y,d); y=graph_fn2264(y,d); y=graph_fn2265(y,d); y=graph_fn2266(y,d); y=graph_fn2267(y,d); y=graph_fn2268(y,d); y=graph_fn2269(y,d); y=graph_fn2270(y,d); y=graph_fn2271(y,d); y=graph_fn2272(y,d); y=graph_fn2273(y,d); y=graph_fn2274(y,d); y=graph_fn2275(y,d); y=graph_fn2276(y,d); y=graph_fn2277(y,d); y=graph_fn2278(y,d); y=graph_fn2279(y,d); y=graph_fn2280(y,d); y=graph_fn2281(y,d); y=graph_fn2282(y,d); y=graph_fn2283(y,d); y=graph_fn2284(y,d); y=graph_fn2285(y,d); y=graph_fn2286(y,d); y=graph_fn2287(y,d); y=graph_fn2288(y,d); y=graph_fn2289(y,d); y=graph_fn2290(y,d); y=graph_fn2291(y,d); y=graph_fn2292(y,d); y=graph_fn2293(y,d); y=graph_fn2294(y,d); y=graph_fn2295(y,d); y=graph_fn2296(y,d); y=graph_fn2297(y,d); y=graph_fn2298(y,d); y=graph_fn2299(y,d); y=graph_fn2300(y,d); y=graph_fn2301(y,d); y=graph_fn2302(y,d); y=graph_fn2303(y,d); y=graph_fn2304(y,d); y=graph_fn2305(y,d); y=graph_fn2306(y,d); y=graph_fn2307(y,d); y=graph_fn2308(y,d); y=graph_fn2309(y,d); y=graph_fn2310(y,d); y=graph_fn2311(y,d); y=graph_fn2312(y,d); y=graph_fn2313(y,d); y=graph_fn2314(y,d); y=graph_fn2315(y,d); y=graph_fn2316(y,d); y=graph_fn2317(y,d); y=graph_fn2318(y,d); y=graph_fn2319(y,d); y=graph_fn2320(y,d); y=graph_fn2321(y,d); y=graph_fn2322(y,d); y=graph_fn2323(y,d); y=graph_fn2324(y,d); y=graph_fn2325(y,d); y=graph_fn2326(y,d); y=graph_fn2327(y,d); y=graph_fn2328(y,d); y=graph_fn2329(y,d); y=graph_fn2330(y,d); y=graph_fn2331(y,d); y=graph_fn2332(y,d); y=graph_fn2333(y,d); y=graph_fn2334(y,d); y=graph_fn2335(y,d); y=graph_fn2336(y,d); y=graph_fn2337(y,d); y=graph_fn2338(y,d); y=graph_fn2339(y,d); y=graph_fn2340(y,d); y=graph_fn2341(y,d); y=graph_fn2342(y,d); y=graph_fn2343(y,d); y=graph_fn2344(y,d); y=graph_fn2345(y,d); y=graph_fn2346(y,d); y=graph_fn2347(y,d); y=graph_fn2348(y,d); y=graph_fn2349(y,d); y=graph_fn2350(y,d); y=graph_fn2351(y,d); y=graph_fn2352(y,d); y=graph_fn2353(y,d); y=graph_fn2354(y,d); y=graph_fn2355(y,d); y=graph_fn2356(y,d); y=graph_fn2357(y,d); y=graph_fn2358(y,d); y=graph_fn2359(y,d); y=graph_fn2360(y,d); y=graph_fn2361(y,d); y=graph_fn2362(y,d); y=graph_fn2363(y,d); y=graph_fn2364(y,d); y=graph_fn2365(y,d); y=graph_fn2366(y,d); y=graph_fn2367(y,d); y=graph_fn2368(y,d); y=graph_fn2369(y,d); y=graph_fn2370(y,d); y=graph_fn2371(y,d); y=graph_fn2372(y,d); y=graph_fn2373(y,d); y=graph_fn2374(y,d); y=graph_fn2375(y,d); y=graph_fn2376(y,d); y=graph_fn2377(y,d); y=graph_fn2378(y,d); y=graph_fn2379(y,d); y=graph_fn2380(y,d); y=graph_fn2381(y,d); y=graph_fn2382(y,d); y=graph_fn2383(y,d); y=graph_fn2384(y,d); y=graph_fn2385(y,d); y=graph_fn2386(y,d); y=graph_fn2387(y,d); y=graph_fn2388(y,d); y=graph_fn2389(y,d); y=graph_fn2390(y,d); y=graph_fn2391(y,d); y=graph_fn2392(y,d); y=graph_fn2393(y,d); y=graph_fn2394(y,d); y=graph_fn2395(y,d); y=graph_fn2396(y,d); y=graph_fn2397(y,d); y=graph_fn2398(y,d); y=graph_fn2399(y,d); y=graph_fn2400(y,d); y=graph_fn2401(y,d); y=graph_fn2402(y,d); y=graph_fn2403(y,d); y=graph_fn2404(y,d); y=graph_fn2405(y,d); y=graph_fn2406(y,d); y=graph_fn2407(y,d); y=graph_fn2408(y,d); y=graph_fn2409(y,d); y=graph_fn2410(y,d); y=graph_fn2411(y,d); y=graph_fn2412(y,d); y=graph_fn2413(y,d); y=graph_fn2414(y,d); y=graph_fn2415(y,d); y=graph_fn2416(y,d); y=graph_fn2417(y,d); y=graph_fn2418(y,d); y=graph_fn2419(y,d); y=graph_fn2420(y,d); y=graph_fn2421(y,d); y=graph_fn2422(y,d); y=graph_fn2423(y,d); y=graph_fn2424(y,d); y=graph_fn2425(y,d); y=graph_fn2426(y,d); y=graph_fn2427(y,d); y=graph_fn2428(y,d); y=graph_fn2429(y,d); y=graph_fn2430(y,d); y=graph_fn2431(y,d); y=graph_fn2432(y,d); y=graph_fn2433(y,d); y=graph_fn2434(y,d); y=graph_fn2435(y,d); y=graph_fn2436(y,d); y=graph_fn2437(y,d); y=graph_fn2438(y,d); y=graph_fn2439(y,d); y=graph_fn2440(y,d); y=graph_fn2441(y,d); y=graph_fn2442(y,d); y=graph_fn2443(y,d); y=graph_fn2444(y,d); y=graph_fn2445(y,d); y=graph_fn2446(y,d); y=graph_fn2447(y,d); y=graph_fn2448(y,d); y=graph_fn2449(y,d); y=graph_fn2450(y,d); y=graph_fn2451(y,d); y=graph_fn2452(y,d); y=graph_fn2453(y,d); y=graph_fn2454(y,d); y=graph_fn2455(y,d); y=graph_fn2456(y,d); y=graph_fn2457(y,d); y=graph_fn2458(y,d); y=graph_fn2459(y,d); y=graph_fn2460(y,d); y=graph_fn2461(y,d); y=graph_fn2462(y,d); y=graph_fn2463(y,d); y=graph_fn2464(y,d); y=graph_fn2465(y,d); y=graph_fn2466(y,d); y=graph_fn2467(y,d); y=graph_fn2468(y,d); y=graph_fn2469(y,d); y=graph_fn2470(y,d); y=graph_fn2471(y,d); y=graph_fn2472(y,d); y=graph_fn2473(y,d); y=graph_fn2474(y,d); y=graph_fn2475(y,d); y=graph_fn2476(y,d); y=graph_fn2477(y,d); y=graph_fn2478(y,d); y=graph_fn2479(y,d); y=graph_fn2480(y,d); y=graph_fn2481(y,d); y=graph_fn2482(y,d); y=graph_fn2483(y,d); y=graph_fn2484(y,d); y=graph_fn2485(y,d); y=graph_fn2486(y,d); y=graph_fn2487(y,d); y=graph_fn2488(y,d); y=graph_fn2489(y,d); y=graph_fn2490(y,d); y=graph_fn2491(y,d); y=graph_fn2492(y,d); y=graph_fn2493(y,d); y=graph_fn2494(y,d); y=graph_fn2495(y,d); y=graph_fn2496(y,d); y=graph_fn2497(y,d); y=graph_fn2498(y,d); y=graph_fn2499(y,d); y=graph_fn2500(y,d); y=graph_fn2501(y,d); y=graph_fn2502(y,d); y=graph_fn2503(y,d); y=graph_fn2504(y,d); y=graph_fn2505(y,d); y=graph_fn2506(y,d); y=graph_fn2507(y,d); y=graph_fn2508(y,d); y=graph_fn2509(y,d); y=graph_fn2510(y,d); y=graph_fn2511(y,d); y=graph_fn2512(y,d); y=graph_fn2513(y,d); y=graph_fn2514(y,d); y=graph_fn2515(y,d); y=graph_fn2516(y,d); y=graph_fn2517(y,d); y=graph_fn2518(y,d); y=graph_fn2519(y,d); y=graph_fn2520(y,d); y=graph_fn2521(y,d); y=graph_fn2522(y,d); y=graph_fn2523(y,d); y=graph_fn2524(y,d); y=graph_fn2525(y,d); y=graph_fn2526(y,d); y=graph_fn2527(y,d); y=graph_fn2528(y,d); y=graph_fn2529(y,d); y=graph_fn2530(y,d); y=graph_fn2531(y,d); y=graph_fn2532(y,d); y=graph_fn2533(y,d); y=graph_fn2534(y,d); y=graph_fn2535(y,d); y=graph_fn2536(y,d); y=graph_fn2537(y,d); y=graph_fn2538(y,d); y=graph_fn2539(y,d); y=graph_fn2540(y,d); y=graph_fn2541(y,d); y=graph_fn2542(y,d); y=graph_fn2543(y,d); y=graph_fn2544(y,d); y=graph_fn2545(y,d); y=graph_fn2546(y,d); y=graph_fn2547(y,d); y=graph_fn2548(y,d); y=graph_fn2549(y,d); y=graph_fn2550(y,d); y=graph_fn2551(y,d); y=graph_fn2552(y,d); y=graph_fn2553(y,d); y=graph_fn2554(y,d); y=graph_fn2555(y,d); y=graph_fn2556(y,d); y=graph_fn2557(y,d); y=graph_fn2558(y,d); y=graph_fn2559(y,d); y=graph_fn2560(y,d); y=graph_fn2561(y,d); y=graph_fn2562(y,d); y=graph_fn2563(y,d); y=graph_fn2564(y,d); y=graph_fn2565(y,d); y=graph_fn2566(y,d); y=graph_fn2567(y,d); y=graph_fn2568(y,d); y=graph_fn2569(y,d); y=graph_fn2570(y,d); y=graph_fn2571(y,d); y=graph_fn2572(y,d); y=graph_fn2573(y,d); y=graph_fn2574(y,d); y=graph_fn2575(y,d); y=graph_fn2576(y,d); y=graph_fn2577(y,d); y=graph_fn2578(y,d); y=graph_fn2579(y,d); y=graph_fn2580(y,d); y=graph_fn2581(y,d); y=graph_fn2582(y,d); y=graph_fn2583(y,d); y=graph_fn2584(y,d); y=graph_fn2585(y,d); y=graph_fn2586(y,d); y=graph_fn2587(y,d); y=graph_fn2588(y,d); y=graph_fn2589(y,d); y=graph_fn2590(y,d); y=graph_fn2591(y,d); y=graph_fn2592(y,d); y=graph_fn2593(y,d); y=graph_fn2594(y,d); y=graph_fn2595(y,d); y=graph_fn2596(y,d); y=graph_fn2597(y,d); y=graph_fn2598(y,d); y=graph_fn2599(y,d); y=graph_fn2600(y,d); y=graph_fn2601(y,d); y=graph_fn2602(y,d); y=graph_fn2603(y,d); y=graph_fn2604(y,d); y=graph_fn2605(y,d); y=graph_fn2606(y,d); y=graph_fn2607(y,d); y=graph_fn2608(y,d); y=graph_fn2609(y,d); y=graph_fn2610(y,d); y=graph_fn2611(y,d); y=graph_fn2612(y,d); y=graph_fn2613(y,d); y=graph_fn2614(y,d); y=graph_fn2615(y,d); y=graph_fn2616(y,d); y=graph_fn2617(y,d); y=graph_fn2618(y,d); y=graph_fn2619(y,d); y=graph_fn2620(y,d); y=graph_fn2621(y,d); y=graph_fn2622(y,d); y=graph_fn2623(y,d); y=graph_fn2624(y,d); y=graph_fn2625(y,d); y=graph_fn2626(y,d); y=graph_fn2627(y,d); y=graph_fn2628(y,d); y=graph_fn2629(y,d); y=graph_fn2630(y,d); y=graph_fn2631(y,d); y=graph_fn2632(y,d); y=graph_fn2633(y,d); y=graph_fn2634(y,d); y=graph_fn2635(y,d); y=graph_fn2636(y,d); y=graph_fn2637(y,d); y=graph_fn2638(y,d); y=graph_fn2639(y,d); y=graph_fn2640(y,d); y=graph_fn2641(y,d); y=graph_fn2642(y,d); y=graph_fn2643(y,d); y=graph_fn2644(y,d); y=graph_fn2645(y,d); y=graph_fn2646(y,d); y=graph_fn2647(y,d); y=graph_fn2648(y,d); y=graph_fn2649(y,d); y=graph_fn2650(y,d); y=graph_fn2651(y,d); y=graph_fn2652(y,d); y=graph_fn2653(y,d); y=graph_fn2654(y,d); y=graph_fn2655(y,d); y=graph_fn2656(y,d); y=graph_fn2657(y,d); y=graph_fn2658(y,d); y=graph_fn2659(y,d); y=graph_fn2660(y,d); y=graph_fn2661(y,d); y=graph_fn2662(y,d); y=graph_fn2663(y,d); y=graph_fn2664(y,d); y=graph_fn2665(y,d); y=graph_fn2666(y,d); y=graph_fn2667(y,d); y=graph_fn2668(y,d); y=graph_fn2669(y,d); y=graph_fn2670(y,d); y=graph_fn2671(y,d); y=graph_fn2672(y,d); y=graph_fn2673(y,d); y=graph_fn2674(y,d); y=graph_fn2675(y,d); y=graph_fn2676(y,d); y=graph_fn2677(y,d); y=graph_fn2678(y,d); y=graph_fn2679(y,d); y=graph_fn2680(y,d); y=graph_fn2681(y,d); y=graph_fn2682(y,d); y=graph_fn2683(y,d); y=graph_fn2684(y,d); y=graph_fn2685(y,d); y=graph_fn2686(y,d); y=graph_fn2687(y,d); y=graph_fn2688(y,d); y=graph_fn2689(y,d); y=graph_fn2690(y,d); y=graph_fn2691(y,d); y=graph_fn2692(y,d); y=graph_fn2693(y,d); y=graph_fn2694(y,d); y=graph_fn2695(y,d); y=graph_fn2696(y,d); y=graph_fn2697(y,d); y=graph_fn2698(y,d); y=graph_fn2699(y,d); y=graph_fn2700(y,d); y=graph_fn2701(y,d); y=graph_fn2702(y,d); y=graph_fn2703(y,d); y=graph_fn2704(y,d); y=graph_fn2705(y,d); y=graph_fn2706(y,d); y=graph_fn2707(y,d); y=graph_fn2708(y,d); y=graph_fn2709(y,d); y=graph_fn2710(y,d); y=graph_fn2711(y,d); y=graph_fn2712(y,d); y=graph_fn2713(y,d); y=graph_fn2714(y,d); y=graph_fn2715(y,d); y=graph_fn2716(y,d); y=graph_fn2717(y,d); y=graph_fn2718(y,d); y=graph_fn2719(y,d); y=graph_fn2720(y,d); y=graph_fn2721(y,d); y=graph_fn2722(y,d); y=graph_fn2723(y,d); y=graph_fn2724(y,d); y=graph_fn2725(y,d); y=graph_fn2726(y,d); y=graph_fn2727(y,d); y=graph_fn2728(y,d); y=graph_fn2729(y,d); y=graph_fn2730(y,d); y=graph_fn2731(y,d); y=graph_fn2732(y,d); y=graph_fn2733(y,d); y=graph_fn2734(y,d); y=graph_fn2735(y,d); y=graph_fn2736(y,d); y=graph_fn2737(y,d); y=graph_fn2738(y,d); y=graph_fn2739(y,d); y=graph_fn2740(y,d); y=graph_fn2741(y,d); y=graph_fn2742(y,d); y=graph_fn2743(y,d); y=graph_fn2744(y,d); y=graph_fn2745(y,d); y=graph_fn2746(y,d); y=graph_fn2747(y,d); y=graph_fn2748(y,d); y=graph_fn2749(y,d); y=graph_fn2750(y,d); y=graph_fn2751(y,d); y=graph_fn2752(y,d); y=graph_fn2753(y,d); y=graph_fn2754(y,d); y=graph_fn2755(y,d); y=graph_fn2756(y,d); y=graph_fn2757(y,d); y=graph_fn2758(y,d); y=graph_fn2759(y,d); y=graph_fn2760(y,d); y=graph_fn2761(y,d); y=graph_fn2762(y,d); y=graph_fn2763(y,d); y=graph_fn2764(y,d); y=graph_fn2765(y,d); y=graph_fn2766(y,d); y=graph_fn2767(y,d); y=graph_fn2768(y,d); y=graph_fn2769(y,d); y=graph_fn2770(y,d); y=graph_fn2771(y,d); y=graph_fn2772(y,d); y=graph_fn2773(y,d); y=graph_fn2774(y,d); y=graph_fn2775(y,d); y=graph_fn2776(y,d); y=graph_fn2777(y,d); y=graph_fn2778(y,d); y=graph_fn2779(y,d); y=graph_fn2780(y,d); y=graph_fn2781(y,d); y=graph_fn2782(y,d); y=graph_fn2783(y,d); y=graph_fn2784(y,d); y=graph_fn2785(y,d); y=graph_fn2786(y,d); y=graph_fn2787(y,d); y=graph_fn2788(y,d); y=graph_fn2789(y,d); y=graph_fn2790(y,d); y=graph_fn2791(y,d); y=graph_fn2792(y,d); y=graph_fn2793(y,d); y=graph_fn2794(y,d); y=graph_fn2795(y,d); y=graph_fn2796(y,d); y=graph_fn2797(y,d); y=graph_fn2798(y,d); y=graph_fn2799(y,d); y=graph_fn2800(y,d); y=graph_fn2801(y,d); y=graph_fn2802(y,d); y=graph_fn2803(y,d); y=graph_fn2804(y,d); y=graph_fn2805(y,d); y=graph_fn2806(y,d); y=graph_fn2807(y,d); y=graph_fn2808(y,d); y=graph_fn2809(y,d); y=graph_fn2810(y,d); y=graph_fn2811(y,d); y=graph_fn2812(y,d); y=graph_fn2813(y,d); y=graph_fn2814(y,d); y=graph_fn2815(y,d); y=graph_fn2816(y,d); y=graph_fn2817(y,d); y=graph_fn2818(y,d); y=graph_fn2819(y,d); y=graph_fn2820(y,d); y=graph_fn2821(y,d); y=graph_fn2822(y,d); y=graph_fn2823(y,d); y=graph_fn2824(y,d); y=graph_fn2825(y,d); y=graph_fn2826(y,d); y=graph_fn2827(y,d); y=graph_fn2828(y,d); y=graph_fn2829(y,d); y=graph_fn2830(y,d); y=graph_fn2831(y,d); y=graph_fn2832(y,d); y=graph_fn2833(y,d); y=graph_fn2834(y,d); y=graph_fn2835(y,d); y=graph_fn2836(y,d); y=graph_fn2837(y,d); y=graph_fn2838(y,d); y=graph_fn2839(y,d); y=graph_fn2840(y,d); y=graph_fn2841(y,d); y=graph_fn2842(y,d); y=graph_fn2843(y,d); y=graph_fn2844(y,d); y=graph_fn2845(y,d); y=graph_fn2846(y,d); y=graph_fn2847(y,d); y=graph_fn2848(y,d); y=graph_fn2849(y,d); y=graph_fn2850(y,d); y=graph_fn2851(y,d); y=graph_fn2852(y,d); y=graph_fn2853(y,d); y=graph_fn2854(y,d); y=graph_fn2855(y,d); y=graph_fn2856(y,d); y=graph_fn2857(y,d); y=graph_fn2858(y,d); y=graph_fn2859(y,d); y=graph_fn2860(y,d); y=graph_fn2861(y,d); y=graph_fn2862(y,d); y=graph_fn2863(y,d); y=graph_fn2864(y,d); y=graph_fn2865(y,d); y=graph_fn2866(y,d); y=graph_fn2867(y,d); y=graph_fn2868(y,d); y=graph_fn2869(y,d); y=graph_fn2870(y,d); y=graph_fn2871(y,d); y=graph_fn2872(y,d); y=graph_fn2873(y,d); y=graph_fn2874(y,d); y=graph_fn2875(y,d); y=graph_fn2876(y,d); y=graph_fn2877(y,d); y=graph_fn2878(y,d); y=graph_fn2879(y,d); y=graph_fn2880(y,d); y=graph_fn2881(y,d); y=graph_fn2882(y,d); y=graph_fn2883(y,d); y=graph_fn2884(y,d); y=graph_fn2885(y,d); y=graph_fn2886(y,d); y=graph_fn2887(y,d); y=graph_fn2888(y,d); y=graph_fn2889(y,d); y=graph_fn2890(y,d); y=graph_fn2891(y,d); y=graph_fn2892(y,d); y=graph_fn2893(y,d); y=graph_fn2894(y,d); y=graph_fn2895(y,d); y=graph_fn2896(y,d); y=graph_fn2897(y,d); y=graph_fn2898(y,d); y=graph_fn2899(y,d); y=graph_fn2900(y,d); y=graph_fn2901(y,d); y=graph_fn2902(y,d); y=graph_fn2903(y,d); y=graph_fn2904(y,d); y=graph_fn2905(y,d); y=graph_fn2906(y,d); y=graph_fn2907(y,d); y=graph_fn2908(y,d); y=graph_fn2909(y,d); y=graph_fn2910(y,d); y=graph_fn2911(y,d); y=graph_fn2912(y,d); y=graph_fn2913(y,d); y=graph_fn2914(y,d); y=graph_fn2915(y,d); y=graph_fn2916(y,d); y=graph_fn2917(y,d); y=graph_fn2918(y,d); y=graph_fn2919(y,d); y=graph_fn2920(y,d); y=graph_fn2921(y,d); y=graph_fn2922(y,d); y=graph_fn2923(y,d); y=graph_fn2924(y,d); y=graph_fn2925(y,d); y=graph_fn2926(y,d); y=graph_fn2927(y,d); y=graph_fn2928(y,d); y=graph_fn2929(y,d); y=graph_fn2930(y,d); y=graph_fn2931(y,d); y=graph_fn2932(y,d); y=graph_fn2933(y,d); y=graph_fn2934(y,d); y=graph_fn2935(y,d); y=graph_fn2936(y,d); y=graph_fn2937(y,d); y=graph_fn2938(y,d); y=graph_fn2939(y,d); y=graph_fn2940(y,d); y=graph_fn2941(y,d); y=graph_fn2942(y,d); y=graph_fn2943(y,d); y=graph_fn2944(y,d); y=graph_fn2945(y,d); y=graph_fn2946(y,d); y=graph_fn2947(y,d); y=graph_fn2948(y,d); y=graph_fn2949(y,d); y=graph_fn2950(y,d); y=graph_fn2951(y,d); y=graph_fn2952(y,d); y=graph_fn2953(y,d); y=graph_fn2954(y,d); y=graph_fn2955(y,d); y=graph_fn2956(y,d); y=graph_fn2957(y,d); y=graph_fn2958(y,d); y=graph_fn2959(y,d); y=graph_fn2960(y,d); y=graph_fn2961(y,d); y=graph_fn2962(y,d); y=graph_fn2963(y,d); y=graph_fn2964(y,d); y=graph_fn2965(y,d); y=graph_fn2966(y,d); y=graph_fn2967(y,d); y=graph_fn2968(y,d); y=graph_fn2969(y,d); y=graph_fn2970(y,d); y=graph_fn2971(y,d); y=graph_fn2972(y,d); y=graph_fn2973(y,d); y=graph_fn2974(y,d); y=graph_fn2975(y,d); y=graph_fn2976(y,d); y=graph_fn2977(y,d); y=graph_fn2978(y,d); y=graph_fn2979(y,d); y=graph_fn2980(y,d); y=graph_fn2981(y,d); y=graph_fn2982(y,d); y=graph_fn2983(y,d); y=graph_fn2984(y,d); y=graph_fn2985(y,d); y=graph_fn2986(y,d); y=graph_fn2987(y,d); y=graph_fn2988(y,d); y=graph_fn2989(y,d); y=graph_fn2990(y,d); y=graph_fn2991(y,d); y=graph_fn2992(y,d); y=graph_fn2993(y,d); y=graph_fn2994(y,d); y=graph_fn2995(y,d); y=graph_fn2996(y,d); y=graph_fn2997(y,d); y=graph_fn2998(y,d); y=graph_fn2999(y,d); y=graph_fn3000(y,d); y=graph_fn3001(y,d); y=graph_fn3002(y,d); y=graph_fn3003(y,d); y=graph_fn3004(y,d); y=graph_fn3005(y,d); y=graph_fn3006(y,d); y=graph_fn3007(y,d); y=graph_fn3008(y,d); y=graph_fn3009(y,d); y=graph_fn3010(y,d); y=graph_fn3011(y,d); y=graph_fn3012(y,d); y=graph_fn3013(y,d); y=graph_fn3014(y,d); y=graph_fn3015(y,d); y=graph_fn3016(y,d); y=graph_fn3017(y,d); y=graph_fn3018(y,d); y=graph_fn3019(y,d); y=graph_fn3020(y,d); y=graph_fn3021(y,d); y=graph_fn3022(y,d); y=graph_fn3023(y,d); y=graph_fn3024(y,d); y=graph_fn3025(y,d); y=graph_fn3026(y,d); y=graph_fn3027(y,d); y=graph_fn3028(y,d); y=graph_fn3029(y,d); y=graph_fn3030(y,d); y=graph_fn3031(y,d); y=graph_fn3032(y,d); y=graph_fn3033(y,d); y=graph_fn3034(y,d); y=graph_fn3035(y,d); y=graph_fn3036(y,d); y=graph_fn3037(y,d); y=graph_fn3038(y,d); y=graph_fn3039(y,d); y=graph_fn3040(y,d); y=graph_fn3041(y,d); y=graph_fn3042(y,d); y=graph_fn3043(y,d); y=graph_fn3044(y,d); y=graph_fn3045(y,d); y=graph_fn3046(y,d); y=graph_fn3047(y,d); y=graph_fn3048(y,d); y=graph_fn3049(y,d); y=graph_fn3050(y,d); y=graph_fn3051(y,d); y=graph_fn3052(y,d); y=graph_fn3053(y,d); y=graph_fn3054(y,d); y=graph_fn3055(y,d); y=graph_fn3056(y,d); y=graph_fn3057(y,d); y=graph_fn3058(y,d); y=graph_fn3059(y,d); y=graph_fn3060(y,d); y=graph_fn3061(y,d); y=graph_fn3062(y,d); y=graph_fn3063(y,d); y=graph_fn3064(y,d); y=graph_fn3065(y,d); y=graph_fn3066(y,d); y=graph_fn3067(y,d); y=graph_fn3068(y,d); y=graph_fn3069(y,d); y=graph_fn3070(y,d); y=graph_fn3071(y,d); y=graph_fn3072(y,d); y=graph_fn3073(y,d); y=graph_fn3074(y,d); y=graph_fn3075(y,d); y=graph_fn3076(y,d); y=graph_fn3077(y,d); y=graph_fn3078(y,d); y=graph_fn3079(y,d); y=graph_fn3080(y,d); y=graph_fn3081(y,d); y=graph_fn3082(y,d); y=graph_fn3083(y,d); y=graph_fn3084(y,d); y=graph_fn3085(y,d); y=graph_fn3086(y,d); y=graph_fn3087(y,d); y=graph_fn3088(y,d); y=graph_fn3089(y,d); y=graph_fn3090(y,d); y=graph_fn3091(y,d); y=graph_fn3092(y,d); y=graph_fn3093(y,d); y=graph_fn3094(y,d); y=graph_fn3095(y,d); y=graph_fn3096(y,d); y=graph_fn3097(y,d); y=graph_fn3098(y,d); y=graph_fn3099(y,d); y=graph_fn3100(y,d); y=graph_fn3101(y,d); y=graph_fn3102(y,d); y=graph_fn3103(y,d); y=graph_fn3104(y,d); y=graph_fn3105(y,d); y=graph_fn3106(y,d); y=graph_fn3107(y,d); y=graph_fn3108(y,d); y=graph_fn3109(y,d); y=graph_fn3110(y,d); y=graph_fn3111(y,d); y=graph_fn3112(y,d); y=graph_fn3113(y,d); y=graph_fn3114(y,d); y=graph_fn3115(y,d); y=graph_fn3116(y,d); y=graph_fn3117(y,d); y=graph_fn3118(y,d); y=graph_fn3119(y,d); y=graph_fn3120(y,d); y=graph_fn3121(y,d); y=graph_fn3122(y,d); y=graph_fn3123(y,d); y=graph_fn3124(y,d); y=graph_fn3125(y,d); y=graph_fn3126(y,d); y=graph_fn3127(y,d); y=graph_fn3128(y,d); y=graph_fn3129(y,d); y=graph_fn3130(y,d); y=graph_fn3131(y,d); y=graph_fn3132(y,d); y=graph_fn3133(y,d); y=graph_fn3134(y,d); y=graph_fn3135(y,d); y=graph_fn3136(y,d); y=graph_fn3137(y,d); y=graph_fn3138(y,d); y=graph_fn3139(y,d); y=graph_fn3140(y,d); y=graph_fn3141(y,d); y=graph_fn3142(y,d); y=graph_fn3143(y,d); y=graph_fn3144(y,d); y=graph_fn3145(y,d); y=graph_fn3146(y,d); y=graph_fn3147(y,d); y=graph_fn3148(y,d); y=graph_fn3149(y,d); y=graph_fn3150(y,d); y=graph_fn3151(y,d); y=graph_fn3152(y,d); y=graph_fn3153(y,d); y=graph_fn3154(y,d); y=graph_fn3155(y,d); y=graph_fn3156(y,d); y=graph_fn3157(y,d); y=graph_fn3158(y,d); y=graph_fn3159(y,d); y=graph_fn3160(y,d); y=graph_fn3161(y,d); y=graph_fn3162(y,d); y=graph_fn3163(y,d); y=graph_fn3164(y,d); y=graph_fn3165(y,d); y=graph_fn3166(y,d); y=graph_fn3167(y,d); y=graph_fn3168(y,d); y=graph_fn3169(y,d); y=graph_fn3170(y,d); y=graph_fn3171(y,d); y=graph_fn3172(y,d); y=graph_fn3173(y,d); y=graph_fn3174(y,d); y=graph_fn3175(y,d); y=graph_fn3176(y,d); y=graph_fn3177(y,d); y=graph_fn3178(y,d); y=graph_fn3179(y,d); y=graph_fn3180(y,d); y=graph_fn3181(y,d); y=graph_fn3182(y,d); y=graph_fn3183(y,d); y=graph_fn3184(y,d); y=graph_fn3185(y,d); y=graph_fn3186(y,d); y=graph_fn3187(y,d); y=graph_fn3188(y,d); y=graph_fn3189(y,d); y=graph_fn3190(y,d); y=graph_fn3191(y,d); y=graph_fn3192(y,d); y=graph_fn3193(y,d); y=graph_fn3194(y,d); y=graph_fn3195(y,d); y=graph_fn3196(y,d); y=graph_fn3197(y,d); y=graph_fn3198(y,d); y=graph_fn3199(y,d); y=graph_fn3200(y,d); y=graph_fn3201(y,d); y=graph_fn3202(y,d); y=graph_fn3203(y,d); y=graph_fn3204(y,d); y=graph_fn3205(y,d); y=graph_fn3206(y,d); y=graph_fn3207(y,d); y=graph_fn3208(y,d); y=graph_fn3209(y,d); y=graph_fn3210(y,d); y=graph_fn3211(y,d); y=graph_fn3212(y,d); y=graph_fn3213(y,d); y=graph_fn3214(y,d); y=graph_fn3215(y,d); y=graph_fn3216(y,d); y=graph_fn3217(y,d); y=graph_fn3218(y,d); y=graph_fn3219(y,d); y=graph_fn3220(y,d); y=graph_fn3221(y,d); y=graph_fn3222(y,d); y=graph_fn3223(y,d); y=graph_fn3224(y,d); y=graph_fn3225(y,d); y=graph_fn3226(y,d); y=graph_fn3227(y,d); y=graph_fn3228(y,d); y=graph_fn3229(y,d); y=graph_fn3230(y,d); y=graph_fn3231(y,d); y=graph_fn3232(y,d); y=graph_fn3233(y,d); y=graph_fn3234(y,d); y=graph_fn3235(y,d); y=graph_fn3236(y,d); y=graph_fn3237(y,d); y=graph_fn3238(y,d); y=graph_fn3239(y,d); y=graph_fn3240(y,d); y=graph_fn3241(y,d); y=graph_fn3242(y,d); y=graph_fn3243(y,d); y=graph_fn3244(y,d); y=graph_fn3245(y,d); y=graph_fn3246(y,d); y=graph_fn3247(y,d); y=graph_fn3248(y,d); y=graph_fn3249(y,d); y=graph_fn3250(y,d); y=graph_fn3251(y,d); y=graph_fn3252(y,d); y=graph_fn3253(y,d); y=graph_fn3254(y,d); y=graph_fn3255(y,d); y=graph_fn3256(y,d); y=graph_fn3257(y,d); y=graph_fn3258(y,d); y=graph_fn3259(y,d); y=graph_fn3260(y,d); y=graph_fn3261(y,d); y=graph_fn3262(y,d); y=graph_fn3263(y,d); y=graph_fn3264(y,d); y=graph_fn3265(y,d); y=graph_fn3266(y,d); y=graph_fn3267(y,d); y=graph_fn3268(y,d); y=graph_fn3269(y,d); y=graph_fn3270(y,d); y=graph_fn3271(y,d); y=graph_fn3272(y,d); y=graph_fn3273(y,d); y=graph_fn3274(y,d); y=graph_fn3275(y,d); y=graph_fn3276(y,d); y=graph_fn3277(y,d); y=graph_fn3278(y,d); y=graph_fn3279(y,d); y=graph_fn3280(y,d); y=graph_fn3281(y,d); y=graph_fn3282(y,d); y=graph_fn3283(y,d); y=graph_fn3284(y,d); y=graph_fn3285(y,d); y=graph_fn3286(y,d); y=graph_fn3287(y,d); y=graph_fn3288(y,d); y=graph_fn3289(y,d); y=graph_fn3290(y,d); y=graph_fn3291(y,d); y=graph_fn3292(y,d); y=graph_fn3293(y,d); y=graph_fn3294(y,d); y=graph_fn3295(y,d); y=graph_fn3296(y,d); y=graph_fn3297(y,d); y=graph_fn3298(y,d); y=graph_fn3299(y,d); y=graph_fn3300(y,d); y=graph_fn3301(y,d); y=graph_fn3302(y,d); y=graph_fn3303(y,d); y=graph_fn3304(y,d); y=graph_fn3305(y,d); y=graph_fn3306(y,d); y=graph_fn3307(y,d); y=graph_fn3308(y,d); y=graph_fn3309(y,d); y=graph_fn3310(y,d); y=graph_fn3311(y,d); y=graph_fn3312(y,d); y=graph_fn3313(y,d); y=graph_fn3314(y,d); y=graph_fn3315(y,d); y=graph_fn3316(y,d); y=graph_fn3317(y,d); y=graph_fn3318(y,d); y=graph_fn3319(y,d); y=graph_fn3320(y,d); y=graph_fn3321(y,d); y=graph_fn3322(y,d); y=graph_fn3323(y,d); y=graph_fn3324(y,d); y=graph_fn3325(y,d); y=graph_fn3326(y,d); y=graph_fn3327(y,d); y=graph_fn3328(y,d); y=graph_fn3329(y,d); y=graph_fn3330(y,d); y=graph_fn3331(y,d); y=graph_fn3332(y,d); y=graph_fn3333(y,d); y=graph_fn3334(y,d); y=graph_fn3335(y,d); y=graph_fn3336(y,d); y=graph_fn3337(y,d); y=graph_fn3338(y,d); y=graph_fn3339(y,d); y=graph_fn3340(y,d); y=graph_fn3341(y,d); y=graph_fn3342(y,d); y=graph_fn3343(y,d); y=graph_fn3344(y,d); y=graph_fn3345(y,d); y=graph_fn3346(y,d); y=graph_fn3347(y,d); y=graph_fn3348(y,d); y=graph_fn3349(y,d); y=graph_fn3350(y,d); y=graph_fn3351(y,d); y=graph_fn3352(y,d); y=graph_fn3353(y,d); y=graph_fn3354(y,d); y=graph_fn3355(y,d); y=graph_fn3356(y,d); y=graph_fn3357(y,d); y=graph_fn3358(y,d); y=graph_fn3359(y,d); y=graph_fn3360(y,d); y=graph_fn3361(y,d); y=graph_fn3362(y,d); y=graph_fn3363(y,d); y=graph_fn3364(y,d); y=graph_fn3365(y,d); y=graph_fn3366(y,d); y=graph_fn3367(y,d); y=graph_fn3368(y,d); y=graph_fn3369(y,d); y=graph_fn3370(y,d); y=graph_fn3371(y,d); y=graph_fn3372(y,d); y=graph_fn3373(y,d); y=graph_fn3374(y,d); y=graph_fn3375(y,d); y=graph_fn3376(y,d); y=graph_fn3377(y,d); y=graph_fn3378(y,d); y=graph_fn3379(y,d); y=graph_fn3380(y,d); y=graph_fn3381(y,d); y=graph_fn3382(y,d); y=graph_fn3383(y,d); y=graph_fn3384(y,d); y=graph_fn3385(y,d); y=graph_fn3386(y,d); y=graph_fn3387(y,d); y=graph_fn3388(y,d); y=graph_fn3389(y,d); y=graph_fn3390(y,d); y=graph_fn3391(y,d); y=graph_fn3392(y,d); y=graph_fn3393(y,d); y=graph_fn3394(y,d); y=graph_fn3395(y,d); y=graph_fn3396(y,d); y=graph_fn3397(y,d); y=graph_fn3398(y,d); y=graph_fn3399(y,d); y=graph_fn3400(y,d); y=graph_fn3401(y,d); y=graph_fn3402(y,d); y=graph_fn3403(y,d); y=graph_fn3404(y,d); y=graph_fn3405(y,d); y=graph_fn3406(y,d); y=graph_fn3407(y,d); y=graph_fn3408(y,d); y=graph_fn3409(y,d); y=graph_fn3410(y,d); y=graph_fn3411(y,d); y=graph_fn3412(y,d); y=graph_fn3413(y,d); y=graph_fn3414(y,d); y=graph_fn3415(y,d); y=graph_fn3416(y,d); y=graph_fn3417(y,d); y=graph_fn3418(y,d); y=graph_fn3419(y,d); y=graph_fn3420(y,d); y=graph_fn3421(y,d); y=graph_fn3422(y,d); y=graph_fn3423(y,d); y=graph_fn3424(y,d); y=graph_fn3425(y,d); y=graph_fn3426(y,d); y=graph_fn3427(y,d); y=graph_fn3428(y,d); y=graph_fn3429(y,d); y=graph_fn3430(y,d); y=graph_fn3431(y,d); y=graph_fn3432(y,d); y=graph_fn3433(y,d); y=graph_fn3434(y,d); y=graph_fn3435(y,d); y=graph_fn3436(y,d); y=graph_fn3437(y,d); y=graph_fn3438(y,d); y=graph_fn3439(y,d); y=graph_fn3440(y,d); y=graph_fn3441(y,d); y=graph_fn3442(y,d); y=graph_fn3443(y,d); y=graph_fn3444(y,d); y=graph_fn3445(y,d); y=graph_fn3446(y,d); y=graph_fn3447(y,d); y=graph_fn3448(y,d); y=graph_fn3449(y,d); y=graph_fn3450(y,d); y=graph_fn3451(y,d); y=graph_fn3452(y,d); y=graph_fn3453(y,d); y=graph_fn3454(y,d); y=graph_fn3455(y,d); y=graph_fn3456(y,d); y=graph_fn3457(y,d); y=graph_fn3458(y,d); y=graph_fn3459(y,d); y=graph_fn3460(y,d); y=graph_fn3461(y,d); y=graph_fn3462(y,d); y=graph_fn3463(y,d); y=graph_fn3464(y,d); y=graph_fn3465(y,d); y=graph_fn3466(y,d); y=graph_fn3467(y,d); y=graph_fn3468(y,d); y=graph_fn3469(y,d); y=graph_fn3470(y,d); y=graph_fn3471(y,d); y=graph_fn3472(y,d); y=graph_fn3473(y,d); y=graph_fn3474(y,d); y=graph_fn3475(y,d); y=graph_fn3476(y,d); y=graph_fn3477(y,d); y=graph_fn3478(y,d); y=graph_fn3479(y,d); y=graph_fn3480(y,d); y=graph_fn3481(y,d); y=graph_fn3482(y,d); y=graph_fn3483(y,d); y=graph_fn3484(y,d); y=graph_fn3485(y,d); y=graph_fn3486(y,d); y=graph_fn3487(y,d); y=graph_fn3488(y,d); y=graph_fn3489(y,d); y=graph_fn3490(y,d); y=graph_fn3491(y,d); y=graph_fn3492(y,d); y=graph_fn3493(y,d); y=graph_fn3494(y,d); y=graph_fn3495(y,d); y=graph_fn3496(y,d); y=graph_fn3497(y,d); y=graph_fn3498(y,d); y=graph_fn3499(y,d); y=graph_fn3500(y,d); y=graph_fn3501(y,d); y=graph_fn3502(y,d); y=graph_fn3503(y,d); y=graph_fn3504(y,d); y=graph_fn3505(y,d); y=graph_fn3506(y,d); y=graph_fn3507(y,d); y=graph_fn3508(y,d); y=graph_fn3509(y,d); y=graph_fn3510(y,d); y=graph_fn3511(y,d); y=graph_fn3512(y,d); y=graph_fn3513(y,d); y=graph_fn3514(y,d); y=graph_fn3515(y,d); y=graph_fn3516(y,d); y=graph_fn3517(y,d); y=graph_fn3518(y,d); y=graph_fn3519(y,d); y=graph_fn3520(y,d); y=graph_fn3521(y,d); y=graph_fn3522(y,d); y=graph_fn3523(y,d); y=graph_fn3524(y,d); y=graph_fn3525(y,d); y=graph_fn3526(y,d); y=graph_fn3527(y,d); y=graph_fn3528(y,d); y=graph_fn3529(y,d); y=graph_fn3530(y,d); y=graph_fn3531(y,d); y=graph_fn3532(y,d); y=graph_fn3533(y,d); y=graph_fn3534(y,d); y=graph_fn3535(y,d); y=graph_fn3536(y,d); y=graph_fn3537(y,d); y=graph_fn3538(y,d); y=graph_fn3539(y,d); y=graph_fn3540(y,d); y=graph_fn3541(y,d); y=graph_fn3542(y,d); y=graph_fn3543(y,d); y=graph_fn3544(y,d); y=graph_fn3545(y,d); y=graph_fn3546(y,d); y=graph_fn3547(y,d); y=graph_fn3548(y,d); y=graph_fn3549(y,d); y=graph_fn3550(y,d); y=graph_fn3551(y,d); y=graph_fn3552(y,d); y=graph_fn3553(y,d); y=graph_fn3554(y,d); y=graph_fn3555(y,d); y=graph_fn3556(y,d); y=graph_fn3557(y,d); y=graph_fn3558(y,d); y=graph_fn3559(y,d); y=graph_fn3560(y,d); y=graph_fn3561(y,d); y=graph_fn3562(y,d); y=graph_fn3563(y,d); y=graph_fn3564(y,d); y=graph_fn3565(y,d); y=graph_fn3566(y,d); y=graph_fn3567(y,d); y=graph_fn3568(y,d); y=graph_fn3569(y,d); y=graph_fn3570(y,d); y=graph_fn3571(y,d); y=graph_fn3572(y,d); y=graph_fn3573(y,d); y=graph_fn3574(y,d); y=graph_fn3575(y,d); y=graph_fn3576(y,d); y=graph_fn3577(y,d); y=graph_fn3578(y,d); y=graph_fn3579(y,d); y=graph_fn3580(y,d); y=graph_fn3581(y,d); y=graph_fn3582(y,d); y=graph_fn3583(y,d); y=graph_fn3584(y,d); y=graph_fn3585(y,d); y=graph_fn3586(y,d); y=graph_fn3587(y,d); y=graph_fn3588(y,d); y=graph_fn3589(y,d); y=graph_fn3590(y,d); y=graph_fn3591(y,d); y=graph_fn3592(y,d); y=graph_fn3593(y,d); y=graph_fn3594(y,d); y=graph_fn3595(y,d); y=graph_fn3596(y,d); y=graph_fn3597(y,d); y=graph_fn3598(y,d); y=graph_fn3599(y,d); y=graph_fn3600(y,d); y=graph_fn3601(y,d); y=graph_fn3602(y,d); y=graph_fn3603(y,d); y=graph_fn3604(y,d); y=graph_fn3605(y,d); y=graph_fn3606(y,d); y=graph_fn3607(y,d); y=graph_fn3608(y,d); y=graph_fn3609(y,d); y=graph_fn3610(y,d); y=graph_fn3611(y,d); y=graph_fn3612(y,d); y=graph_fn3613(y,d); y=graph_fn3614(y,d); y=graph_fn3615(y,d); y=graph_fn3616(y,d); y=graph_fn3617(y,d); y=graph_fn3618(y,d); y=graph_fn3619(y,d); y=graph_fn3620(y,d); y=graph_fn3621(y,d); y=graph_fn3622(y,d); y=graph_fn3623(y,d); y=graph_fn3624(y,d); y=graph_fn3625(y,d); y=graph_fn3626(y,d); y=graph_fn3627(y,d); y=graph_fn3628(y,d); y=graph_fn3629(y,d); y=graph_fn3630(y,d); y=graph_fn3631(y,d); y=graph_fn3632(y,d); y=graph_fn3633(y,d); y=graph_fn3634(y,d); y=graph_fn3635(y,d); y=graph_fn3636(y,d); y=graph_fn3637(y,d); y=graph_fn3638(y,d); y=graph_fn3639(y,d); y=graph_fn3640(y,d); y=graph_fn3641(y,d); y=graph_fn3642(y,d); y=graph_fn3643(y,d); y=graph_fn3644(y,d); y=graph_fn3645(y,d); y=graph_fn3646(y,d); y=graph_fn3647(y,d); y=graph_fn3648(y,d); y=graph_fn3649(y,d); y=graph_fn3650(y,d); y=graph_fn3651(y,d); y=graph_fn3652(y,d); y=graph_fn3653(y,d); y=graph_fn3654(y,d); y=graph_fn3655(y,d); y=graph_fn3656(y,d); y=graph_fn3657(y,d); y=graph_fn3658(y,d); y=graph_fn3659(y,d); y=graph_fn3660(y,d); y=graph_fn3661(y,d); y=graph_fn3662(y,d); y=graph_fn3663(y,d); y=graph_fn3664(y,d); y=graph_fn3665(y,d); y=graph_fn3666(y,d); y=graph_fn3667(y,d); y=graph_fn3668(y,d); y=graph_fn3669(y,d); y=graph_fn3670(y,d); y=graph_fn3671(y,d); y=graph_fn3672(y,d); y=graph_fn3673(y,d); y=graph_fn3674(y,d); y=graph_fn3675(y,d); y=graph_fn3676(y,d); y=graph_fn3677(y,d); y=graph_fn3678(y,d); y=graph_fn3679(y,d); y=graph_fn3680(y,d); y=graph_fn3681(y,d); y=graph_fn3682(y,d); y=graph_fn3683(y,d); y=graph_fn3684(y,d); y=graph_fn3685(y,d); y=graph_fn3686(y,d); y=graph_fn3687(y,d); y=graph_fn3688(y,d); y=graph_fn3689(y,d); y=graph_fn3690(y,d); y=graph_fn3691(y,d); y=graph_fn3692(y,d); y=graph_fn3693(y,d); y=graph_fn3694(y,d); y=graph_fn3695(y,d); y=graph_fn3696(y,d); y=graph_fn3697(y,d); y=graph_fn3698(y,d); y=graph_fn3699(y,d); y=graph_fn3700(y,d); y=graph_fn3701(y,d); y=graph_fn3702(y,d); y=graph_fn3703(y,d); y=graph_fn3704(y,d); y=graph_fn3705(y,d); y=graph_fn3706(y,d); y=graph_fn3707(y,d); y=graph_fn3708(y,d); y=graph_fn3709(y,d); y=graph_fn3710(y,d); y=graph_fn3711(y,d); y=graph_fn3712(y,d); y=graph_fn3713(y,d); y=graph_fn3714(y,d); y=graph_fn3715(y,d); y=graph_fn3716(y,d); y=graph_fn3717(y,d); y=graph_fn3718(y,d); y=graph_fn3719(y,d); y=graph_fn3720(y,d); y=graph_fn3721(y,d); y=graph_fn3722(y,d); y=graph_fn3723(y,d); y=graph_fn3724(y,d); y=graph_fn3725(y,d); y=graph_fn3726(y,d); y=graph_fn3727(y,d); y=graph_fn3728(y,d); y=graph_fn3729(y,d); y=graph_fn3730(y,d); y=graph_fn3731(y,d); y=graph_fn3732(y,d); y=graph_fn3733(y,d); y=graph_fn3734(y,d); y=graph_fn3735(y,d); y=graph_fn3736(y,d); y=graph_fn3737(y,d); y=graph_fn3738(y,d); y=graph_fn3739(y,d); y=graph_fn3740(y,d); y=graph_fn3741(y,d); y=graph_fn3742(y,d); y=graph_fn3743(y,d); y=graph_fn3744(y,d); y=graph_fn3745(y,d); y=graph_fn3746(y,d); y=graph_fn3747(y,d); y=graph_fn3748(y,d); y=graph_fn3749(y,d); y=graph_fn3750(y,d); y=graph_fn3751(y,d); y=graph_fn3752(y,d); y=graph_fn3753(y,d); y=graph_fn3754(y,d); y=graph_fn3755(y,d); y=graph_fn3756(y,d); y=graph_fn3757(y,d); y=graph_fn3758(y,d); y=graph_fn3759(y,d); y=graph_fn3760(y,d); y=graph_fn3761(y,d); y=graph_fn3762(y,d); y=graph_fn3763(y,d); y=graph_fn3764(y,d); y=graph_fn3765(y,d); y=graph_fn3766(y,d); y=graph_fn3767(y,d); y=graph_fn3768(y,d); y=graph_fn3769(y,d); y=graph_fn3770(y,d); y=graph_fn3771(y,d); y=graph_fn3772(y,d); y=graph_fn3773(y,d); y=graph_fn3774(y,d); y=graph_fn3775(y,d); y=graph_fn3776(y,d); y=graph_fn3777(y,d); y=graph_fn3778(y,d); y=graph_fn3779(y,d); y=graph_fn3780(y,d); y=graph_fn3781(y,d); y=graph_fn3782(y,d); y=graph_fn3783(y,d); y=graph_fn3784(y,d); y=graph_fn3785(y,d); y=graph_fn3786(y,d); y=graph_fn3787(y,d); y=graph_fn3788(y,d); y=graph_fn3789(y,d); y=graph_fn3790(y,d); y=graph_fn3791(y,d); y=graph_fn3792(y,d); y=graph_fn3793(y,d); y=graph_fn3794(y,d); y=graph_fn3795(y,d); y=graph_fn3796(y,d); y=graph_fn3797(y,d); y=graph_fn3798(y,d); y=graph_fn3799(y,d); y=graph_fn3800(y,d); y=graph_fn3801(y,d); y=graph_fn3802(y,d); y=graph_fn3803(y,d); y=graph_fn3804(y,d); y=graph_fn3805(y,d); y=graph_fn3806(y,d); y=graph_fn3807(y,d); y=graph_fn3808(y,d); y=graph_fn3809(y,d); y=graph_fn3810(y,d); y=graph_fn3811(y,d); y=graph_fn3812(y,d); y=graph_fn3813(y,d); y=graph_fn3814(y,d); y=graph_fn3815(y,d); y=graph_fn3816(y,d); y=graph_fn3817(y,d); y=graph_fn3818(y,d); y=graph_fn3819(y,d); y=graph_fn3820(y,d); y=graph_fn3821(y,d); y=graph_fn3822(y,d); y=graph_fn3823(y,d); y=graph_fn3824(y,d); y=graph_fn3825(y,d); y=graph_fn3826(y,d); y=graph_fn3827(y,d); y=graph_fn3828(y,d); y=graph_fn3829(y,d); y=graph_fn3830(y,d); y=graph_fn3831(y,d); y=graph_fn3832(y,d); y=graph_fn3833(y,d); y=graph_fn3834(y,d); y=graph_fn3835(y,d); y=graph_fn3836(y,d); y=graph_fn3837(y,d); y=graph_fn3838(y,d); y=graph_fn3839(y,d); y=graph_fn3840(y,d); y=graph_fn3841(y,d); y=graph_fn3842(y,d); y=graph_fn3843(y,d); y=graph_fn3844(y,d); y=graph_fn3845(y,d); y=graph_fn3846(y,d); y=graph_fn3847(y,d); y=graph_fn3848(y,d); y=graph_fn3849(y,d); y=graph_fn3850(y,d); y=graph_fn3851(y,d); y=graph_fn3852(y,d); y=graph_fn3853(y,d); y=graph_fn3854(y,d); y=graph_fn3855(y,d); y=graph_fn3856(y,d); y=graph_fn3857(y,d); y=graph_fn3858(y,d); y=graph_fn3859(y,d); y=graph_fn3860(y,d); y=graph_fn3861(y,d); y=graph_fn3862(y,d); y=graph_fn3863(y,d); y=graph_fn3864(y,d); y=graph_fn3865(y,d); y=graph_fn3866(y,d); y=graph_fn3867(y,d); y=graph_fn3868(y,d); y=graph_fn3869(y,d); y=graph_fn3870(y,d); y=graph_fn3871(y,d); y=graph_fn3872(y,d); y=graph_fn3873(y,d); y=graph_fn3874(y,d); y=graph_fn3875(y,d); y=graph_fn3876(y,d); y=graph_fn3877(y,d); y=graph_fn3878(y,d); y=graph_fn3879(y,d); y=graph_fn3880(y,d); y=graph_fn3881(y,d); y=graph_fn3882(y,d); y=graph_fn3883(y,d); y=graph_fn3884(y,d); y=graph_fn3885(y,d); y=graph_fn3886(y,d); y=graph_fn3887(y,d); y=graph_fn3888(y,d); y=graph_fn3889(y,d); y=graph_fn3890(y,d); y=graph_fn3891(y,d); y=graph_fn3892(y,d); y=graph_fn3893(y,d); y=graph_fn3894(y,d); y=graph_fn3895(y,d); y=graph_fn3896(y,d); y=graph_fn3897(y,d); y=graph_fn3898(y,d); y=graph_fn3899(y,d); y=graph_fn3900(y,d); y=graph_fn3901(y,d); y=graph_fn3902(y,d); y=graph_fn3903(y,d); y=graph_fn3904(y,d); y=graph_fn3905(y,d); y=graph_fn3906(y,d); y=graph_fn3907(y,d); y=graph_fn3908(y,d); y=graph_fn3909(y,d); y=graph_fn3910(y,d); y=graph_fn3911(y,d); y=graph_fn3912(y,d); y=graph_fn3913(y,d); y=graph_fn3914(y,d); y=graph_fn3915(y,d); y=graph_fn3916(y,d); y=graph_fn3917(y,d); y=graph_fn3918(y,d); y=graph_fn3919(y,d); y=graph_fn3920(y,d); y=graph_fn3921(y,d); y=graph_fn3922(y,d); y=graph_fn3923(y,d); y=graph_fn3924(y,d); y=graph_fn3925(y,d); y=graph_fn3926(y,d); y=graph_fn3927(y,d); y=graph_fn3928(y,d); y=graph_fn3929(y,d); y=graph_fn3930(y,d); y=graph_fn3931(y,d); y=graph_fn3932(y,d); y=graph_fn3933(y,d); y=graph_fn3934(y,d); y=graph_fn3935(y,d); y=graph_fn3936(y,d); y=graph_fn3937(y,d); y=graph_fn3938(y,d); y=graph_fn3939(y,d); y=graph_fn3940(y,d); y=graph_fn3941(y,d); y=graph_fn3942(y,d); y=graph_fn3943(y,d); y=graph_fn3944(y,d); y=graph_fn3945(y,d); y=graph_fn3946(y,d); y=graph_fn3947(y,d); y=graph_fn3948(y,d); y=graph_fn3949(y,d); y=graph_fn3950(y,d); y=graph_fn3951(y,d); y=graph_fn3952(y,d); y=graph_fn3953(y,d); y=graph_fn3954(y,d); y=graph_fn3955(y,d); y=graph_fn3956(y,d); y=graph_fn3957(y,d); y=graph_fn3958(y,d); y=graph_fn3959(y,d); y=graph_fn3960(y,d); y=graph_fn3961(y,d); y=graph_fn3962(y,d); y=graph_fn3963(y,d); y=graph_fn3964(y,d); y=graph_fn3965(y,d); y=graph_fn3966(y,d); y=graph_fn3967(y,d); y=graph_fn3968(y,d); y=graph_fn3969(y,d); y=graph_fn3970(y,d); y=graph_fn3971(y,d); y=graph_fn3972(y,d); y=graph_fn3973(y,d); y=graph_fn3974(y,d); y=graph_fn3975(y,d); y=graph_fn3976(y,d); y=graph_fn3977(y,d); y=graph_fn3978(y,d); y=graph_fn3979(y,d); y=graph_fn3980(y,d); y=graph_fn3981(y,d); y=graph_fn3982(y,d); y=graph_fn3983(y,d); y=graph_fn3984(y,d); y=graph_fn3985(y,d); y=graph_fn3986(y,d); y=graph_fn3987(y,d); y=graph_fn3988(y,d); y=graph_fn3989(y,d); y=graph_fn3990(y,d); y=graph_fn3991(y,d); y=graph_fn3992(y,d); y=graph_fn3993(y,d); y=graph_fn3994(y,d); y=graph_fn3995(y,d); y=graph_fn3996(y,d); y=graph_fn3997(y,d); y=graph_fn3998(y,d); y=graph_fn3999(y,d); y=graph_fn4000(y,d); y=graph_fn4001(y,d); y=graph_fn4002(y,d); y=graph_fn4003(y,d); y=graph_fn4004(y,d); y=graph_fn4005(y,d); y=graph_fn4006(y,d); y=graph_fn4007(y,d); y=graph_fn4008(y,d); y=graph_fn4009(y,d); y=graph_fn4010(y,d); y=graph_fn4011(y,d); y=graph_fn4012(y,d); y=graph_fn4013(y,d); y=graph_fn4014(y,d); y=graph_fn4015(y,d); y=graph_fn4016(y,d); y=graph_fn4017(y,d); y=graph_fn4018(y,d); y=graph_fn4019(y,d); y=graph_fn4020(y,d); y=graph_fn4021(y,d); y=graph_fn4022(y,d); y=graph_fn4023(y,d); y=graph_fn4024(y,d); y=graph_fn4025(y,d); y=graph_fn4026(y,d); y=graph_fn4027(y,d); y=graph_fn4028(y,d); y=graph_fn4029(y,d); y=graph_fn4030(y,d); y=graph_fn4031(y,d); y=graph_fn4032(y,d); y=graph_fn4033(y,d); y=graph_fn4034(y,d); y=graph_fn4035(y,d); y=graph_fn4036(y,d); y=graph_fn4037(y,d); y=graph_fn4038(y,d); y=graph_fn4039(y,d); y=graph_fn4040(y,d); y=graph_fn4041(y,d); y=graph_fn4042(y,d); y=graph_fn4043(y,d); y=graph_fn4044(y,d); y=graph_fn4045(y,d); y=graph_fn4046(y,d); y=graph_fn4047(y,d); y=graph_fn4048(y,d); y=graph_fn4049(y,d); y=graph_fn4050(y,d); y=graph_fn4051(y,d); y=graph_fn4052(y,d); y=graph_fn4053(y,d); y=graph_fn4054(y,d); y=graph_fn4055(y,d); y=graph_fn4056(y,d); y=graph_fn4057(y,d); y=graph_fn4058(y,d); y=graph_fn4059(y,d); y=graph_fn4060(y,d); y=graph_fn4061(y,d); y=graph_fn4062(y,d); y=graph_fn4063(y,d); y=graph_fn4064(y,d); y=graph_fn4065(y,d); y=graph_fn4066(y,d); y=graph_fn4067(y,d); y=graph_fn4068(y,d); y=graph_fn4069(y,d); y=graph_fn4070(y,d); y=graph_fn4071(y,d); y=graph_fn4072(y,d); y=graph_fn4073(y,d); y=graph_fn4074(y,d); y=graph_fn4075(y,d); y=graph_fn4076(y,d); y=graph_fn4077(y,d); y=graph_fn4078(y,d); y=graph_fn4079(y,d); y=graph_fn4080(y,d); y=graph_fn4081(y,d); y=graph_fn4082(y,d); y=graph_fn4083(y,d); y=graph_fn4084(y,d); y=graph_fn4085(y,d); y=graph_fn4086(y,d); y=graph_fn4087(y,d); y=graph_fn4088(y,d); y=graph_fn4089(y,d); y=graph_fn4090(y,d); y=graph_fn4091(y,d); y=graph_fn4092(y,d); y=graph_fn4093(y,d); y=graph_fn4094(y,d); y=graph_fn4095(y,d); return y; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12+1) as i32)+i)%65521; i+=1; }
    write(acc);
}
