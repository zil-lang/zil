trait Eval { fn eval(self:&Self,x:i64)->i64; }
fn apply<T:Eval>(v:&T,x:i64)->i64 {return v.eval(x);}
struct K0 { bias:i64 }
impl Eval for K0 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+5)%65521;} }
struct K1 { bias:i64 }
impl Eval for K1 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+2)%65521;} }
struct K2 { bias:i64 }
impl Eval for K2 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+3)%65521;} }
struct K3 { bias:i64 }
impl Eval for K3 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+4)%65521;} }
struct K4 { bias:i64 }
impl Eval for K4 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+5)%65521;} }
struct K5 { bias:i64 }
impl Eval for K5 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+6)%65521;} }
struct K6 { bias:i64 }
impl Eval for K6 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+7)%65521;} }
struct K7 { bias:i64 }
impl Eval for K7 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+8)%65521;} }
struct K8 { bias:i64 }
impl Eval for K8 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+9)%65521;} }
struct K9 { bias:i64 }
impl Eval for K9 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+10)%65521;} }
struct K10 { bias:i64 }
impl Eval for K10 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+11)%65521;} }
struct K11 { bias:i64 }
impl Eval for K11 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+12)%65521;} }
struct K12 { bias:i64 }
impl Eval for K12 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+13)%65521;} }
struct K13 { bias:i64 }
impl Eval for K13 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+14)%65521;} }
struct K14 { bias:i64 }
impl Eval for K14 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+15)%65521;} }
struct K15 { bias:i64 }
impl Eval for K15 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+16)%65521;} }
struct K16 { bias:i64 }
impl Eval for K16 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+17)%65521;} }
struct K17 { bias:i64 }
impl Eval for K17 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+18)%65521;} }
struct K18 { bias:i64 }
impl Eval for K18 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+19)%65521;} }
struct K19 { bias:i64 }
impl Eval for K19 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+20)%65521;} }
struct K20 { bias:i64 }
impl Eval for K20 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+21)%65521;} }
struct K21 { bias:i64 }
impl Eval for K21 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+22)%65521;} }
struct K22 { bias:i64 }
impl Eval for K22 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+23)%65521;} }
struct K23 { bias:i64 }
impl Eval for K23 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+24)%65521;} }
struct K24 { bias:i64 }
impl Eval for K24 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+25)%65521;} }
struct K25 { bias:i64 }
impl Eval for K25 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+26)%65521;} }
struct K26 { bias:i64 }
impl Eval for K26 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+27)%65521;} }
struct K27 { bias:i64 }
impl Eval for K27 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+28)%65521;} }
struct K28 { bias:i64 }
impl Eval for K28 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+29)%65521;} }
struct K29 { bias:i64 }
impl Eval for K29 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+30)%65521;} }
struct K30 { bias:i64 }
impl Eval for K30 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+31)%65521;} }
struct K31 { bias:i64 }
impl Eval for K31 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+32)%65521;} }
struct K32 { bias:i64 }
impl Eval for K32 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+33)%65521;} }
struct K33 { bias:i64 }
impl Eval for K33 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+34)%65521;} }
struct K34 { bias:i64 }
impl Eval for K34 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+35)%65521;} }
struct K35 { bias:i64 }
impl Eval for K35 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+36)%65521;} }
struct K36 { bias:i64 }
impl Eval for K36 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+37)%65521;} }
struct K37 { bias:i64 }
impl Eval for K37 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+38)%65521;} }
struct K38 { bias:i64 }
impl Eval for K38 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+39)%65521;} }
struct K39 { bias:i64 }
impl Eval for K39 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+40)%65521;} }
struct K40 { bias:i64 }
impl Eval for K40 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+41)%65521;} }
struct K41 { bias:i64 }
impl Eval for K41 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+42)%65521;} }
struct K42 { bias:i64 }
impl Eval for K42 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+43)%65521;} }
struct K43 { bias:i64 }
impl Eval for K43 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+44)%65521;} }
struct K44 { bias:i64 }
impl Eval for K44 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+45)%65521;} }
struct K45 { bias:i64 }
impl Eval for K45 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+46)%65521;} }
struct K46 { bias:i64 }
impl Eval for K46 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+47)%65521;} }
struct K47 { bias:i64 }
impl Eval for K47 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+48)%65521;} }
struct K48 { bias:i64 }
impl Eval for K48 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+49)%65521;} }
struct K49 { bias:i64 }
impl Eval for K49 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+50)%65521;} }
struct K50 { bias:i64 }
impl Eval for K50 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+51)%65521;} }
struct K51 { bias:i64 }
impl Eval for K51 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+52)%65521;} }
struct K52 { bias:i64 }
impl Eval for K52 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+53)%65521;} }
struct K53 { bias:i64 }
impl Eval for K53 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+54)%65521;} }
struct K54 { bias:i64 }
impl Eval for K54 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+55)%65521;} }
struct K55 { bias:i64 }
impl Eval for K55 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+56)%65521;} }
struct K56 { bias:i64 }
impl Eval for K56 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+57)%65521;} }
struct K57 { bias:i64 }
impl Eval for K57 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+58)%65521;} }
struct K58 { bias:i64 }
impl Eval for K58 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+59)%65521;} }
struct K59 { bias:i64 }
impl Eval for K59 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+60)%65521;} }
struct K60 { bias:i64 }
impl Eval for K60 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+61)%65521;} }
struct K61 { bias:i64 }
impl Eval for K61 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+62)%65521;} }
struct K62 { bias:i64 }
impl Eval for K62 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+63)%65521;} }
struct K63 { bias:i64 }
impl Eval for K63 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+64)%65521;} }
struct K64 { bias:i64 }
impl Eval for K64 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+65)%65521;} }
struct K65 { bias:i64 }
impl Eval for K65 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+66)%65521;} }
struct K66 { bias:i64 }
impl Eval for K66 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+67)%65521;} }
struct K67 { bias:i64 }
impl Eval for K67 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+68)%65521;} }
struct K68 { bias:i64 }
impl Eval for K68 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+69)%65521;} }
struct K69 { bias:i64 }
impl Eval for K69 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+70)%65521;} }
struct K70 { bias:i64 }
impl Eval for K70 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+71)%65521;} }
struct K71 { bias:i64 }
impl Eval for K71 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+72)%65521;} }
struct K72 { bias:i64 }
impl Eval for K72 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+73)%65521;} }
struct K73 { bias:i64 }
impl Eval for K73 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+74)%65521;} }
struct K74 { bias:i64 }
impl Eval for K74 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+75)%65521;} }
struct K75 { bias:i64 }
impl Eval for K75 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+76)%65521;} }
struct K76 { bias:i64 }
impl Eval for K76 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+77)%65521;} }
struct K77 { bias:i64 }
impl Eval for K77 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+78)%65521;} }
struct K78 { bias:i64 }
impl Eval for K78 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+79)%65521;} }
struct K79 { bias:i64 }
impl Eval for K79 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+80)%65521;} }
struct K80 { bias:i64 }
impl Eval for K80 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+81)%65521;} }
struct K81 { bias:i64 }
impl Eval for K81 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+82)%65521;} }
struct K82 { bias:i64 }
impl Eval for K82 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+83)%65521;} }
struct K83 { bias:i64 }
impl Eval for K83 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+84)%65521;} }
struct K84 { bias:i64 }
impl Eval for K84 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+85)%65521;} }
struct K85 { bias:i64 }
impl Eval for K85 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+86)%65521;} }
struct K86 { bias:i64 }
impl Eval for K86 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+87)%65521;} }
struct K87 { bias:i64 }
impl Eval for K87 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+88)%65521;} }
struct K88 { bias:i64 }
impl Eval for K88 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+89)%65521;} }
struct K89 { bias:i64 }
impl Eval for K89 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+90)%65521;} }
struct K90 { bias:i64 }
impl Eval for K90 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+91)%65521;} }
struct K91 { bias:i64 }
impl Eval for K91 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+92)%65521;} }
struct K92 { bias:i64 }
impl Eval for K92 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+93)%65521;} }
struct K93 { bias:i64 }
impl Eval for K93 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+94)%65521;} }
struct K94 { bias:i64 }
impl Eval for K94 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+95)%65521;} }
struct K95 { bias:i64 }
impl Eval for K95 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+96)%65521;} }
struct K96 { bias:i64 }
impl Eval for K96 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+97)%65521;} }
struct K97 { bias:i64 }
impl Eval for K97 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+98)%65521;} }
struct K98 { bias:i64 }
impl Eval for K98 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+99)%65521;} }
struct K99 { bias:i64 }
impl Eval for K99 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+100)%65521;} }
struct K100 { bias:i64 }
impl Eval for K100 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+101)%65521;} }
struct K101 { bias:i64 }
impl Eval for K101 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+102)%65521;} }
struct K102 { bias:i64 }
impl Eval for K102 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+103)%65521;} }
struct K103 { bias:i64 }
impl Eval for K103 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+104)%65521;} }
struct K104 { bias:i64 }
impl Eval for K104 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+105)%65521;} }
struct K105 { bias:i64 }
impl Eval for K105 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+106)%65521;} }
struct K106 { bias:i64 }
impl Eval for K106 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+107)%65521;} }
struct K107 { bias:i64 }
impl Eval for K107 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+108)%65521;} }
struct K108 { bias:i64 }
impl Eval for K108 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+109)%65521;} }
struct K109 { bias:i64 }
impl Eval for K109 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+110)%65521;} }
struct K110 { bias:i64 }
impl Eval for K110 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+111)%65521;} }
struct K111 { bias:i64 }
impl Eval for K111 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+112)%65521;} }
struct K112 { bias:i64 }
impl Eval for K112 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+113)%65521;} }
struct K113 { bias:i64 }
impl Eval for K113 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+114)%65521;} }
struct K114 { bias:i64 }
impl Eval for K114 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+115)%65521;} }
struct K115 { bias:i64 }
impl Eval for K115 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+116)%65521;} }
struct K116 { bias:i64 }
impl Eval for K116 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+117)%65521;} }
struct K117 { bias:i64 }
impl Eval for K117 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+118)%65521;} }
struct K118 { bias:i64 }
impl Eval for K118 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+119)%65521;} }
struct K119 { bias:i64 }
impl Eval for K119 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+120)%65521;} }
struct K120 { bias:i64 }
impl Eval for K120 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+121)%65521;} }
struct K121 { bias:i64 }
impl Eval for K121 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+122)%65521;} }
struct K122 { bias:i64 }
impl Eval for K122 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+123)%65521;} }
struct K123 { bias:i64 }
impl Eval for K123 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+124)%65521;} }
struct K124 { bias:i64 }
impl Eval for K124 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+125)%65521;} }
struct K125 { bias:i64 }
impl Eval for K125 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+126)%65521;} }
struct K126 { bias:i64 }
impl Eval for K126 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+127)%65521;} }
struct K127 { bias:i64 }
impl Eval for K127 { fn eval(self:&Self,x:i64)->i64 {return (x*x+self.bias+128)%65521;} }
fn run(x:i64,d:i32)->i64 { var y=x; let v0=K0{bias:1}; y=apply(&v0,y); let v1=K1{bias:2}; y=apply(&v1,y); let v2=K2{bias:3}; y=apply(&v2,y); let v3=K3{bias:4}; y=apply(&v3,y); let v4=K4{bias:5}; y=apply(&v4,y); let v5=K5{bias:6}; y=apply(&v5,y); let v6=K6{bias:7}; y=apply(&v6,y); let v7=K7{bias:8}; y=apply(&v7,y); let v8=K8{bias:9}; y=apply(&v8,y); let v9=K9{bias:10}; y=apply(&v9,y); let v10=K10{bias:11}; y=apply(&v10,y); let v11=K11{bias:12}; y=apply(&v11,y); let v12=K12{bias:13}; y=apply(&v12,y); let v13=K13{bias:14}; y=apply(&v13,y); let v14=K14{bias:15}; y=apply(&v14,y); let v15=K15{bias:16}; y=apply(&v15,y); let v16=K16{bias:17}; y=apply(&v16,y); let v17=K17{bias:18}; y=apply(&v17,y); let v18=K18{bias:19}; y=apply(&v18,y); let v19=K19{bias:20}; y=apply(&v19,y); let v20=K20{bias:21}; y=apply(&v20,y); let v21=K21{bias:22}; y=apply(&v21,y); let v22=K22{bias:23}; y=apply(&v22,y); let v23=K23{bias:24}; y=apply(&v23,y); let v24=K24{bias:25}; y=apply(&v24,y); let v25=K25{bias:26}; y=apply(&v25,y); let v26=K26{bias:27}; y=apply(&v26,y); let v27=K27{bias:28}; y=apply(&v27,y); let v28=K28{bias:29}; y=apply(&v28,y); let v29=K29{bias:30}; y=apply(&v29,y); let v30=K30{bias:31}; y=apply(&v30,y); let v31=K31{bias:32}; y=apply(&v31,y); let v32=K32{bias:33}; y=apply(&v32,y); let v33=K33{bias:34}; y=apply(&v33,y); let v34=K34{bias:35}; y=apply(&v34,y); let v35=K35{bias:36}; y=apply(&v35,y); let v36=K36{bias:37}; y=apply(&v36,y); let v37=K37{bias:38}; y=apply(&v37,y); let v38=K38{bias:39}; y=apply(&v38,y); let v39=K39{bias:40}; y=apply(&v39,y); let v40=K40{bias:41}; y=apply(&v40,y); let v41=K41{bias:42}; y=apply(&v41,y); let v42=K42{bias:43}; y=apply(&v42,y); let v43=K43{bias:44}; y=apply(&v43,y); let v44=K44{bias:45}; y=apply(&v44,y); let v45=K45{bias:46}; y=apply(&v45,y); let v46=K46{bias:47}; y=apply(&v46,y); let v47=K47{bias:48}; y=apply(&v47,y); let v48=K48{bias:49}; y=apply(&v48,y); let v49=K49{bias:50}; y=apply(&v49,y); let v50=K50{bias:51}; y=apply(&v50,y); let v51=K51{bias:52}; y=apply(&v51,y); let v52=K52{bias:53}; y=apply(&v52,y); let v53=K53{bias:54}; y=apply(&v53,y); let v54=K54{bias:55}; y=apply(&v54,y); let v55=K55{bias:56}; y=apply(&v55,y); let v56=K56{bias:57}; y=apply(&v56,y); let v57=K57{bias:58}; y=apply(&v57,y); let v58=K58{bias:59}; y=apply(&v58,y); let v59=K59{bias:60}; y=apply(&v59,y); let v60=K60{bias:61}; y=apply(&v60,y); let v61=K61{bias:62}; y=apply(&v61,y); let v62=K62{bias:63}; y=apply(&v62,y); let v63=K63{bias:64}; y=apply(&v63,y); let v64=K64{bias:65}; y=apply(&v64,y); let v65=K65{bias:66}; y=apply(&v65,y); let v66=K66{bias:67}; y=apply(&v66,y); let v67=K67{bias:68}; y=apply(&v67,y); let v68=K68{bias:69}; y=apply(&v68,y); let v69=K69{bias:70}; y=apply(&v69,y); let v70=K70{bias:71}; y=apply(&v70,y); let v71=K71{bias:72}; y=apply(&v71,y); let v72=K72{bias:73}; y=apply(&v72,y); let v73=K73{bias:74}; y=apply(&v73,y); let v74=K74{bias:75}; y=apply(&v74,y); let v75=K75{bias:76}; y=apply(&v75,y); let v76=K76{bias:77}; y=apply(&v76,y); let v77=K77{bias:78}; y=apply(&v77,y); let v78=K78{bias:79}; y=apply(&v78,y); let v79=K79{bias:80}; y=apply(&v79,y); let v80=K80{bias:81}; y=apply(&v80,y); let v81=K81{bias:82}; y=apply(&v81,y); let v82=K82{bias:83}; y=apply(&v82,y); let v83=K83{bias:84}; y=apply(&v83,y); let v84=K84{bias:85}; y=apply(&v84,y); let v85=K85{bias:86}; y=apply(&v85,y); let v86=K86{bias:87}; y=apply(&v86,y); let v87=K87{bias:88}; y=apply(&v87,y); let v88=K88{bias:89}; y=apply(&v88,y); let v89=K89{bias:90}; y=apply(&v89,y); let v90=K90{bias:91}; y=apply(&v90,y); let v91=K91{bias:92}; y=apply(&v91,y); let v92=K92{bias:93}; y=apply(&v92,y); let v93=K93{bias:94}; y=apply(&v93,y); let v94=K94{bias:95}; y=apply(&v94,y); let v95=K95{bias:96}; y=apply(&v95,y); let v96=K96{bias:97}; y=apply(&v96,y); let v97=K97{bias:98}; y=apply(&v97,y); let v98=K98{bias:99}; y=apply(&v98,y); let v99=K99{bias:100}; y=apply(&v99,y); let v100=K100{bias:101}; y=apply(&v100,y); let v101=K101{bias:102}; y=apply(&v101,y); let v102=K102{bias:103}; y=apply(&v102,y); let v103=K103{bias:104}; y=apply(&v103,y); let v104=K104{bias:105}; y=apply(&v104,y); let v105=K105{bias:106}; y=apply(&v105,y); let v106=K106{bias:107}; y=apply(&v106,y); let v107=K107{bias:108}; y=apply(&v107,y); let v108=K108{bias:109}; y=apply(&v108,y); let v109=K109{bias:110}; y=apply(&v109,y); let v110=K110{bias:111}; y=apply(&v110,y); let v111=K111{bias:112}; y=apply(&v111,y); let v112=K112{bias:113}; y=apply(&v112,y); let v113=K113{bias:114}; y=apply(&v113,y); let v114=K114{bias:115}; y=apply(&v114,y); let v115=K115{bias:116}; y=apply(&v115,y); let v116=K116{bias:117}; y=apply(&v116,y); let v117=K117{bias:118}; y=apply(&v117,y); let v118=K118{bias:119}; y=apply(&v118,y); let v119=K119{bias:120}; y=apply(&v119,y); let v120=K120{bias:121}; y=apply(&v120,y); let v121=K121{bias:122}; y=apply(&v121,y); let v122=K122{bias:123}; y=apply(&v122,y); let v123=K123{bias:124}; y=apply(&v123,y); let v124=K124{bias:125}; y=apply(&v124,y); let v125=K125{bias:126}; y=apply(&v125,y); let v126=K126{bias:127}; y=apply(&v126,y); let v127=K127{bias:128}; y=apply(&v127,y); return (y+i64(d))%65521; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12+1))+i)%65521; i+=1; }
    write(acc); return 0;
}
