fn make0()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+1)%251}
}
fn make1()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+2)%251}
}
fn make2()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+3)%251}
}
fn make3()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+4)%251}
}
fn make4()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+5)%251}
}
fn make5()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+6)%251}
}
fn make6()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+7)%251}
}
fn make7()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+8)%251}
}
fn make8()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+9)%251}
}
fn make9()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+10)%251}
}
fn make10()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+11)%251}
}
fn make11()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+12)%251}
}
fn make12()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+13)%251}
}
fn make13()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+14)%251}
}
fn make14()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+15)%251}
}
fn make15()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+16)%251}
}
fn make16()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+17)%251}
}
fn make17()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+18)%251}
}
fn make18()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+19)%251}
}
fn make19()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+20)%251}
}
fn make20()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+21)%251}
}
fn make21()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+22)%251}
}
fn make22()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+23)%251}
}
fn make23()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+24)%251}
}
fn make24()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+25)%251}
}
fn make25()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+26)%251}
}
fn make26()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+27)%251}
}
fn make27()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+28)%251}
}
fn make28()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+29)%251}
}
fn make29()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+30)%251}
}
fn make30()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+31)%251}
}
fn make31()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+32)%251}
}
fn make32()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+33)%251}
}
fn make33()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+34)%251}
}
fn make34()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+35)%251}
}
fn make35()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+36)%251}
}
fn make36()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+37)%251}
}
fn make37()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+38)%251}
}
fn make38()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+39)%251}
}
fn make39()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+40)%251}
}
fn make40()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+41)%251}
}
fn make41()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+42)%251}
}
fn make42()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+43)%251}
}
fn make43()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+44)%251}
}
fn make44()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+45)%251}
}
fn make45()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+46)%251}
}
fn make46()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+47)%251}
}
fn make47()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+48)%251}
}
fn make48()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+49)%251}
}
fn make49()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+50)%251}
}
fn make50()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+51)%251}
}
fn make51()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+52)%251}
}
fn make52()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+53)%251}
}
fn make53()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+54)%251}
}
fn make54()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+55)%251}
}
fn make55()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+56)%251}
}
fn make56()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+57)%251}
}
fn make57()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+58)%251}
}
fn make58()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+59)%251}
}
fn make59()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+60)%251}
}
fn make60()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+61)%251}
}
fn make61()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+62)%251}
}
fn make62()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+63)%251}
}
fn make63()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+64)%251}
}
fn run(x:i64,d:i32)->i64 { let mut c0=make0(); let mut c1=make1(); let mut c2=make2(); let mut c3=make3(); let mut c4=make4(); let mut c5=make5(); let mut c6=make6(); let mut c7=make7(); let mut c8=make8(); let mut c9=make9(); let mut c10=make10(); let mut c11=make11(); let mut c12=make12(); let mut c13=make13(); let mut c14=make14(); let mut c15=make15(); let mut c16=make16(); let mut c17=make17(); let mut c18=make18(); let mut c19=make19(); let mut c20=make20(); let mut c21=make21(); let mut c22=make22(); let mut c23=make23(); let mut c24=make24(); let mut c25=make25(); let mut c26=make26(); let mut c27=make27(); let mut c28=make28(); let mut c29=make29(); let mut c30=make30(); let mut c31=make31(); let mut c32=make32(); let mut c33=make33(); let mut c34=make34(); let mut c35=make35(); let mut c36=make36(); let mut c37=make37(); let mut c38=make38(); let mut c39=make39(); let mut c40=make40(); let mut c41=make41(); let mut c42=make42(); let mut c43=make43(); let mut c44=make44(); let mut c45=make45(); let mut c46=make46(); let mut c47=make47(); let mut c48=make48(); let mut c49=make49(); let mut c50=make50(); let mut c51=make51(); let mut c52=make52(); let mut c53=make53(); let mut c54=make54(); let mut c55=make55(); let mut c56=make56(); let mut c57=make57(); let mut c58=make58(); let mut c59=make59(); let mut c60=make60(); let mut c61=make61(); let mut c62=make62(); let mut c63=make63(); let mut y=x%251; let mut j:i32=0; while j<d { y=c0(((y+0)%251) as u8); if y<0 {return 65520;} j+=1; } return y; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12) as i32)+i)%65521; i+=1; }
    write(acc);
}
