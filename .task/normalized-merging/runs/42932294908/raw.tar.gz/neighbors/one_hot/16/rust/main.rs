fn make0()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+1)%251}
}
fn make1()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+2)%251}
}
fn make2()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+3)%251}
}
fn make3()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+4)%251}
}
fn make4()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+5)%251}
}
fn make5()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+6)%251}
}
fn make6()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+7)%251}
}
fn make7()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+8)%251}
}
fn make8()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+9)%251}
}
fn make9()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+10)%251}
}
fn make10()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+11)%251}
}
fn make11()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+12)%251}
}
fn make12()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+13)%251}
}
fn make13()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+14)%251}
}
fn make14()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+15)%251}
}
fn make15()->impl FnMut(u8)->i64 {
    let mut data=Vec::<u8>::new();let mut sum:i64=0;
    move |byte| {if byte==0 {data=Vec::new();sum=0;return 0;}
        data.push(byte);sum+=i64::from(byte);(sum+data.len() as i64+16)%251}
}
fn run(x:i64,d:i32)->i64 { let mut c0=make0(); let mut c1=make1(); let mut c2=make2(); let mut c3=make3(); let mut c4=make4(); let mut c5=make5(); let mut c6=make6(); let mut c7=make7(); let mut c8=make8(); let mut c9=make9(); let mut c10=make10(); let mut c11=make11(); let mut c12=make12(); let mut c13=make13(); let mut c14=make14(); let mut c15=make15(); let mut y=x%251; let mut j:i32=0; while j<d { y=c0(((y+0)%251) as u8); if y<0 {return 65520;} j+=1; } return y; }
unsafe extern "C" { fn getchar()->i32; fn putchar(x:i32)->i32; }
fn read()->i64 { unsafe { i64::from(getchar()) } }
fn write(x:i64) { unsafe { putchar((x%256) as i32); putchar((x/256) as i32); } }
fn main() { let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {std::process::exit(2);}
    let mut acc:i64=seed; let mut i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,(depth%12) as i32)+i)%65521; i+=1; }
    write(acc);
}
