package State { manages data:ByteBuffer; sum:i64 }
fn create()->ByteBuffer contract { result(create) } {return bytes_new();}
fn append(value:ByteBuffer,byte:u8)->bool {
    let length=bytes_len(value); let capacity=bytes_capacity(value);
    if length==capacity {var next:i64=8; if capacity>0 {next=capacity*2;} if !bytes_reserve(value,next){return false;}}
    return bytes_push(value,byte);
}
fn make0()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+1)%251;
    };
}
fn make1()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+2)%251;
    };
}
fn make2()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+3)%251;
    };
}
fn make3()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+4)%251;
    };
}
fn make4()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+5)%251;
    };
}
fn make5()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+6)%251;
    };
}
fn make6()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+7)%251;
    };
}
fn make7()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+8)%251;
    };
}
fn make8()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+9)%251;
    };
}
fn make9()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+10)%251;
    };
}
fn make10()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+11)%251;
    };
}
fn make11()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+12)%251;
    };
}
fn make12()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+13)%251;
    };
}
fn make13()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+14)%251;
    };
}
fn make14()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+15)%251;
    };
}
fn make15()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+16)%251;
    };
}
fn make16()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+17)%251;
    };
}
fn make17()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+18)%251;
    };
}
fn make18()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+19)%251;
    };
}
fn make19()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+20)%251;
    };
}
fn make20()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+21)%251;
    };
}
fn make21()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+22)%251;
    };
}
fn make22()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+23)%251;
    };
}
fn make23()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+24)%251;
    };
}
fn make24()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+25)%251;
    };
}
fn make25()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+26)%251;
    };
}
fn make26()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+27)%251;
    };
}
fn make27()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+28)%251;
    };
}
fn make28()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+29)%251;
    };
}
fn make29()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+30)%251;
    };
}
fn make30()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+31)%251;
    };
}
fn make31()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+32)%251;
    };
}
fn make32()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+33)%251;
    };
}
fn make33()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+34)%251;
    };
}
fn make34()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+35)%251;
    };
}
fn make35()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+36)%251;
    };
}
fn make36()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+37)%251;
    };
}
fn make37()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+38)%251;
    };
}
fn make38()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+39)%251;
    };
}
fn make39()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+40)%251;
    };
}
fn make40()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+41)%251;
    };
}
fn make41()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+42)%251;
    };
}
fn make42()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+43)%251;
    };
}
fn make43()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+44)%251;
    };
}
fn make44()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+45)%251;
    };
}
fn make45()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+46)%251;
    };
}
fn make46()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+47)%251;
    };
}
fn make47()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+48)%251;
    };
}
fn make48()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+49)%251;
    };
}
fn make49()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+50)%251;
    };
}
fn make50()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+51)%251;
    };
}
fn make51()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+52)%251;
    };
}
fn make52()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+53)%251;
    };
}
fn make53()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+54)%251;
    };
}
fn make54()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+55)%251;
    };
}
fn make55()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+56)%251;
    };
}
fn make56()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+57)%251;
    };
}
fn make57()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+58)%251;
    };
}
fn make58()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+59)%251;
    };
}
fn make59()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+60)%251;
    };
}
fn make60()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+61)%251;
    };
}
fn make61()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+62)%251;
    };
}
fn make62()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+63)%251;
    };
}
fn make63()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+64)%251;
    };
}
fn run(x:i64,d:i32)->i64 { var c0=make0(); var y=x%251; var j:i32=0; while j<d { y=c0(u8((y+0)%251)); if y<0 {return 65520;} j+=1; } return y; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12))+i)%65521; i+=1; }
    write(acc); return 0;
}
