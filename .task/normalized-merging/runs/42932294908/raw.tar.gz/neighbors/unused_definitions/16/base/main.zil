package State { manages data:ByteBuffer; sum:i64 }
fn create()->ByteBuffer contract { result(create) } {return bytes_new();}
fn append(value:ByteBuffer,byte:u8)->bool {
    let length=bytes_len(value); let capacity=bytes_capacity(value);
    if length==capacity {var next:i64=8; if capacity>0 {next=capacity*2;} if !bytes_reserve(value,next){return false;}}
    return bytes_push(value,byte);
}
fn make0()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+1)%251;
    };
}
fn make1()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+2)%251;
    };
}
fn make2()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+3)%251;
    };
}
fn make3()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+4)%251;
    };
}
fn make4()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+5)%251;
    };
}
fn make5()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+6)%251;
    };
}
fn make6()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+7)%251;
    };
}
fn make7()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+8)%251;
    };
}
fn make8()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+9)%251;
    };
}
fn make9()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+10)%251;
    };
}
fn make10()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+11)%251;
    };
}
fn make11()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+12)%251;
    };
}
fn make12()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+13)%251;
    };
}
fn make13()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+14)%251;
    };
}
fn make14()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+15)%251;
    };
}
fn make15()->impl FnMut(u8)->i64 {
    var state=State{data:create(),sum:i64(0)};
    return move(byte)=>{
        if byte==0u8 {state.data=create();state.sum=0;return i64(0);}
        if !append(state.data,byte) {return i64(-1);}
        state.sum+=i64(byte);return (state.sum+bytes_len(state.data)+16)%251;
    };
}
fn run(x:i64,d:i32)->i64 { var c0=make0(); var y=x%251; var j:i32=0; while j<d { y=c0(u8((y+0)%251)); if y<0 {return 65520;} j+=1; } return y; }
extern "C" fn getchar()->i32;
extern "C" fn putchar(x:i32)->i32;
fn read()->i64 { unsafe { return i64(getchar()); } }
fn write(x:i64) { unsafe { putchar(i32(x%256)); putchar(i32(x/256)); } }
fn main()->i32 {
    let seed=read(); let depth=read(); let high=read(); let low=read();
    if seed<0 || depth<0 || high<0 || low<0 {return 2;}
    var acc:i64=seed; var i:i64=0; let count=high*256+low;
    while i<count { acc=(run((acc+i)%65521,i32(depth%12))+i)%65521; i+=1; }
    write(acc); return 0;
}
