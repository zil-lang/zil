#!/usr/bin/python3
import os,sys,json
cmd=['/home/runner/work/_temp/normalized-llvm/bin/clang-23']+sys.argv[1:]+['/home/runner/work/_temp/normalized-consumer/allocator.o', '-Wl,--wrap=realloc', '-Wl,--wrap=free']
assert "ir" not in sys.argv and "-c" not in sys.argv, "probe must only link actual API objects"
with open('/home/runner/work/_temp/normalized-consumer/probe-link-argv.jsonl',"a") as f:f.write(json.dumps(cmd)+"\n")
os.execv(cmd[0],cmd)
